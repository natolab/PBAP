#!/usr/bin/perl
# ./kped.pl
# By Alejandro Q. Nato, Jr., Ph.D.
# This script determines pairwise kinship coefficients based on the pedigree structure
# formerly pedcheck2i.pl
# It is a modified version of pedcheck.pl written by Dr. Nicola H. Chapman, which checks for 
# pedigree errors.

# 03/17/2013-03/22/2013
# 08/02/2013, 08/08/2013, 08/13/2013, 08/22/2013
# Modifications: 09/16/2013-10/16/2014


use strict;
use warnings;
use diagnostics;

use Time::HiRes qw( gettimeofday );

$, = " ";	# set output field separator

my ($line, $line1, $line2, $line3, $line4, $line5) = "";
my (@list, @list1, @list2, @list3, @list4, @list5) = ();
my (@info, @info1, @info2, @info3, @info4, @info5) = ();

my ($line6, $line7, $line8, $line9, $line10) = "";
my (@list6, @list7, @list8, @list9, @list10) = ();
my (@info6, @info7, @info8, @info9, @info10) = ();

my ($people, $person, $famid, $subid, $sex, $dadid, $dad, $momid, $mom) = 0;
my ($counth, $ind, $indiv, $thisdad, $thismom, $numcomp) = 0;
my ($fam, $famA, $famB, $family, $idA, $idB, $ind1, $ind2, $indnew) = 0;
my ($x, $allmarked, $change, $inbred, $kid, $kc, $gen, $gen1, $gen2) = 0;
my ($dad1, $mom1, $dad2, $mom2, $a1, $a2, $af, $mom3, $dad3) = 0;
my (@month, @families, @inds, @indnew) = ();
my ($rest, $aff, $genotyped, $iq) = "";
my (%dad, %mom, %person, %size, %sampled, %sexall) = ();
my (%marked, %anc, %ind, %indnew, %gen, %husb, %wife) = ();

my ($in1, $in2, $gnumh, $nognumh, $outdir) = "";

my $script = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;

if ($#ARGV < 0) {
	$script = $0;
	$script =~ s/^(.+)\///g;
	$script =~ s/^\.\///g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (March 2013, Aug 2013; updated September 2013-October 2014)\n\n";
	print "This script determines pairwise kinship coefficients\n";
	print "based on the pedigree structure.\n\n";

	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script pedigree_file_with_generation_numbers* [T|F]** output_directory*\n";
	print "       OR \.\/$script pedigree_file_with_generation_numbers* [T|F]** pedigree_file_without_generation_numbers*** [T|F]** output_directory*\n";
	print "       *use absolute path\n";
	print "       **header=[T|F]\n";
	print "       ***file containing complex pedigrees whose generation numbers cannot be determined\n";
	print "          Using this file, $script will only get the PO and unrelated pairs\n\n";
	
	print "If you have determined the generation numbers by using generation_numbers.pl,\n";
	print "   use its output file (gen_num.out).\n\n";
	print "Otherwise, use an input file with the following columns:\n\n";
	print "   1) Family ID\n";
	print "   2) Individual ID (concatenated with family ID)\n";
	print "   3) Father ID (concatenated with family ID except for zeros)\n";
	print "   4) Mother ID (concatenated with family ID except for zeros)\n";
	print "   5) Sex\n";
	print "   6) Generation Number\n\n";
	exit;
} elsif ($#ARGV == 2) {
	$in1     = $ARGV[0];	# generation_numbers.pl output file (absolute path of gen_num.out)
	$gnumh   = $ARGV[1];	# generation_number output file header: [T|F]
	$outdir  = $ARGV[2];	# output directory (absolute path)
	open (IN1, "<$in1") || die ("Could not open $in1 file!\n");
	@list1 = <IN1>;
	close (IN1);
} elsif ($#ARGV == 4) {
	$in1     = $ARGV[0];	# generation_numbers.pl output file (absolute path of gen_num.out)
	$gnumh   = $ARGV[1];	# generation_number output file header: [T|F]
	$in2     = $ARGV[2];	# generation_numbers.pl output file (absolute path of gen_num.out)
	$nognumh = $ARGV[3];	# generation_number output file header: [T|F]
	$outdir  = $ARGV[4];	# output directory (absolute path)

	open (IN1, "<$in1") || die ("Could not open $in1 file!\n");
	@list1 = <IN1>;
	close (IN1);

	open (IN3, "<$in2") || die ("Could not open $in2 file!\n");
	@list3 = <IN3>;
	close (IN3);
} else {
	print "$script requires three or five arguments\n\n";
	print "USAGE: \.\/$script pedigree_file_with_generation_numbers* [T|F]** output_directory*\n";
	print "       OR \.\/$script pedigree_file_with_generation_numbers* [T|F]** pedigree_file_without_generation_numbers*** [T|F]** output_directory*\n";
	print "       *use absolute path\n";
	print "       **header=[T|F]\n";
	print "       ***file containing complex pedigrees whose generation numbers cannot be determined\n";
	print "          Using this file, $script will only get the PO and unrelated pairs\n\n";
	
	print "If you have determined the generation numbers by using generation_numbers.pl,\n";
	print "   use its output file (gen_num.out).\n\n";
	print "Otherwise, use an input file with the following columns:\n\n";
	print "   1) Family ID\n";
	print "   2) Individual ID (concatenated with family ID)\n";
	print "   3) Father ID (concatenated with family ID except for zeros)\n";
	print "   4) Mother ID (concatenated with family ID except for zeros)\n";
	print "   5) Sex\n";
	print "   6) Generation Number\n\n";	exit;
}

if ($outdir =~ m/\/$/) { chop $outdir; }

my $out1 = $outdir."/kped.out";		# kinship
my $err  = $outdir."/kped.err";
my $log  = $outdir."/kped.log";

if (! -e $outdir) {
	`mkdir -p $outdir`;
}
if ( -e $err ) {
	`rm $err`;
}

open(OUT1, ">$out1") || die ("Could not create $out1 file!\n");
print OUT1 "Individual1$,Individual2$,Kinship_Coefficient$,Relationship\n";

open(LOG, ">$log") || die ("Could not create $log file!\n");
open (LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "################################################################################\n";
print LOG "#                                 PBAP kped.pl                                 #\n";
print LOG "#                            Alejandro Q. Nato, Jr.                            #\n";
print LOG "#                           Statistical Genetics Lab                           #\n";
print LOG "#                    University of Washington, Seattle, WA                     #\n";
print LOG "################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

print LOG "INPUT FILE                             : $in1\n";
if ( (defined($in2)) && ($in2 ne "") ) {
	print LOG "INDIVIDUALS WITHOUT GENERATION NUMBERS : $in2\n";
}
print LOG "OUTPUT FILE                            : $out1\n\n";
print LOG "LOG:\n";

# Create several hashes
($counth, $people) = 0;
foreach $line1 (@list1) {
	chomp $line1;
	next if ($line1 =~ m/input|\*\#/);
	@info1 = split(/\t|\s+/, $line1);
	$famid  = $info1[0];
	$subid  = $info1[1];
	$dadid  = $info1[2];
	$momid  = $info1[3];
	$sex    = $info1[4];
	$gen    = $info1[5];

	
	$counth++;
	
	# Remove leading and lagging spaces
	$famid=~s/^\s//;
	$famid=~ s/\s+$//;
	$subid=~s/^\s//;
	$subid=~ s/\s+$//;
	$dadid=~s/^\s//;
	$dadid=~ s/\s+$//;
	if ($gnumh =~ m/T/i) {
		next if ( ($counth == 1) || ($famid eq "FamilyID") );
	}
	next if ($famid eq "FamilyID");
	if ( ($dadid eq "") || ($dadid eq ".") ){ $dadid = 0; }

	$momid=~s/^\s//;
	$momid=~ s/\s+$//;
	if ( ($momid eq "") || ($momid eq ".") ) { $momid = 0; }

	if ($sex eq "M") { $sex = 1; }
	elsif ($sex eq "F") { $sex = 2; }
	$sex += 0;

	$dad{$famid}{$subid}    = $dadid;
	$mom{$famid}{$subid}    = $momid;
	$sexall{$famid}{$subid} = $sex;

	# Check for duplicate entries while creating the hash
	if (defined($person{$famid}{$subid})) {
		if (! -e $err) {
				open(ERR, ">$err") || die ("Could not create $err file!\n");
		}
		print ERR "Duplicate: Family $famid\, person $subid has been entered more than once.\n";
	} else {
		$person{$famid}{$subid} = $subid;
	}

	$gen{$famid}{$subid} = $gen;

	$people++;

	if(defined($size{$famid})) {
		$size{$famid} = $size{$famid} + 1;
	} else {
		$size{$famid} = 1;
	}
}

# Check families one by one
@families = sort keys(%person);
foreach $fam (@families) {
	# check each individual
	foreach $ind ( keys(%{$person{$fam}}) ) {

		# Check dad
		$thisdad = $dad{$fam}{$ind};
		$thisdad =~ s/^\s+0//;
		if (!defined($thisdad)) {
			if (! -e $err) {
				open(ERR, ">$err") || die ("Could not create $err file!\n");
			}
			print ERR "$fam $ind\'s dad is not on the input file\n";
		}
		if ( ($dad{$fam}{$ind} ne "0") && !exists( $person{$fam}{$dad{$fam}{$ind}} )) {
			if (! -e $err) {
				open(ERR, ">$err") || die ("Could not create $err file!\n");
			}
			print ERR "Family $fam\, person $ind\'s father \($dad{$fam}{$ind}\) is not in this family.\n";
		} else { # dad IS in the family
			# check sex of dad
			if ( (exists($sexall{$fam}{$thisdad})) && ($sexall{$fam}{$thisdad} != 1) && ($thisdad ne "0") ) {
				if (! -e $err) {
					open(ERR, ">$err") || die ("Could not create $err file!\n");
				}
				print ERR "Family $fam\, person $ind\'s father \($dad{$fam}{$ind}\) has the wrong sex.\n";
			}
		}

		# Check mom
		$thismom = $mom{$fam}{$ind};
		$thismom =~ s/^\s+0//;
		if (!defined($thismom)) {
			if (! -e $err) {
				open(ERR, ">$err") || die ("Could not create $err file!\n");
			}
			print ERR "$fam $ind\'s mom is not on the input file\n";
		}
		if ( ($mom{$fam}{$ind} ne "0") && !exists( $person{$fam}{$mom{$fam}{$ind}} )) {
			if (! -e $err) {
				open(ERR, ">$err") || die ("Could not create $err file!\n");
			}
			print ERR "Family $fam\, person $ind\'s mother \($mom{$fam}{$ind}\) is not in this family.\n";
		} else { # mom IS in the family
			# check sex of mom
			if ( (exists($sexall{$fam}{$thismom})) && ($sexall{$fam}{$thismom} != 2) && ($thismom ne "0") ) {
				if (! -e $err) {
					open(ERR, ">$err") || die ("Could not create $err file!\n");
				}
				print ERR "Family $fam\, person $ind\'s mother \($mom{$fam}{$ind}\) has the wrong sex.\n";
			}
		}

		# Make sure that kid is not his/her own parent because this will hang the inbreeding check
		if ( ($ind eq $dad{$fam}{$ind}) || ($ind eq $mom{$fam}{$ind}) ) {
			if (! -e $err) {
				open(ERR, ">$err") || die ("Could not create $err file!\n");
			}
			print ERR "Family $fam\, person $ind is his/her own parent.\n";
			next;
		}

		# Check if the person is not inbred
		if ($mom{$fam}{$ind} eq "0" && $dad{$fam}{$ind} eq "0") {
			$inbred = 0;
		} else {
			foreach $x ( keys(%{$person{$fam}}) ) {
				$anc{$x} = 0;
			}
			if (defined($dad{$fam}{$ind})) {
				mark_ancestor($fam,$dad{$fam}{$ind});
			}
			if (defined($mom{$fam}{$ind})) {
				$inbred = check_ancestor($fam,$mom{$fam}{$ind});
			}
		}

		if ($inbred == 1) {
			if (! -e $err) {
				open(ERR, ">$err") || die ("Could not create $err file!\n");
			}
			print ERR "Family $fam\, person $ind is inbred.\n";
		}

	} # end of foreach ind loop

	print LOG "Checking components in family $fam\n";
	@inds = keys(%{$person{$fam}});
	foreach $x (@inds) {
		$marked{$x} = 0;
	}
	# Mark someone to start
	$marked{$inds[0]} = 1;
	$change = 1;
	$allmarked = 0;
	while ( ($change == 1) && ($allmarked == 0) ) {
		$change = 0;
		$allmarked = 1;
		foreach $person (@inds) {
			if ($marked{$person}) {
				#mark parents
				if ( ($dad{$fam}{$person} ne "0") && ($mom{$fam}{$person} ne "0") ) {
					if ( (defined($marked{$dad{$fam}{$person}})) && ($marked{$dad{$fam}{$person}} == 0) ) {
						$marked{$dad{$fam}{$person}} = 1;
						$change = 1;
					}
					if ( (defined($marked{$mom{$fam}{$person}})) && ($marked{$mom{$fam}{$person}} == 0) ) {
						$marked{$mom{$fam}{$person}} = 1;
						$change = 1;
					}
				}
				#mark kids
				foreach $kid (@inds) {
					if ( ( ($person eq $dad{$fam}{$kid}) && ($marked{$kid} == 0) ) || ( ($person eq $mom{$fam}{$kid}) && ($marked{$kid} == 0) ) ) {
						$marked{$kid} = 1;
						$change = 1;
					}
				}
			} else {
				$allmarked = 0;
			}
		} # end of foreach person loop
	} # end of while loop

	$numcomp = 1;
	foreach $person (@inds) {
		if ($marked{$person} == 0) {
			$numcomp = 2;
		}
	}

	if ($numcomp == 2) {
		if (! -e $err) {
                                open(ERR, ">$err") || die ("Could not create $err file!\n");
                }
		print ERR "Family $fam has more than one component.\n";
	}
} # end of foreach fam loop

# Calculate Kinship Coefficients
my %relpair = ();
my $rel = "";
$counth = 0;
foreach $line1 (@list1) {
	chomp $line1;
	next if ($line1 =~ m/input|\*\#/);
	@info1 = split(/\t|\s+/, $line1);
	$famid  = $info1[0];
	$subid  = $info1[1];
	$dadid  = $info1[2];
	$momid  = $info1[3];
	$sex    = $info1[4];
	$gen    = $info1[5];

	$counth++;

	# Remove leading and lagging spaces
	$famid=~s/^\s//;
	$famid=~ s/\s+$//;
	$subid=~s/^\s//;
	$subid=~ s/\s+$//;
	$dadid=~s/^\s//;
	$dadid=~ s/\s+$//;
	if ($gnumh =~ m/T/i) {
		next if ( ($counth == 1) || ($famid eq "FamilyID") );
	}
	next if ($famid eq "FamilyID");
	if ( ($dadid eq "") || ($dadid eq ".") ){ $dadid = 0; }

	$momid=~s/^\s//;
	$momid=~ s/\s+$//;
	if ( ($momid eq "") || ($momid eq ".") ) { $momid = 0; }

	if ($sex eq "M") { $sex = 1; }
	elsif ($sex eq "F") { $sex = 2; }
	$sex += 0;

	$famA = $famid;
	$idA = $subid;


	@list2 = ();
	#open (IN2, "< $ARGV[0]");
	open (IN2, "<$in1") || die ("Could not open $in1 file!\n");
	@list2 = <IN2>;
	close (IN2);
	
	my $counth2 = 0;
	if ( (defined($idA)) && ($idA ne "") ) {
		foreach $line2 (@list2) {
			chomp $line2;
			next if ($line2 =~ m/input|\*\#/);
			@info2 = split (/\t|\s+/, $line2, 3);
			$famB = $info2[0];
			$idB  = $info2[1];
			
			$counth2++;
			if ($gnumh =~ m/T/i) {
				next if ( ($counth2 == 1) || ($famB eq "FamilyID") );
			}
			
			if ($famB eq $famA) {	# check within the same FamilyID for now
				if ($idA ne $idB) {
					if ( (!defined($relpair{$famA}{$idA}{$idB})) && (!defined($relpair{$famA}{$idB}{$idA})) ) {
						$kc = kinship($famA,$idA,$famB,$idB);
						$kc = sprintf("%.10f", $kc);	# changed to 10 decimal places (08/22/2013)
						$relpair{$famA}{$idA}{$idB} = $kc;
						$rel = relationship($famA,$idA,$idB,$kc);
						print OUT1 "$idA$,$idB$,$kc$,$rel\n";
						$kc = 0;
					}
				}
			}
		}
	}
}

###### If there is a gen_num.pnd file
if ( (defined($in2)) && ($in2 ne "") ) {
	# Create several hashes
	($counth, $people) = 0;
	(%dad, %mom, %sexall, %person, %size) = ();
	foreach $line3 (@list3) {
		chomp $line3;
		next if ($line3 =~ m/input|\*\#/);
		@info3 = split(/\s+/, $line3);
		$famid  = $info3[0];
		$subid  = $info3[1];
		$dadid  = $info3[2];
		$momid  = $info3[3];
		$sex    = $info3[4];

	
		$counth++;

		# Remove leading and lagging spaces
		$famid=~s/^\s//;
		$famid=~ s/\s+$//;
		$subid=~s/^\s//;
		$subid=~ s/\s+$//;
		$dadid=~s/^\s//;
		$dadid=~ s/\s+$//;
		if ($nognumh =~ m/T/i) {
			next if ( ($counth == 1) || ($famid eq "FamilyID") );
		}
		next if ($famid eq "FamilyID");
		if ( ($dadid eq "") || ($dadid eq ".") ){ $dadid = 0; }

		$momid=~s/^\s//;
		$momid=~ s/\s+$//;
		if ( ($momid eq "") || ($momid eq ".") ) { $momid = 0; }

		if ($sex eq "M") { $sex = 1; }
		elsif ($sex eq "F") { $sex = 2; }
		$sex += 0;

		$dad{$famid}{$subid}    = $dadid;
		$mom{$famid}{$subid}    = $momid;
		$sexall{$famid}{$subid} = $sex;

		# Check for duplicate entries while creating the hash
		if (defined($person{$famid}{$subid})) {
			if (! -e $err) {
					open(ERR, ">$err") || die ("Could not create $err file!\n");
			}
			print ERR "Duplicate: Family $famid\, person $subid has been entered more than once.\n";
		} else {
			$person{$famid}{$subid} = $subid;
		}

		$people++;

		if(defined($size{$famid})) {
			$size{$famid} = $size{$famid} + 1;
		} else {
			$size{$famid} = 1;
		}
	}
	
	# Check families one by one
	@families = ();
	@families = sort keys(%person);
	foreach $fam (@families) {
		# check each individual
		print LOG "Checking PO, FS, and U pairs in family $fam\n";
		foreach $ind ( keys(%{$person{$fam}}) ) {

			# Check dad
			$thisdad = $dad{$fam}{$ind};
			$thisdad =~ s/^\s+0//;
			if (!defined($thisdad)) {
				if (! -e $err) {
					open(ERR, ">$err") || die ("Could not create $err file!\n");
				}
				print ERR "$fam $ind\'s dad is not on the input file\n";
			}
			if ( ($dad{$fam}{$ind} ne "0") && !exists( $person{$fam}{$dad{$fam}{$ind}} )) {
				if (! -e $err) {
					open(ERR, ">$err") || die ("Could not create $err file!\n");
				}
				print ERR "Family $fam\, person $ind\'s father \($dad{$fam}{$ind}\) is not in this family.\n";
			} else { # dad IS in the family
				# check sex of dad
				if ( (exists($sexall{$fam}{$thisdad})) && ($sexall{$fam}{$thisdad} != 1) && ($thisdad ne "0") ) {
					if (! -e $err) {
						open(ERR, ">$err") || die ("Could not create $err file!\n");
					}
					print ERR "Family $fam\, person $ind\'s father \($dad{$fam}{$ind}\) has the wrong sex.\n";
				}
			}

			# Check mom
			$thismom = $mom{$fam}{$ind};
			#print "Family\=$fam Individual\=$ind Mom\=$thismom\n";
			$thismom =~ s/^\s+0//;
			if (!defined($thismom)) {
				if (! -e $err) {
					open(ERR, ">$err") || die ("Could not create $err file!\n");
				}
				print ERR "$fam $ind\'s mom is not on the input file\n";
			}
			if ( ($mom{$fam}{$ind} ne "0") && !exists( $person{$fam}{$mom{$fam}{$ind}} )) {
				if (! -e $err) {
					open(ERR, ">$err") || die ("Could not create $err file!\n");
				}
				print ERR "Family $fam\, person $ind\'s mother \($mom{$fam}{$ind}\) is not in this family.\n";
			} else { # mom IS in the family
				# check sex of mom
				if ( (exists($sexall{$fam}{$thismom})) && ($sexall{$fam}{$thismom} != 2) && ($thismom ne "0") ) {
					if (! -e $err) {
						open(ERR, ">$err") || die ("Could not create $err file!\n");
					}
					print ERR "Family $fam\, person $ind\'s mother \($mom{$fam}{$ind}\) has the wrong sex.\n";
				}
			}

			# Make sure that kid is not his/her own parent because this will hang the inbreeding check
			if ( ($ind eq $dad{$fam}{$ind}) || ($ind eq $mom{$fam}{$ind}) ) {
				if (! -e $err) {
					open(ERR, ">$err") || die ("Could not create $err file!\n");
				}
				print ERR "Family $fam\, person $ind is his/her own parent.\n";
				next;
			}
		}
	}
	
	# Kinship Coefficients for PO and U only
	%relpair = ();
	$rel = "";
	$counth = 0;
	foreach $line3 (@list3) {
		chomp $line3;
		next if ($line3 =~ m/input|\*\#/);
		@info3 = split(/\s+/, $line3);
		$famid  = $info3[0];
		$subid  = $info3[1];
		$dadid  = $info3[2];
		$momid  = $info3[3];
		$sex    = $info3[4];

		$counth++;

		# Remove leading and lagging spaces
		$famid=~s/^\s//;
		$famid=~ s/\s+$//;
		$subid=~s/^\s//;
		$subid=~ s/\s+$//;
		$dadid=~s/^\s//;
		$dadid=~ s/\s+$//;
		if ($nognumh =~ m/T/i) {
			next if ( ($counth == 1) || ($famid eq "FamilyID") );
		}
		next if ($famid eq "FamilyID");
		if ( ($dadid eq "") || ($dadid eq ".") ){ $dadid = 0; }

		$momid=~s/^\s//;
		$momid=~ s/\s+$//;
		if ( ($momid eq "") || ($momid eq ".") ) { $momid = 0; }

		if ($sex eq "M") { $sex = 1; }
		elsif ($sex eq "F") { $sex = 2; }
		$sex += 0;

		$famA = $famid;
		$idA = $subid;


		@list4 = ();
		open (IN4, "<$in2") || die ("Could not open $in2 file!\n");
		@list4 = <IN4>;
		close (IN4);
	
		my $counth2 = 0;
		if ( (defined($idA)) && ($idA ne "") ) {
			foreach $line4 (@list4) {
				chomp $line4;
				next if ($line4 =~ m/input|\*\#/);
				@info4 = split (/\t|\s+/, $line4, 3);
				$famB = $info4[0];
				$idB  = $info4[1];
			
				$counth2++;
				if ($nognumh =~ m/T/i) {
					next if ( ($counth2 == 1) || ($famB eq "FamilyID") );
				}
			
				if ($famB eq $famA) {	# check within the same FamilyID for now
					if ($idA ne $idB) {
						if ( (!defined($relpair{$famA}{$idA}{$idB})) && (!defined($relpair{$famA}{$idB}{$idA})) ) {
							# check for PO, FS, and U
							if ( ($idA eq $dad{$famA}{$idB}) || ($idA eq $mom{$famA}{$idB}) || ($idB eq $dad{$famA}{$idA}) || ($idB eq $mom{$famA}{$idA}) ) {
								# PO
								$kc = sprintf("%.10f", 0.25);
								$relpair{$famA}{$idA}{$idB} = $kc;
								$rel = relationship($famA,$idA,$idB,$kc);
							} elsif ( ($mom{$famA}{$idA} eq $mom{$famA}{$idB}) && ($dad{$famA}{$idA} eq $dad{$famA}{$idB}) && ($mom{$famA}{$idA} ne "0") && ($dad{$famA}{$idA} ne "0") && ($mom{$famA}{$idB} ne "0") && ($dad{$famA}{$idB} ne "0")) {
								# parents are the same so FS
								$kc = sprintf("%.10f", 0.25);
								$relpair{$famA}{$idA}{$idB} = $kc;
								$rel = relationship($famA,$idA,$idB,$kc);
							} elsif ( ($dad{$famA}{$idA} eq "0") && ($mom{$famA}{$idA} eq "0") && ($dad{$famA}{$idB} eq "0") && ($mom{$famA}{$idB} eq "0") ) {
								# both founders so U
								$kc = sprintf("%.10f", 0);
								$relpair{$famA}{$idA}{$idB} = $kc;
								$rel = relationship($famA,$idA,$idB,$kc);
							} else {
								$kc = "ND";	# reverted back on 01/27/2015
								$relpair{$famA}{$idA}{$idB} = $kc;
								$rel = "ND";
							}
							print OUT1 "$idA$,$idB$,$kc$,$rel\n";
							$kc = 0;
						}
					}
				}
			}
		}
	}
}

close (ERR);
close (OUT1);

##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);

print "\nTotal real time   : " . parsetime ($real);
print   "Total user time   : " . parsetime ($user);
print   "Total system time : " . parsetime ($system);
print LOG "\nTotal real time   : " . parsetime ($real);
print LOG   "Total user time   : " . parsetime ($user);
print LOG   "Total system time : " . parsetime ($system);
print "\nDone\n\n";
close (LOG);

##### SUBROUTINES #####

sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}


# Recursively mark all of individual's ancestors
sub mark_ancestor {
	$family = $_[0];
	$indiv  = $_[1];

	if (defined($indiv)) {
		$anc{$indiv} = 1.0;
		if ( (defined($dad{$family}{$indiv})) && (defined($mom{$family}{$indiv})) && ($dad{$family}{$indiv} eq "0") && ($mom{$family}{$indiv} eq "0") ) {
			return;
		} else {
			if (defined($dad{$family}{$indiv})) {
				mark_ancestor($family,$dad{$family}{$indiv});
			}
			if (defined($mom{$family}{$indiv})) {
				mark_ancestor($family,$mom{$family}{$indiv});
			}
        }
    }
}

# Recursively check all of an individual's ancestors: return "1" if you hit one
# that has been previously marked.
sub check_ancestor {
	$family=$_[0];
	$indiv=$_[1];

	if (defined($indiv)) {
		if (exists($anc{$indiv})) {
			$anc{$indiv} += 0;
			if ($anc{$indiv} == 1) {
				return 1.0;
			}
		} else {
			if ( (exists($dad{$family}{$indiv})) && (exists($mom{$family}{$indiv})) ) {
				if ( ($dad{$family}{$indiv} eq "0") && ($mom{$family}{$indiv} eq "0") ) {
					return 0.0;
				}
			} else {
				if (exists($dad{$family}{$indiv})) {
					check_ancestor($family,$dad{$family}{$indiv});
				} elsif (exists($mom{$family}{$indiv})) {
					check_ancestor($family,$mom{$family}{$indiv});
				}
			}
		}
	}
}

sub kinship {
	# Define local variables
	my $fam1 = $_[0];
	my $id1  = $_[1];
	my $fam2 = $_[2];
	my $id2  = $_[3];

	if ( (defined($fam1)) && (defined($id1)) && (defined($fam2)) && (defined($id2)) ) {

		if ( ($fam1 eq $fam2) && ($id1 eq $id2) ) {										# if two people are the same
			if ( (defined($dad{$fam1}{$id1})) && (defined($mom{$fam1}{$id1})) && ($dad{$fam1}{$id1} eq "0") && ($mom{$fam1}{$id1} eq "0") ) {			# founder
				return 0.5;
			} elsif ( (defined($dad{$fam1}{$id1})) && (defined($mom{$fam1}{$id1})) && ($dad{$fam1}{$id1} ne "0") && ($mom{$fam1}{$id1} ne "0") ) { 			# not founder
				return (1 + kinship($fam1,$dad{$fam1}{$id1},$fam1,$mom{$fam1}{$id1}))/2;
			}
		} elsif ( ($fam1 eq $fam2) && ($id1 ne $id2) ) {								# if two people are not the same
			if ( (defined($dad{$fam1}{$id1})) && (defined($mom{$fam1}{$id1})) && ($dad{$fam1}{$id1} eq "0") && ($mom{$fam1}{$id1} eq "0") ) { 			# person with id1 is a founder
				if ( (defined($dad{$fam2}{$id2})) && (defined($mom{$fam2}{$id2})) && ($dad{$fam2}{$id2} eq "0") && ($mom{$fam2}{$id2} eq "0") ) {		# person with id2 is also a founder
					return 0.0;      													# zero because both are founders
				} elsif ( (defined($dad{$fam2}{$id2})) && (defined($mom{$fam2}{$id2})) && ($dad{$fam2}{$id2} ne "0") && ($mom{$fam2}{$id2} ne "0") ) {	# 1 is a founder, 2 isn't a founder so expand around 2
					return (kinship($fam2,$dad{$fam2}{$id2},$fam1,$id1) + kinship($fam2,$mom{$fam2}{$id2},$fam1,$id1))/2;
				}
			} elsif ( (defined($dad{$fam1}{$id1})) && (defined($mom{$fam1}{$id1})) && ($dad{$fam1}{$id1} ne "0") && ($mom{$fam1}{$id1} ne "0") ) {		# person with id1 is not a founder
				if ( (defined($dad{$fam2}{$id2})) && (defined($mom{$fam2}{$id2})) && ($dad{$fam2}{$id2} eq "0") && ($mom{$fam2}{$id2} eq "0") ) {		# person with id2 is a founder, 1 isn't a founder so expand around 1
					return (kinship($fam1,$dad{$fam1}{$id1},$fam2,$id2) + kinship($fam1,$mom{$fam1}{$id1},$fam2,$id2))/2;
				} elsif ( (defined($dad{$fam2}{$id2})) && (defined($mom{$fam2}{$id2})) && ($dad{$fam2}{$id2} ne "0") && ($mom{$fam2}{$id2} ne "0") ) {	# neither person is a founder so expand around younger
					# If they are from the same generation number, we can expand around either safely
					if ($gen{$fam1}{$id1} <= $gen{$fam2}{$id2}){ 												#expand around person 2
						return (kinship($fam2,$dad{$fam2}{$id2},$fam1,$id1) + kinship($fam2,$mom{$fam2}{$id2},$fam1,$id1))/2;
					} elsif ($gen{$fam1}{$id1} > $gen{$fam2}{$id2}) { 											#expand around person 1
						return (kinship($fam1,$dad{$fam1}{$id1},$fam2,$id2) + kinship($fam1,$mom{$fam1}{$id1},$fam2,$id2))/2;
					}
				}
			}
		}
	}
}

sub relationship {
	my $fam3 = $_[0];
	my $id3  = $_[1];
	my $id4  = $_[2];
	my $kc2  = $_[3];
	if ( (defined($fam3)) && (defined($id3)) && (defined($id4)) && (defined($kc2)) ) {
		if ($kc2 == 0) {
			return "U";
		} elsif ($kc2 == 0.25) {
			# check whether PO or FS
			if ( ($mom{$fam3}{$id4} eq $id3) || ($dad{$fam3}{$id4} eq $id3) || ($mom{$fam3}{$id3} eq $id4) || ($dad{$fam3}{$id3} eq $id4) ) {
				return "PO";
			} elsif ( ($mom{$fam3}{$id3} eq $mom{$fam3}{$id4}) && ($dad{$fam3}{$id3} eq $dad{$fam3}{$id4}) ) {
				return "FS";
			}
		} elsif ($kc2 == 0.125) {
			# check whether G, N, H, or DFC
			my $mom_of_id3 = $mom{$fam3}{$id3};
			my $mom_of_id4 = $mom{$fam3}{$id4};
			my $dad_of_id3 = $dad{$fam3}{$id3};
			my $dad_of_id4 = $dad{$fam3}{$id4};
			if ( (defined($mom{$fam3}{$mom_of_id3})) && ($mom{$fam3}{$mom_of_id3} eq $id4) ) {
				return "GG";
			} elsif ( (defined($dad{$fam3}{$mom_of_id3})) && ($dad{$fam3}{$mom_of_id3} eq $id4) ) {
				return "GG";
			} elsif ( (defined($mom{$fam3}{$dad_of_id3})) && ($mom{$fam3}{$dad_of_id3} eq $id4) ) {
				return "GG"
			} elsif ( (defined($dad{$fam3}{$dad_of_id3})) && ($dad{$fam3}{$dad_of_id3} eq $id4) ) {
				return "GG";
			} elsif ( (defined($mom{$fam3}{$mom_of_id4})) && ($mom{$fam3}{$mom_of_id4} eq $id3) ) {
				return "GG";
			} elsif ( (defined($dad{$fam3}{$mom_of_id4})) && ($dad{$fam3}{$mom_of_id4} eq $id3) ) {
				return "GG";
			} elsif ( (defined($mom{$fam3}{$dad_of_id4})) && ($mom{$fam3}{$dad_of_id4} eq $id3) ) {
				return "GG"
			} elsif ( (defined($dad{$fam3}{$dad_of_id4})) && ($dad{$fam3}{$dad_of_id4} eq $id3) ) {
				return "GG";
			} elsif ( (defined($mom{$fam3}{$mom_of_id3})) && (defined($dad{$fam3}{$mom_of_id3})) && ($mom{$fam3}{$mom_of_id3} eq $mom{$fam3}{$id4}) && ($dad{$fam3}{$mom_of_id3} eq $dad{$fam3}{$id4}) ) {
				return "AV";
			} elsif ( (defined($mom{$fam3}{$dad_of_id3})) && (defined($dad{$fam3}{$dad_of_id3})) && ($mom{$fam3}{$dad_of_id3} eq $mom{$fam3}{$id4}) && ($dad{$fam3}{$dad_of_id3} eq $dad{$fam3}{$id4}) ) {
				return "AV";
			} elsif ( (defined($mom{$fam3}{$mom_of_id4})) && (defined($dad{$fam3}{$mom_of_id4})) && ($mom{$fam3}{$mom_of_id4} eq $mom{$fam3}{$id3}) && ($dad{$fam3}{$mom_of_id4} eq $dad{$fam3}{$id3}) ) {
				return "AV";
			} elsif ( (defined($mom{$fam3}{$dad_of_id4})) && (defined($dad{$fam3}{$dad_of_id4})) && ($mom{$fam3}{$dad_of_id4} eq $mom{$fam3}{$id3}) && ($dad{$fam3}{$dad_of_id4} eq $dad{$fam3}{$id3}) ) {
				return "AV";
			} elsif ( ($mom{$fam3}{$id3} eq $mom{$fam3}{$id4}) && ($dad{$fam3}{$id3} ne $dad{$fam3}{$id4}) ) {
				return "HS";
			} elsif ( ($mom{$fam3}{$id3} ne $mom{$fam3}{$id4}) && ($dad{$fam3}{$id3} eq $dad{$fam3}{$id4}) ) {
				return "HS";
			} elsif ( (defined($mom{$fam3}{$mom_of_id3})) && (defined($dad{$fam3}{$mom_of_id3})) && (defined($mom{$fam3}{$dad_of_id3})) && (defined($dad{$fam3}{$dad_of_id3})) && (defined($mom{$fam3}{$mom_of_id4})) && (defined($dad{$fam3}{$mom_of_id4})) && (defined($mom{$fam3}{$dad_of_id4})) && (defined($dad{$fam3}{$dad_of_id4}))) {
				# moms are siblings, dads are siblings, moms U dads OR
				# mom1 and dad2 are siblings, mom2 and dad1 are siblings, mom1 U mom2, dad1 U dad2
				if ( ($mom{$fam3}{$mom_of_id3} eq $mom{$fam3}{$mom_of_id4}) && ($dad{$fam3}{$mom_of_id3} eq $dad{$fam3}{$mom_of_id4}) ) {
					if ( ($mom{$fam3}{$dad_of_id3} eq $mom{$fam3}{$dad_of_id4}) && ($dad{$fam3}{$dad_of_id3} eq $dad{$fam3}{$dad_of_id4}) ) {
						if ( ($mom{$fam3}{$mom_of_id3} ne $mom{$fam3}{$dad_of_id4}) && ($dad{$fam3}{$mom_of_id3} ne $dad{$fam3}{$dad_of_id4}) ) {
							return "DFC";
						}
					}
				} elsif ( ($mom{$fam3}{$mom_of_id3} eq $mom{$fam3}{$dad_of_id4}) && ($dad{$fam3}{$mom_of_id3} eq $dad{$fam3}{$dad_of_id4}) ) {
					if ( ($mom{$fam3}{$dad_of_id3} eq $mom{$fam3}{$mom_of_id4}) && ($dad{$fam3}{$dad_of_id3} eq $dad{$fam3}{$mom_of_id4}) ) {
						if ( ($mom{$fam3}{$mom_of_id3} ne $mom{$fam3}{$mom_of_id4}) && ($dad{$fam3}{$dad_of_id3} ne $dad{$fam3}{$dad_of_id4}) ) {
							return "DFC";
						}
					}
				}
			}
		} elsif ($kc2 == 0.0625) {
			# check whether GGG, GAV, FC, HAV, or DFC1R
			my $mom_of_id3 = $mom{$fam3}{$id3};
			my $mom_of_id4 = $mom{$fam3}{$id4};
			my $dad_of_id3 = $dad{$fam3}{$id3};
			my $dad_of_id4 = $dad{$fam3}{$id4};
			my $mgmom_of_id3 = $mom{$fam3}{$mom_of_id3};
			my $mgmom_of_id4 = $mom{$fam3}{$mom{$fam3}{$id4}};
			my $mgdad_of_id3 = $dad{$fam3}{$mom{$fam3}{$id3}};
			my $mgdad_of_id4 = $dad{$fam3}{$mom{$fam3}{$id4}};
			my $pgmom_of_id3 = $mom{$fam3}{$dad{$fam3}{$id3}};
			my $pgmom_of_id4 = $mom{$fam3}{$dad{$fam3}{$id4}};
			my $pgdad_of_id3 = $dad{$fam3}{$dad{$fam3}{$id3}};
			my $pgdad_of_id4 = $dad{$fam3}{$dad{$fam3}{$id4}};
			if ( (defined($mgmom_of_id3)) && (defined($mom{$fam3}{$mgmom_of_id3})) && ($mom{$fam3}{$mgmom_of_id3} eq $id4) ) {
				return "GGG";
			} elsif ( (defined($mgmom_of_id4)) && (defined($mom{$fam3}{$mgmom_of_id4})) && ($mom{$fam3}{$mgmom_of_id4} eq $id3) ) {
				return "GGG";
			} elsif ( (defined($mgdad_of_id3)) && (defined($mom{$fam3}{$mgdad_of_id3})) && ($mom{$fam3}{$mgdad_of_id3} eq $id4) ) {
				return "GGG";
			} elsif ( (defined($mgdad_of_id4)) && (defined($mom{$fam3}{$mgdad_of_id4})) && ($mom{$fam3}{$mgdad_of_id4} eq $id3) ) {
				return "GGG";
			} elsif ( (defined($mgmom_of_id3)) && (defined($dad{$fam3}{$mgmom_of_id3})) && ($dad{$fam3}{$mgmom_of_id3} eq $id4) ) {
				return "GGG";
			} elsif ( (defined($mgmom_of_id4)) && (defined($dad{$fam3}{$mgmom_of_id4})) && ($dad{$fam3}{$mgmom_of_id4} eq $id3) ) {
				return "GGG";
			} elsif ( (defined($mgdad_of_id3)) && (defined($dad{$fam3}{$mgdad_of_id3})) && ($dad{$fam3}{$mgdad_of_id3} eq $id4) ) {
				return "GGG";
			} elsif ( (defined($mgdad_of_id4)) && (defined($dad{$fam3}{$mgdad_of_id4})) && ($dad{$fam3}{$mgdad_of_id4} eq $id3) ) {
				return "GGG";
			} elsif ( (defined($pgmom_of_id3)) && (defined($mom{$fam3}{$pgmom_of_id3})) && ($mom{$fam3}{$pgmom_of_id3} eq $id4) ) {
				return "GGG";
			} elsif ( (defined($pgmom_of_id4)) && (defined($mom{$fam3}{$pgmom_of_id4})) && ($mom{$fam3}{$pgmom_of_id4} eq $id3) ) {
				return "GGG";
			} elsif ( (defined($pgdad_of_id3)) && (defined($mom{$fam3}{$pgdad_of_id3})) && ($mom{$fam3}{$pgdad_of_id3} eq $id4) ) {
				return "GGG";
			} elsif ( (defined($pgdad_of_id4)) && (defined($mom{$fam3}{$pgdad_of_id4})) && ($mom{$fam3}{$pgdad_of_id4} eq $id3) ) {
				return "GGG";
			} elsif ( (defined($pgmom_of_id3)) && (defined($dad{$fam3}{$pgmom_of_id3})) && ($dad{$fam3}{$pgmom_of_id3} eq $id4) ) {
				return "GGG";
			} elsif ( (defined($pgmom_of_id4)) && (defined($dad{$fam3}{$pgmom_of_id4})) && ($dad{$fam3}{$pgmom_of_id4} eq $id3) ) {
				return "GGG";
			} elsif ( (defined($pgdad_of_id3)) && (defined($dad{$fam3}{$pgdad_of_id3})) && ($dad{$fam3}{$pgdad_of_id3} eq $id4) ) {
				return "GGG";
			} elsif ( (defined($pgdad_of_id4)) && (defined($dad{$fam3}{$pgdad_of_id4})) && ($dad{$fam3}{$pgdad_of_id4} eq $id3) ) {
				return "GGG";
			} elsif ( (defined($mgmom_of_id3)) && (defined($mom{$fam3}{$mgmom_of_id3})) && (defined($dad{$fam3}{$mgmom_of_id3})) && (defined($mom{$fam3}{$id4})) && (defined($dad{$fam3}{$id4})) && ($mom{$fam3}{$mgmom_of_id3} eq $mom{$fam3}{$id4}) && ($dad{$fam3}{$mgmom_of_id3} eq $dad{$fam3}{$id4}) ) {
				return "GAV";
			} elsif ( (defined($mgdad_of_id3)) && (defined($mom{$fam3}{$mgdad_of_id3})) && (defined($dad{$fam3}{$mgdad_of_id3})) && (defined($mom{$fam3}{$id4})) && (defined($dad{$fam3}{$id4})) && ($mom{$fam3}{$mgdad_of_id3} eq $mom{$fam3}{$id4}) && ($dad{$fam3}{$mgdad_of_id3} eq $dad{$fam3}{$id4}) ) {
				return "GAV";
			} elsif ( (defined($mgmom_of_id4)) && (defined($mom{$fam3}{$mgmom_of_id4})) && (defined($dad{$fam3}{$mgmom_of_id4})) && (defined($mom{$fam3}{$id3})) && (defined($dad{$fam3}{$id3})) && ($mom{$fam3}{$mgmom_of_id4} eq $mom{$fam3}{$id3}) && ($dad{$fam3}{$mgmom_of_id4} eq $dad{$fam3}{$id3}) ) {
				return "GAV";
			} elsif ( (defined($mgdad_of_id4)) && (defined($mom{$fam3}{$mgdad_of_id4})) && (defined($dad{$fam3}{$mgdad_of_id4})) && (defined($mom{$fam3}{$id3})) && (defined($dad{$fam3}{$id3})) && ($mom{$fam3}{$mgdad_of_id4} eq $mom{$fam3}{$id3}) && ($dad{$fam3}{$mgdad_of_id4} eq $dad{$fam3}{$id3}) ) {
				return "GAV";
			} elsif ( (defined($pgmom_of_id3)) && (defined($mom{$fam3}{$pgmom_of_id3})) && (defined($dad{$fam3}{$pgmom_of_id3})) && (defined($mom{$fam3}{$id4})) && (defined($dad{$fam3}{$id4})) && ($mom{$fam3}{$pgmom_of_id3} eq $mom{$fam3}{$id4}) && ($dad{$fam3}{$pgmom_of_id3} eq $dad{$fam3}{$id4}) ) {
				return "GAV";
			} elsif ( (defined($pgdad_of_id3)) && (defined($mom{$fam3}{$pgdad_of_id3})) && (defined($dad{$fam3}{$pgdad_of_id3})) && (defined($mom{$fam3}{$id4})) && (defined($dad{$fam3}{$id4})) && ($mom{$fam3}{$pgdad_of_id3} eq $mom{$fam3}{$id4}) && ($dad{$fam3}{$pgdad_of_id3} eq $dad{$fam3}{$id4}) ) {
				return "GAV";
			} elsif ( (defined($pgmom_of_id4)) && (defined($mom{$fam3}{$pgmom_of_id4})) && (defined($dad{$fam3}{$pgmom_of_id4})) && (defined($mom{$fam3}{$id3})) && (defined($dad{$fam3}{$id3})) && ($mom{$fam3}{$pgmom_of_id4} eq $mom{$fam3}{$id3}) && ($dad{$fam3}{$pgmom_of_id4} eq $dad{$fam3}{$id3}) ) {
				return "GAV";
			} elsif ( (defined($pgdad_of_id4)) && (defined($mom{$fam3}{$pgdad_of_id4})) && (defined($dad{$fam3}{$pgdad_of_id4})) && (defined($mom{$fam3}{$id3})) && (defined($dad{$fam3}{$id3})) && ($mom{$fam3}{$pgdad_of_id4} eq $mom{$fam3}{$id3}) && ($dad{$fam3}{$pgdad_of_id4} eq $dad{$fam3}{$id3}) ) {
				return "GAV";
			} elsif ( (defined($mgmom_of_id3)) && (defined($mgmom_of_id4)) && (defined($mgdad_of_id3)) && (defined($mgdad_of_id4)) && ($mgmom_of_id3 eq $mgmom_of_id4) && ($mgdad_of_id3 eq $mgdad_of_id4) ) {
				return "FC";
			}  elsif ( (defined($mgmom_of_id3)) && (defined($pgmom_of_id4)) && (defined($mgdad_of_id3)) && (defined($pgdad_of_id4)) && ($mgmom_of_id3 eq $pgmom_of_id4) && ($mgdad_of_id3 eq $pgdad_of_id4) ) {
				return "FC";
			} elsif ( (defined($pgmom_of_id3)) && (defined($mgmom_of_id4)) && (defined($pgdad_of_id3)) && (defined($mgdad_of_id4)) && ($pgmom_of_id3 eq $mgmom_of_id4) && ($pgdad_of_id3 eq $mgdad_of_id4) ) {
				return "FC";
			} elsif ( (defined($pgmom_of_id3)) && (defined($pgmom_of_id4)) && (defined($pgdad_of_id3)) && (defined($pgdad_of_id4)) && ($pgmom_of_id3 eq $pgmom_of_id4) && ($pgdad_of_id3 eq $pgdad_of_id4) ) {
				return "FC";
			} else {
				return "CX";
			}
		} elsif ( ($kc2 > 0.0625) && ($kc2 != 0.5) && ($kc2 != 0.25) && ($kc2 != 0.125) ) {
			return "CX";
		} elsif ($kc2 < 0.0625) {
			return "DR";
		}
	}
}
