#!/usr/bin/perl
# ./marker_subpanels.pl
# By Alejandro Q. Nato, Jr., Ph.D.
# This script (a) selects marker subpanels using a parameter file
# that specifies panel number, direction, starting marker number, 
# max r^2, and MID, and (b) prepares files needed for setup_gl_auto

# 06/12/2013, 09/20/2013
# Modifications: 10/15/2013-07/22/2015



use strict;
use warnings;
use diagnostics;

use Time::HiRes qw( gettimeofday );
use Statistics::Descriptive;

$, = " ";	# set output field separator

my ($line, $line1, $line2, $line3, $line4, $line5) = "";
my (@list, @list1, @list2, @list3, @list4, @list5) = ();
my (@info, @info1, @info2, @info3, @info4, @info5) = ();

my ($line6, $line7, $line8, $line9, $line10) = "";
my (@list6, @list7, @list8, @list9, @list10) = ();
my (@info6, @info7, @info8, @info9, @info10) = ();

my ($line11, $line12, $line13, $line14, $line15) = "";
my (@list11, @list12, @list13, @list14, @list15) = ();
my (@info11, @info12, @info13, @info14, @info15) = ();

my ($line16, $line17, $line18, $line19, $line20) = "";
my (@list16, @list17, @list18, @list19, @list20) = ();
my (@info16, @info17, @info18, @info19, @info20) = ();

my $chr     = $ARGV[0];	# chromosome
my $parfile = $ARGV[1];	# absolute path of parameter file

my ($script, $script1) = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;

if ($#ARGV < 0) {
	$script  = $0;
	$script  =~ s/^(.+)\///g;
	$script  =~ s/^\.\///g;
	$script1 = $script;
	$script1 =~ s/\.pl//g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (June 2013; Sept 2013; updated Oct 2013-Apr 2015)\n\n";
	print "This script (a) selects marker subpanels using a parameter file\n";
	print "that specifies panel number\, direction\, and starting marker number\,\n";
	print "and (b) prepares files needed for setup_gl_auto\n\n";

	print "1) Panel number  : >= 1\n";
	print "2) Direction     : forward (or fwd), reverse (or rev)\n";
	print "3) Marker number : >= 1 (starting from edge of map depending on direction)\n\n";

	print "Before running this script, please install PLINK\n";
	print "   http://pngu.mgh.harvard.edu/purcell/plink/ (Purcell et al. (2007) AJHG, 81).\n\n";

	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script chromosome $script1\_parameter_file*\n";
	print "       *use absolute path\n\n";

	print "Parameter file should contain the following:\n\n";
	print "\tLine  1 - Chromosome(s) that have genotype data\n";
	print "\t             e.g., if there is genotype data for chromosomes 1-22, put \"1-22\"\n";
	print "\t                if there is genotype data for chromosomes 3, 5, and 7, put \"3 5 7\"\n";
	print "\t                or if there is genotype data only for chromosome 3, put \"3\"\n"; 
	print "\tLine  2 - Directory containing marker_subpanels.pl\n";
	print "\t             In certain loops within the script, marker_subpanels.pl moves to different directories\n";
	print "\t                and has to go back to the script directory at the end of the loop\n";
	print "\tLine  3 - Directory for output files\n";
	print "\t             Directory will be created if it does not exist\n";
	print "\t             Under this directory, subdirectories for panel 1 to panel n, main population,\n";
	print "\t                and chromosome will also be created\n";

	print "\tLine  4 - Inclusion filename for SNPs\n";
	print "\t             Format (space-delimited): chromosome, marker, [core|aux]\n";
	print "\t             Use one file across all chromosomes that applies to the entire dataset.\n";
	print "\t             Put \"none\" for this line if you don't have a SNP inclusion file.\n";
	print "\t             Markers indicated in this file will be present in the first panel\n";
	print "\t                unless they are also included in the exclusion file in line 6.\n";
	print "\t             Core inclusion markers will be included again if removed after LD-based SNP pruning\n";
	print "\t                unless they are also included in the exclusion file in line 6.\n";
	print "\t             Aux inclusion markers may still be pruned based on the parameters in lines 6-9\n";
	print "\tLine  5 - Inclusion filename for STRs and minimum distance (cM) from SNPs\n";
	print "\t             Format (space-delimited): inclusion filename, minimum distance\n";
	print "\t             Format of inclusion file (space-delimited): chromosome, marker, genetic location, physical position\n";
	print "\t             Use one file across all chromosomes for the entire dataset.\n";
	print "\t             Put \"none\" for this line if you don't have an STS inclusion file.\n";
	print "\t             STS inclusion markers are always core inclusion markers\n";
	print "\t                and will be present in the first panel\n";
	print "\t                unless they are also included in the exclusion file in line 6.\n";
	print "\tLine  6 - Exclusion filename\n";
	print "\t             Use one file for the entire dataset. Put \"none\" if you don't have an exclusion file.\n";
	print "\t             Format (space-delimited): chromosome, marker\n";
	print "\t             Markers indicated in this file will always be absent in all of the panels generated\n";
	print "\t             This file overrides the inclusion file and any of the parameters in lines 7-11\n";

	print "\tLine  7 - Prepare files for pedigree structure validation (kstat.pl): [Y|N]\n";
	print "\t             If yes, run $script on all chromosomes before running kstat.pl\n";
	print "\t                Note that $script will only prepare one panel per chromosome\n";
	print "\t                Specify one set of sequence of methods in line 14 (others will be ignored)\n";
	print "\t             There will be no gapfilling when you opt to prepare files for kstat.pl\n";
	print "\tLine  8 - Minimum intermarker distance (cM)\n";
	print "\tLine  9 - Marker completion (\%) threshold\n";
	print "\t             Any marker with genotype data less than this threshold will be excluded from the panels\n";
	print "\tLine 10 - Minor allele frequency (MAF) minimum and maximum cut-offs\n";
	print "\t             Format (space-delimited): minimum, maximum\n";
	print "\t             Recommended values: [minimum maximum]\n";
	print "\t                For pedigree structure validation: \"0.3 0.5\"\n";
	print "\t                For linkage analysis: \"0.2 0.5\"\n";
	print "\tLine 11 - Maximum LD threshold\n";
	print "\t             Recommended value:\n";
	print "\t                For pedigree structure validation: \"0.25\"\n";
	print "\t                For linkage analysis: \"0.04\" or \"0.01\"\n";
	print "\tLine 12 - Exclude monomorphic markers: [Y|N]\n";
	print "\t             By default, markers that are monomorphic will be excluded\. If these markers actually have\n";
	print "\t             very low MAFs and only happen to be monomorphic in this dataset due to small sample size\n";
	print "\t             and you want to keep some of them, include these markers in one the inclusion files in lines 4-5\n";
	print "\tLine 13 - Number of subpanels (n)\n";
	print "\t             Specify the number of subpanels that you want to generate\n";
	print "\t             For pedigree structure validation, one subpanel will be created\n";
	print "\t             For linkage analysis, we recommend a minimum of three subpanels\n";
	print "\tLine 14 - Sequence of methods for each subpanel specified in line 13\n";
	print "\t             Format (space-delimited):\n";
	print "\t             subpanel number, direction, marker number (main panel), marker number (pre-subpanel)\n";
	print "\t             e.g., \"1 fwd 1 1\" means \"for subpanel 1\, use forward direction\,\n";
	print "\t                   start at marker 1 on main panel\, and start at marker 1 on pre-subpanel\"\n";
	print "\t             Separate sequence of methods between panels by a \"\ | \"\n";
	print "\tLine 15 - Path of PLINK that will be used (e.g., /usr/bin/plink or /home/username/bin/plink)\n";
	
	print "\tLine 16 - Directory containing reference files (e.g., 1000 Genomes Project files)\n";
	print "\t             If you intend to use your own reference files, put subfolders for\n";
	print "\t             the AFR, AMR, ASN, and EUR populations under this directory prior to running $script\n";
	print "\tLine 17 - Population: [AFR|AMR|ASN|EUR]\n";
	
	print "\tLine 18 - Directory containing map files\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 19 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where map files are located\n";
	print "\tLine 20 - [(prefix=)(suffix)] of chromosome number in input map filenames\n";
	print "\t             e.g., if if your files are named chr*-map.txt, put \"prefix=chr suffix=-map.txt\"\n";
	print "\tLine 21 - Input map file has a header or not: header=[T|F]\n";

	print "\tLine 22 - Directory containing pedigree files\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 23 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where pedigree files are located\n";
	print "\tLine 24 - [(prefix=)(suffix)] of chromosome number in input pedigree filenames\n";
	print "\t             e.g., if if your files are named chr*-ped.txt, put \"prefix=chr suffix=-ped.txt\"\n";
	print "\tLine 25 - Input pedigree file has a header or not: header=[T|F]\n";

	print "\tLine 26 - Directory containing genotype data\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 27 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where genotype files are located\n";
	print "\tLine 28 - [(prefix=)(suffix)] of chromosome number in input genotype filenames\n";
	print "\t             e.g., if if your files are named chr*-geno.txt, put \"prefix=chr suffix=-geno.txt\"\n";
	print "\tLine 29 - Input genotype file has a header or not: header=[T|F]\n";
	print "\tLine 30 - Option: [1|2] for input file(s) containing IDs of genotyped individuals\n";
	print "\t             1: Use output files of transpose_fileset.pl\n";
	print "\t             2: Use a file containing the list of genotyped individuals (supplied by user)\n";
	print "\t             If you chose option 2, line 31 should contain the absolute path of input file\n";
	print "\t             and leave lines 32-34 blank.\n";
	print "\tLine 31 - If option 1 was chosen in line 30,\n";
	print "\t             indicate directory containing files with IDs of genotyped individuals\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\t          If option 2 was chosen in line 30,\n";
	print "\t             indicate input file containing list of IDs of genotyped individuals (absolute path)\n";
	print "\tLine 32 - [(prefix=)(suffix)] of chromosome number in names of subdirectories where files with\n";
	print "\t             IDs of genotyped individuals are located\n";
	print "\tLine 33 - [(prefix=)(suffix)] of chromosome number in files containing IDs of genotyped individuals\n";
	print "\t             e.g., if if your files are named chr*-ind.txt, put \"prefix=chr suffix=-ind.txt\"\n";
	print "\tLine 34 - Input file containing IDs of genotyped individuals has a header or not: header=[T|F]\n";

	print "\tNotes: 1) Blank lines and lines that start with a pound sign (#) will be ignored\n";
	print "\t       2) Use absolute paths for all directories and filenames unless specified otherwise\n";
	print "\t       3) To avoid mismatching, all individual IDs should be concatenated with family IDs,\n";
	print "\t             e.g., \"FamilyID.IndividualID\" or \"FamilyID_IndividualID\"\n";
	print "\t       4) For subdirectories in lines 19, 23, 27, and 32, if files in lines 20, 24, 28, and 33 are\n";
	print "\t             directly under the directories in lines 18, 22, 26, and 31, respectively, put \"no dir\"\n";
	print "\t             Examples (if subdirectories are present):\n";
	print "\t             If subdirectories are named chr*, put \"prefix=chr suffix=none\"\n";
	print "\t             If subdirectories are named chr*geno, put \"prefix=chr suffix=geno\"\n";
	print "\t       5) Phenotype information at this point will be coded as missing\n";
	print "\t       6) Lines 18-21, 22-25, and 26-34 are for the map, pedigree, and genotype files, respectively\n\n";
	exit;
}
##########
my ($count, $count1, $count2, $count3, $count4) = 0;
my ($mindist, $stsdist, $markcompt, $npanels, $markcomp, $mafrange, $mafmin, $mafmax) = 0;
my ($inclusnp, $inclusts, $inclustsfile, $exclu, $kstatprep, $start, $exclumono, $mono, $methods, $plink) = "";
my ($mapname, $mappre, $mapsuf, $mapin) = "";
my ($pedname, $pedpre, $pedsuf, $pedin) = "";
my ($option, $genoname, $genopre, $genosuf, $genoin) = "";
my ($idname, $idpre, $idsuf, $idin) = "";
my ($oneKGdir, $popn) = "";
my ($mainmdir, $mapdir, $mapdirpre, $mapdirsuf, $mapdirin) = "";
my ($mainpdir, $peddir, $peddirpre, $peddirsuf, $peddirin) = "";
my ($maingdir, $genodir, $genodirpre, $genodirsuf, $genodirin) = "";
my ($mainidir, $iddir, $iddirpre, $iddirsuf, $iddirin, $outdir, $scriptdir) = "";
my ($mapfdir, $mapfile, $maph, $pedfdir, $pedfile, $pedh) = "";
my ($genofdir, $genofile, $genoh, $idfdir, $idfile, $idh) = "";
my ($tfamfile, $tpedfile, $tfile) = "";
my ($chrA, $chrs, $chre, $i, $j, $k, $nummarker, $r2max) = 0;
my ($famid, $subid) = "";
my (@idin, @method, @method2) = ();
my (%freq, %nummrkr, %imgeno) = ();

open (IN1, "<$parfile") || die ("Could not open $parfile!\n");
@list1 = <IN1>;
close (IN1);
print "\nThese are the parameters that you specified:\n";
foreach $line1 (@list1) {
	chomp $line1;
	next if ($line1 =~ m/^\#/);
	next if ( ($line1 =~ m/\t|\#/) && ( ($line1 =~ m/line|:|\"|\=/i) || ($line1 !~ m/\d/)) );
	next if (length($line1) == 0);
	$line1 =~ s/^\s+//g;
	$line1 =~ s/\s+$//g;
	$count++;
	print "line $count: $line1\n";
	if    ($count == 1) { $chrA       = $line1; }
	elsif ($count == 2) { $scriptdir  = $line1; }
	elsif ($count == 3) { $outdir     = $line1; }
	elsif ($count == 4) { $inclusnp   = $line1; }
	elsif ($count == 5) { $inclusts   = $line1; }
	elsif ($count == 6) { $exclu      = $line1; }
	elsif ($count == 7) { $kstatprep  = $line1; }
	elsif ($count == 8) { $mindist    = $line1; }
	elsif ($count == 9) { $markcompt  = $line1; }
	elsif ($count == 10) { $mafrange   = $line1; }
	elsif ($count == 11) { $r2max     = $line1; }
	elsif ($count == 12) { $exclumono = $line1; }
	elsif ($count == 13) {
		$npanels   = $line1; 
		if ( ($kstatprep eq "Y") && ($npanels > 1) ) {
			print "\tYou specified generation of $npanels panels but since this is for kstat\.pl\,\n";
			print "\t   we will only generate 1 panel\n";
			$npanels = 1;
		}
	}
	elsif ($count == 14) { $methods   = $line1; }
	elsif ($count == 15) { $plink     = $line1; }
	
	elsif ($count == 16) { $oneKGdir  = $line1; }
	elsif ($count == 17) { $popn      = $line1; }
	
	elsif ($count == 18) { $mainmdir  = $line1; }
	elsif ($count == 19) { $mapdir    = $line1; }
	elsif ($count == 20) { $mapname   = $line1; }
	elsif ($count == 21) { $maph      = $line1; }

	elsif ($count == 22) { $mainpdir  = $line1; }
	elsif ($count == 23) { $peddir    = $line1; }
	elsif ($count == 24) { $pedname   = $line1; }
	elsif ($count == 25) { $pedh      = $line1; }

	elsif ($count == 26) { $maingdir  = $line1; }
	elsif ($count == 27) { $genodir   = $line1; }
	elsif ($count == 28) { $genoname  = $line1; }
	elsif ($count == 29) { $genoh     = $line1; }
	elsif ($count == 30) { $option    = $line1; }
	elsif ( (defined($option)) && ($option == 1) ) {
		if ($count == 31) { $mainidir = $line1; }
		elsif ($count == 32)  { $iddir = $line1; }
		elsif ($count == 33) { $idname = $line1; }
		elsif ($count == 34) { $idh    = $line1; }
	} elsif ( (defined($option)) && ($option == 2) ) {
		if    ($count == 31)  { $idin  = $line1; }
	}
}
print "\n";
if ($mainmdir =~ m/\/$/) { chop $mainmdir; }
if ($mainpdir =~ m/\/$/) { chop $mainpdir; }
if ($maingdir =~ m/\/$/) { chop $maingdir; }
if ( (defined($mainidir)) && ($mainidir =~ m/\/$/) ) { chop $mainidir; }
if ($outdir =~ m/\/$/)   { chop $outdir; }

if (! -e $outdir) {
	`mkdir -p $outdir`;
}

my $log  = $outdir."/marker_subpanels_$popn\_chr$chr\.log";

open (LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "################################################################################\n";
print LOG "#                           PBAP marker_subpanels.pl                           #\n";
print LOG "#                            Alejandro Q. Nato, Jr.                            #\n";
print LOG "#                           Statistical Genetics Lab                           #\n";
print LOG "#                    University of Washington, Seattle, WA                     #\n";
print LOG "################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

my @chrA = ();
if ($chrA =~ m/\-/) {
	($chrs, $chre) = split (/\-/, $chrA);
	my $i = 0;
	for ($i = $chrs; $i <= $chre; $i++) {
		push (@chrA, $i);
	}
} elsif ($chrA =~ m/\s+/) {
	@chrA = split (/\s+/, $chrA);
} else {
	$chrs = $chre = $chrA;
	push (@chrA, $chrA);
}

print LOG "Command-line arguments used: $chr$,$parfile\n\n";

print LOG "PARAMETERS SPECIFIED:\n";
# Map file
if ($mapdir eq "no dir") {
	# Map files are directly under mainmdir
	$mapfdir = $mainmdir;
} else {
	if ($mapdir =~ m/prefix\=(.+)\s+/) {
		# mapdir has a prefix
		$mapdirpre = $1;
		if ($mapdirpre eq "none") { $mapdirpre = ""; }
	} elsif ($mapdir !~ m/prefix\=(.+)\s+/) {
		$mapdirpre = "";
	}
	if ($mapdir =~ m/suffix\=(.+)/) {
		# mapdir has a suffix
		$mapdirsuf = $1;
		if ($mapdirsuf eq "none") { $mapdirsuf = ""; }
	} elsif ($mapdir !~ m/suffix\=(.+)/) {
		$mapdirsuf = "";
	}
	$mapfdir = $mainmdir . "/" . $mapdirpre . $chr . $mapdirsuf;
}
if ($mapname =~ m/prefix\=(.+)\s+/) {
	# mapname has a prefix
	$mappre = $1;
	if ($mappre eq "none") { $mappre = ""; }
} elsif ($mapname !~ m/prefix\=(.+)\s+/) {
	$mappre = "";
}
if ($mapname =~ m/suffix\=(.+)/) {
	# mapname has a suffix
	$mapsuf = $1;
	if ($mapsuf eq "none") { $mapsuf = ""; }
} elsif ($mapname !~ m/suffix\=(.+)/) {
	$mapsuf = "";
}
$mapfile = $mapfdir . "/" . $mappre . $chr . $mapsuf;
print "Map file : $mapfile\n";
print LOG "Map file                     : $mapfile\n";

# Pedigree file
if ($peddir eq "no dir") {
	# Pedigree files are directly under mainpdir
	$pedfdir = $mainpdir;
} else {
	if ($peddir =~ m/prefix\=(.+)\s+/) {
		# peddir has a prefix
		$peddirpre = $1;
		if ($peddirpre eq "none") { $peddirpre = ""; }
	} elsif ($peddir !~ m/prefix\=(.+)\s+/) {
		$peddirpre = "";
	}
	if ($peddir =~ m/suffix\=(.+)/) {
		# peddir has a suffix
		$peddirsuf = $1;
		if ($peddirsuf eq "none") { $peddirsuf = ""; }
	} elsif ($peddir !~ m/suffix\=(.+)/) {
		$peddirsuf = "";
	}
	$pedfdir = $mainpdir . "/" . $peddirpre . $chr . $peddirsuf;
}
if ($pedname =~ m/prefix\=(.+)\s+/) {
	# pedname has a prefix
	$pedpre = $1;
	if ($pedpre eq "none") { $pedpre = ""; }
} elsif ($pedname !~ m/prefix\=(.+)\s+/) {
	$pedpre = "";
}
if ($pedname =~ m/suffix\=(.+)/) {
	# pedname has a suffix
	$pedsuf = $1;
	if ($pedsuf eq "none") { $pedsuf = ""; }
} elsif ($pedname !~ m/suffix\=(.+)/) {
	$pedsuf = "";
}
$pedfile = $pedfdir . "/" . $pedpre . $chr . $pedsuf;
print "Pedigree file : $pedfile\n";
print LOG "Pedigree file                : $pedfile\n";

if ($genodir eq "no dir") {
	# Genotype files are directly under maingdir
	$genofdir = $maingdir;
} elsif ($genodir ne "no dir") {
	if ($genodir eq "none") {
		$genodirpre = "";
		$genodirsuf = "";
	} elsif ($genodir =~ m/prefix\=(.+) suffix\=(.+)/) {
		$genodirpre = $1;
		$genodirsuf = $2;
		if ($genodirpre eq "none") { $genodirpre = ""; }
		if ($genodirsuf eq "none") { $genodirsuf = ""; }
	} elsif ( ($genodir =~ m/prefix\=(.+)/) && ($genodir !~ m/suffix\=(.+)/) ) {
		$genodirpre = $1;
		$genodirsuf = "";
		if ($genodirpre eq "none") { $genodirpre = ""; }
	} elsif ( ($genodir !~ m/prefix\=(.+)/) && ($genodir =~ m/suffix\=(.+)/) ) {
		$genodirpre = "";
		$genodirsuf = $1;
		if ($genodirsuf eq "none") { $genodirsuf = ""; }
	}
	$genofdir = $maingdir . "/" . $genodirpre . $chr . $genodirsuf;
}
if ($genoname =~ m/prefix\=(.+) suffix\=(.+)/) {
	$genopre = $1;
	$genosuf = $2;
	if ($genopre eq "none") { $genopre = ""; }
	if ($genosuf eq "none") { $genosuf = ""; }
} elsif ( ($genoname =~ m/prefix\=(.+)/) && ($genoname !~ m/suffix\=(.+)/) ) {
	$genopre = $1;
	$genosuf = "";
	if ($genopre eq "none") { $genopre = ""; }
} elsif ( ($genoname !~ m/prefix\=(.+)/) && ($genoname =~ m/suffix\=(.+)/) ) {
	$genopre = "";
	$genosuf = $1;
	if ($genosuf eq "none") { $genosuf = ""; }
}
$genofile = $genofdir . "/" . $genopre . $chr . $genosuf;
print "Genotype file : $genofile\n";
print LOG "Genotype file                : $genofile\n";

if ($option == 1) {
	# Compare all individual ID files per chromosome and use the IDs that are
	# present across all chromosomes
	if ($iddir eq "no dir") {
		# ID files are directly under mainidir
		$idfdir = $mainidir;
	} elsif ($iddir ne "no dir") {
		if ($iddir eq "none") {
			$iddirpre = "";
			$iddirsuf = "";
		} elsif ($iddir =~ m/prefix\=(.+) suffix\=(.+)/) {
			$iddirpre = $1;
			$iddirsuf = $2;
			if ($iddirpre eq "none") { $iddirpre = ""; }
			if ($iddirsuf eq "none") { $iddirsuf = ""; }
		} elsif ( ($iddir =~ m/prefix\=(.+)/) && ($iddir !~ m/suffix\=(.+)/) ) {
			$iddirpre = $1;
			$iddirsuf = "";
			if ($iddirpre eq "none") { $iddirpre = ""; }
		} elsif ( ($iddir !~ m/prefix\=(.+)/) && ($iddir =~ m/suffix\=(.+)/) ) {
			$iddirpre = "";
			$iddirsuf = $1;
			if ($iddirsuf eq "none") { $iddirsuf = ""; }
		}
		$idfdir = $mainidir . "/" . $iddirpre . $chr . $iddirsuf;
	}
	if ($idname =~ m/prefix\=(.+) suffix\=(.+)/) {
		$idpre = $1;
		$idsuf = $2;
		if ($idpre eq "none") { $idpre = ""; }
		if ($idsuf eq "none") { $idsuf = ""; }
	} elsif ( ($idname =~ m/prefix\=(.+)/) && ($idname !~ m/suffix\=(.+)/) ) {
		$idpre = $1;
		$idsuf = "";
		if ($idpre eq "none") { $idpre = ""; }
	} elsif ( ($idname !~ m/prefix\=(.+)/) && ($idname =~ m/suffix\=(.+)/) ) {
		$idpre = "";
		$idsuf = $1;
		if ($idsuf eq "none") { $idsuf = ""; }
	}
	$idfile = $idfdir . "/" . $idpre . $chr . $idsuf;
	print "IDs of genotyped individuals : $idfile\n";
	print LOG "IDs of genotyped individuals : $idfile\n";
	print "Path of plink: $plink\n";
	print LOG "Path of plink                : $plink\n";
	
	# Check individual ID files now
	(@list2, @idin) = ();
	%freq = ();
	my $numchr = scalar(@chrA);
	print "\n$npanels marker subpanel\(s\) for chromosome $chr will be created\n";
	print "Sequence of methods          : ";
	print LOG "\n$npanels marker subpanel\(s\) for chromosome $chr will be created\n";
	print LOG "Sequence of methods          : ";
	@method2 = ();
	@method = split (/\|/, $methods);
	for ($j = 0; $j < $npanels; $j++) {
		$method[$j] =~ s/^\s+//g;
		$method[$j] =~ s/\s+$//g;
		push (@method2, $method[$j]);
	}
	print join (" | ", @method2);
	print "\n";
	print "Prepare files for kstat.pl   : $kstatprep\n";
	print "Minimum intermarker distance : $mindist cM\n";
	print "Marker completion threshold  : $markcompt\%\n";
	print "MAF (minimum and maximum)    : $mafrange\n";
	print LOG join (" | ", @method2);
	print LOG "\n";
	print LOG "Prepare files for kstat.pl   : $kstatprep\n";
	print LOG "Minimum intermarker distance : $mindist cM\n";
	print LOG "Marker completion threshold  : $markcompt\%\n";
	print LOG "MAF (minimum and maximum)    : $mafrange\n";
	if ($numchr > 1) {
		print "Checking if individual IDs specified in $idpre" . $chr . "$idsuf are present in ID files for " . join (" ", @chrA) . "\...\n";
	} elsif ($numchr == 1) {
		# do nothing
	}
	foreach $i (@chrA) {
		my $idftemp = "";
		if ($iddir eq "no dir") {
			$idftemp = $idfdir . "/" . $idpre . $i . $idsuf;
		} else {
			$idftemp = $mainidir . "/" . $iddirpre . $i . $iddirsuf . "/" . $idpre . $i . $idsuf;
		}
		open (IN2, "<$idftemp") || die ("Could not open $idftemp file!\n");
		@list2 = <IN2>;
		close (IN2);
		foreach $line2 (@list2) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if (length ($line2) == 0);
			$freq{$line2}++;
		}
	}
	# Use the last list2 to check the individual IDs that are present in all ID files
	my $iderr = 0;
	foreach $line2 (@list2) {
		chomp $line2;
		$line2 =~ s/^\s+//g;
		$line2 =~ s/\s+$//g;
		next if (length ($line2) == 0);
		if ($freq{$line2} == $numchr) {
			push (@idin, $line2);
		} elsif ($freq{$line2} < $numchr) {
			print "Check ID of individual $line2 in one of the ID files\n";
			$iderr++;
		}
	}

	if ($iderr == 0) {
		print "  Individual IDs are present in all ID files\n";
	}
} elsif ($option == 2) {
	# Use the file supplied by the user as the $idin
	print "IDs of genotyped individuals : $idin\n";
	print LOG "IDs of genotyped individuals     : $idin\n";
	print "Path of plink: $plink\n";
	print LOG "Path of plink                : $plink\n";

	# Check individual ID files now
	%freq = ();
	print "\n$npanels marker subpanel\(s\) for chromosome $chr will be created\n";
	print "Sequence of methods          : ";
	print LOG "\n$npanels marker subpanel\(s\) for chromosome $chr will be created\n";
	print LOG "Sequence of methods          : ";
	@method2 = ();
	@method = split (/\|/, $methods);
	for ($j = 0; $j < $npanels; $j++) {
		$method[$j] =~ s/^\s+//g;
		$method[$j] =~ s/\s+$//g;
		push (@method2, $method[$j]);
	}
	print join (" | ", @method2);
	print "\n";
	print "Prepare files for kstat.pl   : $kstatprep\n";
	print "Minimum intermarker distance : $mindist cM\n";
	print "Marker completion threshold  : $markcompt\%\n";
	print "MAF (minimum and maximum)    : $mafrange\n";
	print LOG join (" | ", @method2);
	print LOG "\n";
	print LOG "Prepare files for kstat.pl   : $kstatprep\n";
	print LOG "Minimum intermarker distance : $mindist cM\n";
	print LOG "Marker completion threshold  : $markcompt\%\n";
	print LOG "MAF (minimum and maximum)    : $mafrange\n";

	(@list2, @idin) = ();
	open (IN2, "<$idin") || die ("Could not open $idin file!\n");
	@list2 = <IN2>;
	close (IN2);
	foreach $line2 (@list2) {
		chomp $line2;
		$line2 =~ s/^\s+//g;
		$line2 =~ s/\s+$//g;
		next if (length ($line2) == 0);
		push (@idin, $line2);
	}
	$idfile = $idin;
	$idh    = "F";
}

print LOG "Output directory             : $outdir\n\n";

print LOG "LOG:\n\n";
##########
# Before proceeding, check input files to see if something is far from matching each other
my ($indiv_tpedo, $mrkr_tmap, $indiv_tgen, $mrkr_tgen) = 0;
$indiv_tpedo  = `wc -l $pedfile | cut -d " " -f 1`;
$mrkr_tmap   = `wc -l $mapfile | cut -d " " -f 1`;
$indiv_tgen  = `awk '{FS=" "}{if (NR==1) print NF }' $genofile`;
$mrkr_tgen  = `wc -l $genofile | cut -d " " -f 1`;
if ($pedh =~ m/T/i) {
	$indiv_tpedo -= 1;
}
if ($maph =~ m/T/i) {
	$mrkr_tmap -= 1;
}
if ($genoh =~ m/T/i) {
	$mrkr_tgen -= 1;
}
chomp $indiv_tpedo;
chomp $mrkr_tmap;
chomp $mrkr_tgen;
$indiv_tgen = ($indiv_tgen - 2) / 2;


print "\n";
print "Individuals in input pedigree file ($pedfile): $indiv_tpedo\n";
print "Markers in input map file ($mapfile): $mrkr_tmap\n";
print "Individuals in input genotype file ($genofile): $indiv_tgen\n";
print "Markers in input genotype file ($genofile): $mrkr_tgen\n\n";

print LOG "Individuals in input pedigree file ($pedfile): $indiv_tpedo\n";
print LOG "Markers in input map file ($mapfile): $mrkr_tmap\n";
print LOG "Individuals in input genotype file ($genofile): $indiv_tgen\n";
print LOG "Markers in input genotype file ($genofile): $mrkr_tgen\n\n";

# Make sure that genotyped individuals >= total number of individuals
if ($indiv_tgen <= $indiv_tpedo) {
	# OK proceed
	print "Number of genotyped individuals is less than or equal to the number of individuals in pedigree file...OK\n";
	print LOG "Number of genotyped individuals is less than or equal to the number of individuals in pedigree file...OK\n";
} elsif ($indiv_tgen > $indiv_tpedo) {
	# Alert user
	print "Check genotype file since number of genotyped individuals is greater than the number of individuals in pedigree file\n";
	print LOG "Check genotype file since number of genotyped individuals is greater than the number of individuals in pedigree file\n";
	close (LOG);
	exit;
}
if ($mrkr_tgen == $mrkr_tmap) {
	# OK proceed
	print "Number of markers in genotype file is equal to the number of markers in map file...OK\n";
	print LOG "Number of markers in genotype file is equal to the number of markers in map file...OK\n\n";
} elsif ($mrkr_tgen < ($mrkr_tmap * 0.90)) {
	# Alert user
	print "Check genotype file since number of markers in genotype file is less than 90% of markers in map file\n";
	print LOG "Check genotype file since number of markers in genotype file is less than 90% of markers in map file\n";
	close (LOG);
	exit;
}

##########
my (%include, %exclude, %chrinc, %chrexc, %categ, %type) = ();
my ($incchr, $incmarker, $inccateg, $excchr, $excmarker) = "";
my ($incgloc, $incppos) = 0;

# Create hashes
@list2 = ();
if ($inclusnp !~ m/none/i) {
	open (IN2A, "<$inclusnp") || die ("Could not open $inclusnp file!\n");
	@list2 = <IN2A>;
	close (IN2A);
	print "SNPs that will be included:\n";
	print LOG "SNPs that will be included:\n";
	foreach $line2 (@list2) {
		chomp $line2;
		$line2 =~ s/^\s+//g;
		$line2 =~ s/\s+$//g;
		next if (length($line2) == 0);
		($incchr, $incmarker, $inccateg) = split (" ", $line2);
		if ($incchr == $chr) {
			$include{$incmarker} = 1;
			$chrinc{$incmarker} = $incchr;
			$categ{$incmarker} = $inccateg;
			$type{$incchr}{$incmarker} = "SNP";
			print "  $incchr $incmarker $inccateg $type{$incchr}{$incmarker}\n";
			print LOG "  $incchr $incmarker $inccateg $type{$incchr}{$incmarker}\n";
		} elsif ($incchr != $chr) {
			next;
		}
	}
}
@list2 = ();
my (%mrkr8, %ppos8, %gloc8, %matchKGppos, %KGmarker, %nogenloc) = ();
if ($inclusts !~ m/none/i) {
	($inclustsfile, $stsdist) = split (/\s+/, $inclusts);
	open (IN2B, "<$inclustsfile") || die ("Could not open $inclustsfile file!\n");
	@list2 = <IN2B>;
	close (IN2B);
	print "STS markers that will be included:\n";
	print LOG "STS markers that will be included:\n";
	foreach $line2 (@list2) {
		chomp $line2;
		$line2 =~ s/^\s+//g;
		$line2 =~ s/\s+$//g;
		next if (length($line2) == 0);
		($incchr, $incmarker, $incgloc, $incppos) = split (" ", $line2);
		$inccateg = "core";

		if (!defined($incgloc)) { $incgloc = ""; }
		if (!defined($incppos)) { $incppos = ""; }
		if ($incchr == $chr) {
			if ( ($incgloc =~ m/NA/) || ($incgloc =~ m/\-9/) || ($incgloc eq "") ) {
				# Skip this marker
				print "  We cannot include $incmarker as a core inclusion STS marker since it has no genetic location\n";
				print LOG "  We cannot include $incmarker as a core inclusion STS marker since it has no genetic location\n";
				next;
			} else {
				$incgloc = sprintf ("%.6f", $incgloc);
			}
			$include{$incmarker} = 1;
			$chrinc{$incmarker} = $incchr;
			$categ{$incmarker} = $inccateg;
		
			$gloc8{$incchr}{$incmarker} = $incgloc;
			$ppos8{$incchr}{$incmarker} = $incppos;
			$mrkr8{$incchr}{$incgloc} = $incmarker;
			$mrkr8{$incchr}{$incppos} = $incmarker;
			$type{$incchr}{$incmarker} = "STS";
		
			print "  $incchr $incmarker $inccateg $type{$incchr}{$incmarker}\n";
			print LOG "  $incchr $incmarker $inccateg $type{$incchr}{$incmarker}\n";
		} elsif ($incchr != $chr) {
			next;
		}
	}
}
if ($exclu !~ m/none/i) {
	open (IN3, "<$exclu") || die ("Could not open $exclu file!\n");
	@list3 = <IN3>;
	close (IN3);
	print "Markers that will be excluded (overrides inclusion file):\n";
	print LOG "Markers that will be excluded (overrides inclusion file):\n";
	foreach $line3 (@list3) {
		chomp $line3;
		$line3 =~ s/^\s+//g;
		$line3 =~ s/\s+$//g;
		next if (length($line3) == 0);
		($excchr, $excmarker) = split (" ", $line3);
		$exclude{$excmarker} = 1;
		$chrexc{$excmarker} = $excchr;
		if (defined($include{$excmarker})) {
			if ( ($include{$excmarker} == 1) && ($chrexc{$excmarker} == $chr) ) {
				print "  $excchr $excmarker \(marker inclusion overridden\)\n";
				print LOG "  $excchr $excmarker \(marker inclusion overridden\)\n";
			}
		} elsif ($chrexc{$excmarker} == $chr) {
			print "  $excchr $excmarker\n";
			print LOG "  $excchr $excmarker\n";
		}
	}
}

# Get minimum and maximum cut-offs for MAF
($mafmin, $mafmax) = split (" ", $mafrange);
if ($mafmax > $mafmin) {
	if ($mafmin >= 0.5) {
		print "Cut-off specified for minimum MAF ($mafmin) is too high\n";
		print "   change it to a lower value\n";
		print LOG "Cut-off specified for minimum MAF ($mafmin) is too high\n";
		print LOG "   change it to a lower value\n";
		close (LOG);
		exit;
	}
} elsif ($mafmin > $mafmax) {
	print "Since MAF min ($mafmin) is greater than max ($mafmax)\,\n";
	print "   we will swap the two values: min\=$mafmax max\=$mafmin\n";
	print LOG "Since MAF min ($mafmin) is greater than max ($mafmax)\,\n";
	print LOG "   we will swap the two values: min\=$mafmax max\=$mafmin\n";
	my $maftemp = $mafmax;
	$mafmax = $mafmin;
	$mafmin = $maftemp;
	if ($mafmin >= 0.5) {
		print "Cut-off specified for minimum MAF ($mafmin) is too high\n";
		print "   change it to a lower value\n";
		print LOG "Cut-off specified for minimum MAF ($mafmin) is too high\n";
		print LOG "   change it to a lower value\n";
		close (LOG);
		exit;
	}
} elsif ($mafmin == $mafmax) {
	if ($mafmin < 0.5) {
		print "Since you specified equal values for minimum and maximum cut-offs,\n";
		print "   we will set these values as the minimum value\n";
		print "   and the maximum value will be 0.5\n";
		print LOG "Since you specified equal values for minimum and maximum cut-offs,\n";
		print LOG "   we will set these values as the minimum value\n";
		print LOG "   and the maximum value will be 0.5\n";
		$mafmax = 0.5;
	} elsif ($mafmin >= 0.5) {
		print "Cut-off specified for minimum MAF ($mafmin) is too high\n";
		print "   change it to a lower value\n";
		print LOG "Cut-off specified for minimum MAF ($mafmin) is too high\n";
		print LOG "   change it to a lower value\n";
		close (LOG);
		exit;
	}
}
$mafmin += 0;
$mafmax += 0;


### We will use -9 for phenotype just for PLINK tfam file
($count1, $count2, $count3, $count4) = 0;
# Map file (count1 header)
open (IN4, "<$mapfile") || die ("Could not open $mapfile file!\n");
@list4 = <IN4>;
close (IN4);
my ($chr4, $genloc4, $phypos4) = 0;
my $marker4 = "";
my (%genloc, %phypos) = ();
foreach $line4 (@list4) {
	chomp $line4;
	$line4 =~ s/^\s+//g;
	$line4 =~ s/\s+$//g;
	next if (length($line4) == 0);
	$count1++;
	next if ( ($maph =~ m/T/) && ($count1 == 1) );
	($chr4, $marker4, $genloc4, $phypos4) = split (/\t|\s+/, $line4);
	if (!defined($genloc4)) { $genloc4 = ""; }
	if (!defined($phypos4)) { $phypos4 = ""; }
	$genloc{$chr4}{$marker4} = $genloc4;
	$phypos{$chr4}{$marker4} = $phypos4;
}
# Pedigree file (count2 header)
open (IN5, "<$pedfile") || die ("Could not open $pedfile file!\n");
@list5 = <IN5>;
close (IN5);
my ($famid5, $subid5, $dadid5, $momid5, $sex5) = "";
my (%dad, %mom, %sex) = ();
foreach $line5 (@list5) {
	chomp $line5;
	$line5 =~ s/^\s+//g;
	$line5 =~ s/\s+$//g;
	next if (length($line5) == 0);
	$count2++;
	next if ( ($pedh =~ m/T/) && ($count2 == 1) );
	($famid5, $subid5, $dadid5, $momid5, $sex5) = split (/\t|\s+/, $line5);
	$dad{$subid5} = $dadid5;
	$mom{$subid5} = $momid5;
	$sex{$subid5} = $sex5;
}
# Genotype file (count3 header) - dataset
open (IN6, "<$genofile") || die ("Could not open $genofile file!\n");
@list6 = <IN6>;
close (IN6);
my ($marker6, $geno6, $famid7, $subid7, $id7, $maf2, $obshet2, $count2_1, $count2_2, $A1_data, $A2_data) = "";
my @geno6 = ();
my $chr6 = 0;
my (%idgen, %markgen, %markcomp, %mono, %maf2, %exphet2, %obshet2, %A1_data, %A2_data, %nogeno) = ();
foreach $line6 (@list6) {
	chomp $line6;
	$line6 =~ s/^\s+//g;
	$line6 =~ s/\s+$//g;
	next if (length($line6) == 0);
	$count3++;
	next if ( ($genoh =~ m/T/) && ($count3 == 1) );
	@geno6 = ();
	($chr6, $marker6, $geno6) = split (/\t|\s+/, $line6, 3);
	$markgen{$chr6}{$marker6} = $geno6;
	$markcomp = sprintf ("%.2f", marker_completion($geno6));
	$markcomp{$chr6}{$marker6} = $markcomp;
	
	# Exclude marker if all missing
	if ( ($geno6 =~ m/\-|0/) && ($geno6 !~ m/A|C|G|T|1|2/i) ) {
		$nogeno{$marker6}++;
		$nogeno{$phypos{$chr6}{$marker6}}++;
		next;
	}
	
	$mono = check_monomorphic($geno6);
	$mono{$chr6}{$marker6} = $mono;
	($maf2, $obshet2, $count2_1, $count2_2, $A1_data, $A2_data) = split (/\s/, MAF($geno6));
	
	$maf2{$chr6}{$marker6} = sprintf ("%.6f", $maf2);
	$obshet2{$chr6}{$marker6} = sprintf ("%.6f", $obshet2);
	my $exphet2 = sprintf ("%.6f", 1 - (($maf2**2) + ((1-$maf2)**2)));
	$exphet2{$chr6}{$marker6} = $exphet2;
	$A1_data{$chr6}{$marker6} = $A1_data;
	$A2_data{$chr6}{$marker6} = $A2_data;
	@geno6 = split (/\t|\s+/, $geno6);
	
	my ($a1, $a2, $count6) = 0;
	my ($geno6a, $geno6b, $idgeno) = "";
	
	# ID file (count4 header)
	open (IN7, "<$idfile") || die ("Could not open $idfile file!\n");
	@list7 = <IN7>;
	close (IN7);
	foreach $line7 (@list7) {
		chomp $line7;
		$line7 =~ s/^\s+//g;
		$line7 =~ s/\s+$//g;
		next if (length($line7) == 0);
		$count4++;
		next if ( ($idh =~ m/T/) && ($count4 == 1) );
		$id7 = $line7;
		($famid7, $subid7) = split (/\_|\./, $id7);
		$count6 = $count4 - 1;
		
		$a1 = ($count6*2);
		$a2 = ($count6*2) + 1;
		if ( (defined($geno6[$a1])) && (defined($geno6[$a1])) ) {
			$geno6a = $geno6[$a1];
			$geno6b = $geno6[$a2];
			$idgeno = $geno6a." ".$geno6b;
			$idgen{$id7}{$marker6} = $idgeno;
			$count6++;
		}
	}
	($a1, $a2, $count6) = 0;
}

($count1, $count2, $count3, $count4) = 0;
# Convert tmap and tgen to tped; place under outdir
# Remove all markers that are in the exclusion file
# Chromosome, Marker, Genetic Location, Physical Position, Genotypes
$tpedfile = "$outdir\/chr$chr\.tped";
open (OUT1, ">$tpedfile") || die ("Could not create $tpedfile file!\n");
foreach $line4 (@list4) {
	chomp $line4;
	$line4 =~ s/^\s+//g;
	$line4 =~ s/\s+$//g;
	next if (length($line4) == 0);
	$count1++;
	next if ( ($maph =~ m/T/) && ($count1 == 1) );
	($chr4, $marker4, $genloc4, $phypos4) = split (/\t|\s+/, $line4);
	print OUT1 "$chr4$,$marker4$,$genloc4$,$phypos4$,$markgen{$chr4}{$marker4}\n";
}
close (OUT1);
# Convert tpedo and tind to tfam; place under outdir
# Note that this version of tfam only contains the genotyped individuals
# Family ID, Individual ID, Father ID, Mother ID, Phenotype
$tfamfile = "$outdir\/chr$chr\.tfam";
open (OUT2, ">$tfamfile") || die ("Could not create $tfamfile file!\n");
foreach $line7 (@list7) {
	chomp $line7;
	$line7 =~ s/^\s+//g;
	$line7 =~ s/\s+$//g;
	next if (length($line7) == 0);
	$count2++;
	next if ( ($idh =~ m/T/) && ($count4 == 1) );
	$id7 = $line7;
	($famid7, $subid7) = split (/\_|\./, $id7);
	if ( (defined($dad{$id7})) && (defined($mom{$id7})) && (defined($sex{$id7})) ) {
		print OUT2 "$famid7$,$id7$,$dad{$id7}$,$mom{$id7}$,$sex{$id7}$,\-9\n";
	} elsif ( (defined($dad{$subid7})) && (defined($mom{$subid7})) && (defined($sex{$subid7})) ) {
		print OUT2 "$famid7$,$id7$,$famid7\_$dad{$subid7}$,$famid7\_$mom{$subid7}$,$sex{$subid7}$,\-9\n";
	}
}
close (OUT2);
# Dataset transposed fileset name
$tfile = "$outdir\/chr$chr";

# Convert marker completion to decimal
$markcompt = sprintf("%.2f", $markcompt);

### Create subpanels
my ($panel, $startm, $pass1dist) = 0;
my ($dirxn, $method1, $revmap, $maptmp, $reducedset, $maptmp2, $maptmp3, $prune1, $KGtmp, $matchKGpos, $extract, $exctmap) = "";
my ($paneldir, $auxdir, $auxdir2, $chrdir, $dense, $densepaneltmap, $densepaneldesc, $reduced, $pruned) = "";
my ($pre, $prepanel, $prepaneldesc, $prepanelgaps, $numgapfillers, $panelfile, $paneldesc, $paneltgen) = "";
my ($chr8, $genloc8, $phypos8, $diff) = 0;
my ($marker8, $temp) = "";
my (@gloc, @temp, @usertime, @systemtime) = ();

# Create hashes as each panel is created
my @panels = ();
$dense   = "den";
$extract = "ext";
$reduced = "red";
$pruned  = "pru";
$pre     = "pre";


for ($k = 1; $k <= $npanels; $k++) {
	push @panels, {};
	$time2 = 0;
	$time2  = [Time::HiRes::gettimeofday()];
	print "\nSubpanel $k: $method2[$k-1]\n";
	print LOG "\nSubpanel $k: $method2[$k-1]\n";
	($panel, $dirxn, $start, $startm) = split (" ", $method2[$k-1]);
	print "\nPBAP will use $dirxn direction and start at marker number $start on main panel to create pre-subpanel\n";
	print "For subpanel $panel\, PBAP will use $dirxn direction and start at marker $startm on the pre-subpanel\n";
	print LOG "\nPBAP will use $dirxn direction and start at marker number $start of main panel to create pre-subpanel\n";
	print LOG "For subpanel $panel\, PBAP will use $dirxn direction and start at marker $startm on the pre-subpanel\n";
	
	$paneldir = "$outdir\/panel$panel";
	$auxdir   = "$paneldir\/$popn\/aux\/chr$chr";
	$auxdir2   = "$paneldir\/$popn\/aux2\/chr$chr";
	$chrdir   = "$paneldir\/$popn\/chr$chr";
	# Create directory or clean contents
	if ( ! -e $paneldir ) {
		`mkdir -p $paneldir`;
	} elsif ( -e $paneldir ) {
		# do nothing
	}
	if ( ! -e $auxdir ) {
		`mkdir -p $auxdir`;
	} elsif ( -e $auxdir ) {
		# do nothing
	}
	if ( ! -e $auxdir2 ) {
		if ($kstatprep eq "N") {
			`mkdir -p $auxdir2`;
		}
	} elsif ( -e $auxdir2 ) {
		# do nothing
	}
	if ( ! -e $chrdir ) {
		`mkdir -p $chrdir`;
	} elsif ( -e $chrdir ) {
		# do nothing
	}
	
	$pass1dist      = sprintf ("%.2f", $mindist / 5);
	$maptmp         = $auxdir . "/" . $mappre . $chr . "_" . $extract . ".tmap";
	$reducedset     = $auxdir . "/" . $mappre . $chr . "_" . $extract . ".in";
	$prune1         = $auxdir . "/" . $mappre . $chr . "_exc1.tmap";
	$KGtmp          = $auxdir . "/chr" . $chr . ".tped";
	$matchKGpos     = $auxdir . "/chr" . $chr . "_KGpos.match";
	$exctmap        = $auxdir . "/chr" . $chr . "_exc2.tmap";
	$maptmp2        = $auxdir . "/chr" . $chr . "_" . $pruned . ".tmap";
	$maptmp3        = $auxdir . "/chr" . $chr . "_" . $pruned . "rev.tmap";
	$densepaneltmap = $auxdir . "/chr" . $chr . "_" . $dense  . ".pmap";
	$densepaneldesc = $auxdir . "/chr" . $chr . "_" . $dense  . ".desc";
	$prepanel       = $auxdir . "/chr" . $chr . "_" . $pre    . ".pmap";
	$prepanelgaps   = $auxdir . "/chr" . $chr . "_" . $pre    . ".gaps";
	$numgapfillers  = $auxdir . "/chr" . $chr . "_" . $pre    . ".ngapf";
	$prepaneldesc   = $auxdir . "/chr" . $chr . "_" . $pre    . ".desc";
	$panelfile      = $chrdir . "/chr" . $chr . ".pmap";
	$paneldesc      = $chrdir . "/chr" . $chr . ".desc";
	$paneltgen      = $chrdir . "/chr" . $chr . ".tgen";
	
	if ( -e $maptmp ) { `rm -f $maptmp`; }
	if ( -e $prune1 ) { `rm -f $prune1`; }
	open (OUT3, ">$maptmp") || die ("Could not create $maptmp file! $!\n");
	open (OUT3A, ">$reducedset") || die ("Could not create $reducedset file! $!\n");
	
	open (OUT4, ">$prune1") || die ("Could not create $prune1 file! $!\n");
	open (OUT5, ">$KGtmp") || die ("Could not create $KGtmp file! $!\n");
	open (OUT6, ">$exctmap") || die ("Could not create $exctmap file! $!\n");
	open (OUT7, ">$maptmp2") || die ("Could not create $maptmp2 file! $!\n");
	open (OUT8, ">$maptmp3") || die ("Could not create $maptmp3 file! $!\n");
	open (OUT9, ">$densepaneltmap") || die ("Could not create $densepaneltmap file! $!\n");
	open (OUT9A, ">$densepaneldesc") || die ("Could not create $densepaneldesc file! $!\n");
	if ($kstatprep eq "N") {
		open (OUT10, ">$prepanel") || die ("Could not create $prepanel file! $!\n");
		open (OUT11, ">$prepaneldesc") || die ("Could not create $prepaneldesc file! $!\n");
		open (OUT12, ">$prepanelgaps") || die ("Could not create $prepanelgaps file! $!\n");
		open (OUT12A, ">$numgapfillers") || die ("Could not create $numgapfillers file! $!\n");
	}
	open (OUT13, ">$panelfile") || die ("Could not create $panelfile file! $!\n");
	open (OUT14, ">$paneldesc") || die ("Could not create $paneldesc file! $!\n");
	if ($kstatprep eq "Y") {
		open (OUT15, ">$paneltgen") || die ("Could not create $paneltgen file! $!\n");
	}

	print "Minimum distance for first pass \= $pass1dist\n";
	print LOG "Minimum distance for first pass \= $pass1dist\n";
	create_subpanel($mapfile, $pass1dist);
	
	### Clean up
	
	
	###
	
	my ($user3, $system3) = 0;
	($user2, $system2, $child_user2, $child_system2) = 0;
	($user2, $system2, $child_user2, $child_system2) = times;
	$real2   = Time::HiRes::tv_interval($time2);
	$user2   = sprintf ("%.3f", $user2 + $child_user2);
	$system2 = sprintf ("%.3f", $system2 + $child_system2);
	unshift (@usertime, $user2);
	unshift (@systemtime, $system2);
	if ($k == 1) {
		$user3 = $usertime[0];
		$system3 = $systemtime[0];
	} elsif ($k > 1) {
		$user3 = $usertime[0] - $usertime[1];
		$system3 = $systemtime[0] - $systemtime[1];
	}
	print "\nReal time (panel $k popn $popn chr $chr)   : " . parsetime ($real2);
	print   "User time (panel $k popn $popn chr $chr)   : " . parsetime ($user3);
	print   "System time (panel $k popn $popn chr $chr) : " . parsetime ($system3);
	print LOG "\nReal time (panel $k popn $popn chr $chr)   : " . parsetime ($real2);
	print LOG   "User time (panel $k popn $popn chr $chr)   : " . parsetime ($user3);
	print LOG   "System time (panel $k popn $popn chr $chr) : " . parsetime ($system3);
	
}

### Done creating panels

##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);

print "\nTotal real time (popn $popn chr $chr)   : " . parsetime ($real);
print   "Total user time (popn $popn chr $chr)   : " . parsetime ($user);
print   "Total system time (popn $popn chr $chr) : " . parsetime ($system);
print LOG "\nTotal real time (popn $popn chr $chr)   : " . parsetime ($real);
print LOG   "Total user time (popn $popn chr $chr)   : " . parsetime ($user);
print LOG   "Total system time (popn $popn chr $chr) : " . parsetime ($system);
print "\nDone\n\n";
close (LOG);

##### SUBROUTINES #####

# Elapsed time
sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}

sub marker_completion {
	my $genodata = $_[0];
	my ($talleles, $missing) = 0;
	
	chomp $genodata;
	$genodata =~ s/^\s+//g;
	$genodata =~ s/\s+$//g;
	my @genodata = split (/\s+/, $genodata);
	foreach my $a5 (@genodata) {
		# If 0 or -, count as missing
		$talleles++;
		if ( ($a5 =~ /^0$/) || ($a5 =~ /\-/) ) {
			$missing++;
		}
	}
	if (!defined($missing)) { $missing = 0; }
	my $compl = (($talleles - $missing) / $talleles) * 100;
	return $compl;
}

sub check_monomorphic {
	my $genodata = $_[0];
	my ($missing, $count, $i) = 0;
	my ($a1, $a2, $geno2, $geno3) = "";
	chomp $genodata;
	$genodata =~ s/^\s+//g;
	$genodata =~ s/\s+$//g;
	my @genodata = split (/\s+/, $genodata);
	my $size = scalar(@genodata);
	# Use first genotype as the allele
	my $geno = "";
	my $ik = 0;
	for ($ik=0; $ik<$size; $ik+=2) {
		$geno = "$genodata[$ik]" ."$genodata[$ik]";
		if (($geno ne "00") && ($geno ne "NANA") && ($geno ne "--") && ($geno ne "-0--0-") && ($geno ne "MISSINGMISSING") && ($geno ne "MISMIS") && ($geno ne "missmiss") && ($geno ne "-9-9") && ($geno ne "-1-1") ) {
			last;
		}
	}
	($count, $i) = 0;
	
	for ($i=2; $i<$size; $i+=2) {
		$geno2 = "$genodata[$i]" . "$genodata[$i+1]";
		$geno3 = "$genodata[$i+1]" . "$genodata[$i]";
		if (($geno2 eq $geno) || ($geno3 eq $geno)) {
			# Same so keep $count as zero
		} elsif (($geno2 eq "00") || ($geno2 eq "NANA") || ($geno2 eq "--") || ($geno2 eq "-0--0-") || ($geno2 eq "MISSINGMISSING") || ($geno2 eq "MISMIS") || ($geno2 eq "missmiss") || ($geno2 eq "-9-9") || ($geno2 eq "-1-1") ) {
			# 0 NA - -0- MISSING MIS miss -9 -1
			# Missing so just skip it
		} elsif (($geno2 ne $geno) || ($geno3 ne $geno)) {
			# Different so increase $count
			$count++;
		}
	}
	if (!defined($count)) { $count = 0; }
	if ($count == 0) {	# monomorphic
		$mono = "Y";
	} elsif ($count >= 1) {
		$mono = "N"
	}
	return $mono;
}

sub MAF {
	my $genodata = $_[0];
	my ($missing, $count, $i, $allele_freq, $MAF, $obshet) = 0;
	my ($a1, $a2, $geno2, $geno3) = "";
	chomp $genodata;
	$genodata =~ s/^\s+//g;
	$genodata =~ s/\s+$//g;
	my @genodata = split (/\s+/, $genodata);
	my $size = 0;
	$size = scalar(@genodata);
	my $geno = "";
	
	my ($count_11, $count_12, $count_22, $total) = 0;
	($count, $i) = 0;
	my %genotypes = ();
	my ($A1, $A2) = "";
	my (@A1, @A2) = ();
	for ($i=0; $i<$size; $i+=2) {
		$geno = "$genodata[$i]" . "$genodata[$i+1]";
		if ($count == 0) {
			if ( ($geno eq "00") || ($geno eq "--") || ($geno eq "NANA") ) {
				$missing++;
			} elsif ($genodata[$i] eq $genodata[$i+1]) {
				$count_11++; $total++;
				$genotypes{$genodata[$i]}++;
				$A1 = $genodata[$i];
				unshift (@A1, $A1);
			} elsif ($genodata[$i] ne $genodata[$i+1]) {
				$count_12++; $total++;
				$genotypes{$genodata[$i]}++;
				$genotypes{$genodata[$i+1]}++;
				$A1 = $genodata[$i];
				$A2 = $genodata[$i+1];
				unshift (@A1, $A1);
				unshift (@A2, $A2);
			}
		} elsif ($count >= 1) {
			if ( ($geno eq "00") || ($geno eq "--") || ($geno eq "NANA") ) {
				$missing++;
			} elsif ($genodata[$i] ne $genodata[$i+1]) {
				$count_12++; $total++;
				if ( (scalar(@A1) == 0) && (scalar(@A2) == 0) ) {
					# Get both
					$genotypes{$genodata[$i]}++;
					$genotypes{$genodata[$i+1]}++;
					$A1 = $genodata[$i];
					$A2 = $genodata[$i+1];
					unshift (@A1, $A1);
					unshift (@A2, $A2);
				} elsif ( (scalar(@A1) >= 1) && (scalar(@A2) == 0) ) {
					# A1 exists so get A2
					if ( ($genodata[$i] eq $A1[0]) && ($genodata[$i+1] ne $A1[0]) ) {
						# get A2
						$genotypes{$genodata[$i+1]}++;
						$A2 = $genodata[$i+1];
						unshift (@A2, $A2);
					} elsif ( ($genodata[$i] ne $A1[0]) && ($genodata[$i+1] eq $A1[0]) ) {
						$genotypes{$genodata[$i]}++;
						$A2 = $genodata[$i];
						unshift (@A2, $A2);
					}
				} elsif ( (scalar(@A1) >= 1) && (scalar(@A2) >= 1) ) {
					# Both already exist (do nothing)
				}
			} elsif ( (defined($genotypes{$genodata[$i]})) && ($genodata[$i] eq $genodata[$i+1]) ) {
				if ( (scalar(@A1) >= 1) && ($genodata[$i] eq $A1[0]) ) {
					$count_11++; $total++;
				} elsif ( (scalar(@A2) >= 1) && ($genodata[$i] eq $A2[0]) ) {
					$count_22++; $total++;
				}
			} elsif ( (!defined($genotypes{$genodata[$i]})) && ($genodata[$i] eq $genodata[$i+1]) ) {
				if ($count_11 == 0) {
					$count_11++; $total++;
					$genotypes{$genodata[$i]}++;
					$A1 = $genodata[$i];
					unshift (@A1, $A1);
				} elsif ($count_11 >= 1) {
					$count_22++; $total++;
					$genotypes{$genodata[$i]}++;
					$A2 = $genodata[$i];
					unshift (@A2, $A2);
				}
			}
		}
		$count++;
	}
	if (!defined($missing)) { $missing = 0; }
	if (!defined($count_22)) { $count_22 = 0; }
	if (!defined($count_12)) { $count_12 = 0; }
	$allele_freq = ((2*$count_11) + $count_12)/(2*$total);
	my $count_1 = (2*$count_11) + $count_12;
	my $count_2 = (2*$count_22) + $count_12;
	if ($allele_freq <= 0.5) {
		$MAF = sprintf ("%.6f", $allele_freq);
		$A1 = $A1[0];	# $A1 is the minor allele
		$A2 = $A2[0];	# $A2 is the major allele
		if (!defined($A1)) { $A1 = "none"; }
		$obshet = sprintf ("%.6f", $count_12/$total);
		return "$MAF $obshet $count_1 $count_2 $A1 $A2";
	} elsif ($allele_freq > 0.5) {
		$MAF = sprintf ("%.6f", 1-$allele_freq);
		$A1 = $A2[0];	# $A1 is the minor allele
		$A2 = $A1[0];	# $A2 is the major allele
		if (!defined($A1)) { $A1 = "none"; }
		$obshet = sprintf ("%.6f", $count_12/$total);
		return "$MAF $obshet $count_2 $count_1 $A1 $A2";
	}
}

sub create_subpanel {
	my $map  = $_[0];
	my $dist = $_[1];
	$dist = sprintf ("%.2f", $dist);
	$auxdir = $auxdir;
	$maptmp = $maptmp;
	$prune1 = $prune1;
	$chr = $chr;
	my ($mainrow, $presubrow) = 0;
	$start = $start;
	$k = $k; 	# panel number
	$dirxn = $dirxn;
	$mindist = $mindist;
	$startm = $startm;
	$option = $option;
	$chrdir = $chrdir;
	if ($option == 1) {
		$idfile = $idfile;
	} elsif ($option == 2) {
		$idin = $idin;
	}
	@gloc = ();
	$count = 0;
	$matchKGpos = $matchKGpos;
	if ( -e $matchKGpos ) {
		`rm $matchKGpos`;
	}
	
	my (@list8a, @map, @temp, @exc, @gapfillexc) = ();
	my $temp = "";
	
	open (IN8, "<$map") || die ("Could not open $map file!\n");
	@list8 = <IN8>;
	close (IN8);
	# Create the gloc8, ppos8, mrkr8 hashes
	foreach $line8 (@list8) {
		chomp $line8;
		$line8 =~ s/^\s+//g;
		$line8 =~ s/\s+$//g;
		$genloc8 = 0;
		@info8 = split(/\s+/, $line8);
		$chr8    = $info8[0];
		$marker8 = $info8[1];
		$genloc8 = $info8[2];
		$phypos8 = $info8[3];
		if ($genloc8 !~ m/NA/) {
			$gloc8{$chr8}{$marker8} = sprintf ("%.6f", $genloc8);
		} elsif ($genloc8 =~ m/NA/) {
			$nogenloc{$chr8}{$marker8}++;
		}
		$ppos8{$chr8}{$marker8} = $phypos8;
		$mrkr8{$chr8}{$genloc8} = $marker8;
		$mrkr8{$chr8}{$phypos8} = $marker8;
		$mrkr8{$chr8}{$marker8}++;
		$ppos8{$chr8}{$phypos8}++;
	}
	# Read 1000 Genomes Project genotype data to parse the reduced set of markers
	print "1000 Genomes Project directory \= $oneKGdir\n";
	print LOG "1000 Genomes Project directory \= $oneKGdir\n";
	my $oneKGtped = "$oneKGdir\/$popn\/$popn\_chr$chr\.tped";	# huge file
	my $oneKGtfam = "$oneKGdir\/$popn\/$popn\_chr$chr\.tfam";
	my $oneKG     = "chr$chr";
	my ($oneKGchr, $oneKGgloc, $oneKGppos, $countKG) = 0;
	my ($oneKGmrkr, $oneKGgeno) = "";
	my @oneKG = ();
	my (%maf3, %obshet3, %exphet3, %A1_1KG, %A2_1KG) = ();
	my ($maf3, $obshet3, $exphet3, $count3_1, $count3_2, $count9, $gdist9, $pdist9, $A1_1KG, $A2_1KG) = 0;
	my (@gloc9, @ppos9) = ();
	$count9 = 0;
	open (IN9, "<$oneKGtped") || die ("Could not open $oneKGtped file!\n");
	while (defined ($line9 = <IN9>)) {
		chomp $line9;
		$line9 =~ s/^\s+//g;
		$line9 =~ s/\s+$//g;
		@info9 = split(" ", $line9, 5);
		$oneKGchr  = $info9[0];
		$oneKGmrkr = $info9[1];
		$oneKGgloc = $info9[2];
		$oneKGppos = $info9[3];
		$oneKGgeno = $info9[4];
		
		if (defined($nogeno{$oneKGmrkr})) {
			next;
		} elsif (defined($nogeno{$oneKGppos})) {
			next;
		} elsif (defined($nogenloc{$oneKGchr}{$oneKGmrkr})) {
			next;
		}
		
		if (defined($mrkr8{$oneKGchr}{$oneKGmrkr})) {
			print OUT5 "$line9\n";
			
			push (@oneKG, $oneKGmrkr);
			($maf3, $obshet3, $count3_1, $count3_2, $A1_1KG, $A2_1KG) = split (/\s/, MAF($oneKGgeno));
			$maf3{$oneKGchr}{$oneKGmrkr} = sprintf ("%.6f", $maf3);
			$obshet3{$oneKGchr}{$oneKGmrkr} = sprintf ("%.6f", $obshet3);
			$exphet3 = sprintf ("%.6f", 1 - (($maf3**2) + ((1-$maf3)**2)));
			$exphet3{$oneKGchr}{$oneKGmrkr} = $exphet3;
			$A1_1KG{$oneKGchr}{$oneKGmrkr} = $A1_1KG;
			$A2_1KG{$oneKGchr}{$oneKGmrkr} = $A2_1KG;
			if ($count9 == 0) {
				$gdist9 = sprintf ("%.6f", 0);
				$pdist9 = sprintf ("%.6f", 0);
				unshift (@gloc9, $gloc8{$oneKGchr}{$oneKGmrkr});
				unshift (@ppos9, $oneKGppos);
			} elsif ($count9 >= 1) {
				$gdist9 = sprintf ("%.6f", $gloc8{$oneKGchr}{$oneKGmrkr} - $gloc9[0]);
				$pdist9 = sprintf ("%.6f", ($oneKGppos-$ppos9[0])/1000000);
				unshift (@gloc9, $gloc8{$oneKGchr}{$oneKGmrkr});
				unshift (@ppos9, $oneKGppos);
			}
			print OUT9 "$oneKGchr$,$oneKGmrkr$,$gloc8{$oneKGchr}{$oneKGmrkr}$,$oneKGppos$,SNP$,$markcomp{$oneKGchr}{$oneKGmrkr}$,$maf3$,$exphet3$,$obshet3$,$maf2{$oneKGchr}{$oneKGmrkr}$,$exphet2{$oneKGchr}{$oneKGmrkr}$,$obshet2{$oneKGchr}{$oneKGmrkr}$,$A1_1KG{$oneKGchr}{$oneKGmrkr}$,$A2_1KG{$oneKGchr}{$oneKGmrkr}$,$A1_data{$oneKGchr}{$oneKGmrkr}$,$A2_data{$oneKGchr}{$oneKGmrkr}$,$gdist9$,$pdist9\n";
			$count9++;
		} elsif (defined($ppos8{$oneKGchr}{$oneKGppos})) {
			print OUT5 "$line9\n";
			
			if ( ! -e $matchKGpos ) {
				open (OUT5A, ">$matchKGpos") || die ("Could not create $matchKGpos file! $!\n");
				print OUT5A "Dataset_rsID$,Physical_Position$,1KG_rsID\n";
			}
			print OUT5A "$mrkr8{$oneKGchr}{$oneKGppos}$,$oneKGppos$,$oneKGmrkr\n";
			$matchKGppos{$oneKGmrkr} = $mrkr8{$oneKGchr}{$oneKGppos};
			$KGmarker{$mrkr8{$oneKGchr}{$oneKGppos}} = $oneKGmrkr;
			push (@oneKG, $oneKGppos);
			($maf3, $obshet3, $count3_1, $count3_2, $A1_1KG, $A2_1KG) = split (/\s/, MAF($oneKGgeno));
			$maf3{$oneKGchr}{$matchKGppos{$oneKGmrkr}} = sprintf ("%.6f", $maf3);
			$obshet3{$oneKGchr}{$matchKGppos{$oneKGmrkr}} = sprintf ("%.6f", $obshet3);
			$exphet3 = sprintf ("%.6f", 1 - (($maf3**2) + ((1-$maf3)**2)));
			$exphet3{$oneKGchr}{$matchKGppos{$oneKGmrkr}} = $exphet3;
			$A1_1KG{$oneKGchr}{$matchKGppos{$oneKGmrkr}} = $A1_1KG;
			$A2_1KG{$oneKGchr}{$matchKGppos{$oneKGmrkr}} = $A2_1KG;
			if ($count9 == 0) {
				$gdist9 = sprintf ("%.6f", 0);
				$pdist9 = sprintf ("%.6f", 0);
				unshift (@gloc9, $gloc8{$oneKGchr}{$matchKGppos{$oneKGmrkr}});
				unshift (@ppos9, $oneKGppos);
			} elsif ($count9 >= 1) {
				$gdist9 = sprintf ("%.6f", $gloc8{$oneKGchr}{$matchKGppos{$oneKGmrkr}} - $gloc9[0]);
				$pdist9 = sprintf ("%.6f", ($oneKGppos-$ppos9[0])/1000000);
				unshift (@gloc9, $gloc8{$oneKGchr}{$matchKGppos{$oneKGmrkr}});
				unshift (@ppos9, $oneKGppos);
			}
			print OUT9 "$oneKGchr$,$matchKGppos{$oneKGmrkr}$,$gloc8{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$oneKGppos$,SNP$,$markcomp{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$maf3$,$exphet3$,$obshet3$,$maf2{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$exphet2{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$obshet2{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$A1_1KG{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$A2_1KG{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$A1_data{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$A2_data{$oneKGchr}{$matchKGppos{$oneKGmrkr}}$,$gdist9$,$pdist9\n";
			$count9++;
		}
	}
	close (IN9);
	close (OUT5);
	close (OUT5A);
	close (OUT9);
	panel_characteristics2 ($densepaneltmap, $densepaneldesc);
	foreach my $KG (@map) {
		chomp $KG;
		my ($a, $b, $c, $d, $e) = split (/\s+/, $KG, 5);
		if ( (grep(/^$b$/, @oneKG)) || (grep(/^$d$/, @oneKG)) ) {
		} else {
			$temp = "$a$,$b$,$c$,$d$,not_in_KGP";
			push (@temp, $temp);
		}
	}
	
	# Calculate allele frequencies of markers in dense panel based on 1KG data
	chdir("$auxdir");
	`cp -p $oneKGtfam $oneKG\.tfam`;
	system("$plink --tfile $oneKG --noweb --allow-no-sex --freq --out $oneKG\_$dense");
	
	# Create a hash of the minor allele frequencies calculated using Plink
	my %mainmaf = ();
	open (IN14, "<$oneKG\_$dense.frq") || die ("Could not open $oneKG\_$dense.frq file!\n");
	while (defined ($line14 = <IN14>)) {
		chomp $line14;
		$line14 =~ s/^\s+//g;
		$line14 =~ s/\s+$//g;
		# MAF is for allele 1 (Plink)
		my ($chr14, $rsid14, $allele1, $allele2, $maf14, $numobs) = split(/\s+/, $line14);
		next if ($chr14 =~ m/CHR/);
		$mainmaf{$rsid14} = $maf14;
	}
	close (IN14);
	
	if ($dirxn eq "rev") {
		@list8a = sort { (split(" ", $b))[2] <=> (split(" ", $a))[2] } @list8;
	} elsif ($dirxn eq "fwd") {
		@list8a = @list8;
	}
	my @remove = ();
	foreach $line8 (@list8a) {
		chomp $line8;
		$line8 =~ s/^\s+//g;
		$line8 =~ s/\s+$//g;
		$genloc8 = 0;
		@info8 = split(/\s+/, $line8);
		$chr8    = $info8[0];
		$marker8 = $info8[1];
		$genloc8 = $info8[2];
		$phypos8 = $info8[3];
		if ($genloc8 !~ m/NA/) {
			$genloc8 = sprintf ("%.6f", $genloc8);
		} elsif ($genloc8 !~ m/NA/) {
			# do nothing
		}
		@remove = ();
		if (defined($nogenloc{$chr8}{$marker8})) { push (@remove, "no genetic location"); }
		if ( (defined($mono{$chr8}{$marker8})) && ($mono{$chr8}{$marker8} eq "Y") ) { push (@remove, "monomorphic"); }
		if ( (defined($markcomp{$chr8}{$marker8})) && ($markcomp{$chr8}{$marker8} < $markcompt) ) { push (@remove, "marker_completion\=$markcomp{$chr8}{$marker8}" ); }
		if ( (defined($mainmaf{$marker8})) && ( ($mainmaf{$marker8} < $mafmin) || ($mainmaf{$marker8} > $mafmax) ) ) { push (@remove, "maf\=$mainmaf{$marker8}" ); }
		
		if (scalar(@remove) >= 1) {
			print LOG "Exclude: $chr8$,$marker8$,$genloc8$,$phypos8 | " . join ("|", @remove) ."\n";
			$temp = "$chr8$,$marker8$,$genloc8$,$phypos8$,SNP$," . join ("|", @remove);
			print OUT4 "$temp\n";	# place in list of pruned snps
			push (@temp, $temp);
			next;
		}
		
		$mainrow++;
		if ($mainrow < $start) {
			# Exclude this marker no matter what
			if ($dirxn eq "fwd") {
				$temp = "$chr8$,$marker8$,$genloc8$,$phypos8$,SNP$,upstream_of_main_panel_start_marker_forward_direction";
			} elsif ($dirxn eq "rev") {
				$temp = "$chr8$,$marker8$,$genloc8$,$phypos8$,SNP$,upstream_of_main_panel_start_marker_reverse_direction";
			}
			print OUT4 "$temp\n";	# place in list of pruned snps
			print "mainrow\=$mainrow start\=$start so exclude $temp\n";
			push (@temp, $temp);
			next;
		} elsif ($mainrow >= $start) {
			# Calculate intermarker distances and remove those that are below 1/5 of the minimum distance
			if (defined($exclude{$marker8})) {
				# Exclude this marker no matter what
				$temp = "$chr8$,$marker8$,$genloc8$,$phypos8$,SNP$,exclusion_marker";
				push (@temp, $temp);
				next;
			} elsif ( ($count == 0) || (scalar(@gloc) == 0) ) {		# first row of tmap file
				$presubrow++;
				if ($presubrow < $startm) {
					# Exclude this marker no matter what
					if ($dirxn eq "fwd") {
						$temp = "$chr8$,$marker8$,$genloc8$,$phypos8$,SNP$,upstream_of_pre-subpanel_start_marker_forward_direction";
					} elsif ($dirxn eq "rev") {
						$temp = "$chr8$,$marker8$,$genloc8$,$phypos8$,SNP$,upstream_of_pre-subpanel_start_marker_reverse_direction";
					}
					print "presubrow\=$presubrow start\=$startm so exclude $temp\n";
					push (@temp, $temp);
					next;
				} elsif ($presubrow >= $startm) {
					$diff = sprintf ("%.6f", 0);
					print OUT3 "$chr8$,$marker8$,$genloc8$,$phypos8$,$diff\n";
					if (defined($KGmarker{$marker8})) {
						print OUT3A "$KGmarker{$marker8}\n";
					} elsif (!defined($KGmarker{$marker8})) {
						print OUT3A "$marker8\n";
					}
					unshift (@gloc, $genloc8);
					push (@map, $line8);
					$count++;
				}
			} elsif ( ($count >= 1) && (scalar(@gloc) >= 1) ) {
				$diff = sprintf ("%.6f", abs($genloc8 - $gloc[0]));
				if ($diff >= $dist) {
					if ($k == 1) {
						print OUT3 "$chr8$,$marker8$,$genloc8$,$phypos8$,$diff\n";		# include on map
						if (defined($KGmarker{$marker8})) {
							print OUT3A "$KGmarker{$marker8}\n";
						} elsif (!defined($KGmarker{$marker8})) {
							print OUT3A "$marker8\n";
						}
						unshift (@gloc, $genloc8);
						push (@map, $line8);
					} elsif ($k >= 2) {
						my ($z, $countz) = 0;
						$countz = 0;
						for ($z = 1; $z < $k; $z++) {
							if (defined($panels[$z]{$phypos8})) {
								print OUT4 "$chr8$,$marker8$,$genloc8$,$phypos8$,$diff\n";		# place in list of pruned snps
								$temp = "$chr8$,$marker8$,$genloc8$,$phypos8$,SNP$,previous_panel-based_pruning";
								push (@temp, $temp);
								$countz++;
								last;
							}
						}
						if ($countz == 0) {
							print OUT3 "$chr8$,$marker8$,$genloc8$,$phypos8$,$diff\n";		# include on map
							if (defined($KGmarker{$marker8})) {
								print OUT3A "$KGmarker{$marker8}\n";
							} elsif (!defined($KGmarker{$marker8})) {
								print OUT3A "$marker8\n";
							}
							unshift (@gloc, $genloc8);
							push (@map, $line8);
						}
					}
					$count++;
				} elsif ($diff < $dist) {
					print OUT4 "$chr8$,$marker8$,$genloc8$,$phypos8$,$diff\n";		# place in list of pruned snps
					$temp = "$chr8$,$marker8$,$genloc8$,$phypos8$,SNP$,initial_distance-based_pruning";
					push (@temp, $temp);
					$count++;
				}
			}
		}
	}
	close (OUT3);
	close (OUT4);
	
	# Extract the reduced set of SNPs before performing LD-based SNP pruning
	# This will prevent removal of markers later due to being monomorphic, 
	# having low MAF, or marker completion below threshold
	system("$plink --tfile $oneKG --noweb --allow-no-sex --extract $reducedset --recode --transpose --out $oneKG\_$reduced");
	
	# Now we can perform LD-based SNP pruning (Plink)
	my $VIF = sprintf ("%.5f", 1/(1-($r2max)));
	my $r2part = 0;
	if ($r2max =~ m/\.(\d+)/) { $r2part = $1; }
	my $window = sprintf ("%.0f", 1/$dist);
	my $increment = sprintf ("%.0f", $window/2.5);
	print "#-----------------------------------------------------------------------------------------#\n";
	print "   Based on a smaller minimum distance of $dist cM and maximum LD threshold of $r2max\,\n";
	print "   we will perform Plink LD-based SNP pruning in a window of $window SNPs\n";
	print "   incrementing by $increment SNPs at a time, using a variance inflation factor (VIF) of $VIF\n";
	print "#-----------------------------------------------------------------------------------------#\n";
	print LOG "#-----------------------------------------------------------------------------------------#\n";
	print LOG "   Based on a smaller minimum distance of $dist cM and maximum LD threshold of $r2max\,\n";
	print LOG "   we will perform Plink LD-based SNP pruning in a window of $window SNPs\n";
	print LOG "   incrementing by $increment SNPs at a time, using a variance inflation factor (VIF) of $VIF\n";
	print LOG "#-----------------------------------------------------------------------------------------#\n";

	system("$plink --tfile $oneKG\_$reduced --noweb --allow-no-sex --indep $window $increment $VIF --out $oneKG\_$window\_$increment\_$r2part");
	open (IN10, "<$oneKG\_$window\_$increment\_$r2part\.prune\.out") || die ("Could not open $oneKG\_$window\_$increment\_$r2part\.prune\.out file!\n");
	@list10 = <IN10>;
	close (IN10);
	foreach $line10 (@list10) {
		chomp $line10;	# marker
		$line10 =~ s/^\s+//g;
		$line10 =~ s/\s+$//g;
		next if (length($line10) == 0);
		if (defined($matchKGppos{$line10})) {
			$temp = "$chr$,$line10$,$gloc8{$chr}{$matchKGppos{$line10}}$,$ppos8{$chr}{$matchKGppos{$line10}}$,SNP$,LD-based_pruning";
		} elsif (!defined($matchKGppos{$line10})) {
			$temp = "$chr$,$line10$,$gloc8{$chr}{$line10}$,$ppos8{$chr}{$line10}$,SNP$,LD-based_pruning";
		}
		push (@temp, $temp);
	}
	
	chdir("$auxdir");
	system("$plink --tfile $oneKG --noweb --allow-no-sex --extract $oneKG\_$window\_$increment\_$r2part\.prune.in --recode --transpose --out $oneKG\_$pruned");
	system("$plink --tfile $oneKG\_$pruned --noweb --allow-no-sex --freq --out $oneKG\_$pruned\_f");
	`rm -r *.nosex`;
	
	
	# We will now include the core and aux inclusion markers that are not exclusion markers
	my $temp2 = "";
	my @temp2 = ();
	my ($gloc11, $ppos11) = 0;
	my (%prunedmap, %coreinc, %stsgloc) = ();
	open (IN11, "<$oneKG\_$pruned\.tped") || die ("Could not open $oneKG\_$pruned\.tped file!\n");
	while (defined ($line11 = <IN11>)) {
		chomp $line11;
		$line11 =~ s/^\s+//g;
		$line11 =~ s/\s+$//g;
		my ($g, $h, $l, $m, $n) = split(/\s+/, $line11, 5);
		if (defined($matchKGppos{$h})) {
			$gloc11 = sprintf ("%.6f", $gloc8{$g}{$matchKGppos{$h}});
		} elsif (!defined($gloc8{$g}{$h})) {
			$gloc8{$g}{$h} = $l;
			$gloc11 = $l;
		} elsif (defined($gloc8{$g}{$h})) {
			$gloc11 = sprintf ("%.6f", $gloc8{$g}{$h});
		}
		if (!defined($ppos8{$g}{$h})) {
			$ppos8{$g}{$h} = $m;
			$ppos11 = $m;
		} elsif (defined($ppos8{$g}{$h})) {
			$ppos11 = sprintf ("%.0f", $ppos8{$g}{$h});
		}
		$temp2 = "$g$,$h$,$gloc11$,$ppos11$,SNP";
		push (@temp2, $temp2);
		$prunedmap{$h} = 1;
	}
	close (IN11);
	# Check the inclusion and exclusion hashes
	# Make sure that duplicates are removed
	if (keys %include) {
		my $countinc = 0;
		print "Processing inclusion markers that should be returned back into the LD-reduced pre-subpanel $panel\...\n";
		print LOG "Processing inclusion markers that should be returned back into the LD-reduced pre-subpanel $panel\...\n";
		foreach my $key (sort keys %include) {
			if ($chrinc{$key} == $chr) {
				if (defined($exclude{$key})) {
					# marker should not be put back because it is also an exclusion marker
				} else {
					if (defined($prunedmap{$key})) {
						# it is already in the pruned map file
						print "   $chrinc{$key}$,$key$,$categ{$key} is already in the LD-reduced pre-subpanel\n";
						print LOG "   $chrinc{$key}$,$key$,$categ{$key} is already in the LD-reduced pre-subpanel\n";
						$coreinc{$key} = 1;
					} else {
						$gloc11 = "";
						if (defined($gloc8{$chrinc{$key}}{$key})) {
							$countinc++;
							$gloc11 = sprintf ("%.6f", $gloc8{$chrinc{$key}}{$key});
							$temp2 = "$chrinc{$key}$,$key$,$gloc11$,$ppos8{$chrinc{$key}}{$key}$,$type{$chrinc{$key}}{$key}";
							$coreinc{$key} = 1;
							push(@temp2, $temp2);
						} elsif (!defined($gloc8{$chrinc{$key}}{$key})) {
							print "   $chrinc{$key}$,$key$,$categ{$key} is not in main input file and has no genetic location so it cannot be included\n";
							print LOG "   $chrinc{$key}$,$key$,$categ{$key} is not in main input file and has no genetic location so it cannot be included\n";
						}
					}
				}
			}
		}
		if ($countinc == 0) {
			print "   None of the inclusion markers on your list is on chromosome $chr\n";
			print LOG "   None of the inclusion markers on your list is on chromosome $chr\n";
		}
	}
	# Print markers with the additional inclusion markers into a map file
	my @exc2 = sort { (split(" ", $a))[2] <=> (split(" ", $b))[2] } @temp2;
	print OUT7 join ("\n", @exc2);	# sorted by genetic location
	close (OUT7);
	my @exc3 = sort { (split(" ", $b))[2] <=> (split(" ", $a))[2] } @temp2;
	print OUT8 join ("\n", @exc3);	# reverse sorted by genetic location
	close (OUT8);
	my (%maf, %exphet) = ();
	# Create a hash of the minor allele frequencies calculated using PLINK
	chdir("$auxdir");
	open (IN12, "<$oneKG\_$pruned\_f.frq") || die ("Could not open $oneKG\_$pruned\_f.frq file!\n");
	while (defined ($line12 = <IN12>)) {
		chomp $line12;
		$line12 =~ s/^\s+//g;
		$line12 =~ s/\s+$//g;
		# MAF is for allele 1 (PLINK)
		my ($chr12, $rsid12, $allele1, $allele2, $maf11, $numobs) = split(/\s+/, $line12);
		next if ($chr12 =~ m/CHR/);
		$maf11 = sprintf ("%.4f", $maf11);
		$maf{$rsid12} = $maf11;
		my $exphet11 = sprintf ("%.4f", 1 - (($maf11**2) + ((1-$maf11)**2)));
		$exphet{$rsid12} = $exphet11;
	}
	close (IN12);
	
	# Put the final inclusion markers into the subpanel
	# Note that only the core inclusion markers will be immune to the parameters
	# that will be used
	my (@subpanel, @glocinc, @glocexc) = ();
	my $temp3 = "";
	foreach my $key2 (sort keys %coreinc) {
		if (!defined($markcomp{$chr}{$key2})) { $markcomp{$chr}{$key2} = "NA"; }

		if (!defined($maf{$key2})) { $maf{$key2} = "NA"; }
		if (!defined($exphet{$key2})) { $exphet{$key2} = "NA"; }
		
		if (!defined($maf2{$chr}{$key2})) { $maf2{$chr}{$key2} = "NA"; }
		if (!defined($obshet2{$chr}{$key2})) { $obshet2{$chr}{$key2} = "NA"; }
		if (!defined($exphet2{$chr}{$key2})) { $exphet2{$chr}{$key2} = "NA"; }

		if (!defined($maf3{$chr}{$key2})) { $maf3{$chr}{$key2} = "NA"; }
		if (!defined($obshet3{$chr}{$key2})) { $obshet3{$chr}{$key2} = "NA"; }
		if (!defined($exphet3{$chr}{$key2})) { $exphet3{$chr}{$key2} = "NA"; }
		
		if (!defined($A1_1KG{$chr}{$key2})) { $A1_1KG{$chr}{$key2} = "NA"; }
		if (!defined($A2_1KG{$chr}{$key2})) { $A2_1KG{$chr}{$key2} = "NA"; }
		
		if (!defined($A1_data{$chr}{$key2})) { $A1_data{$chr}{$key2} = "NA"; }
		if (!defined($A2_data{$chr}{$key2})) { $A2_data{$chr}{$key2} = "NA"; }

		# exclude Plink calculations
		$temp3 = "$chrinc{$key2}$,$key2$,$gloc8{$chrinc{$key2}}{$key2}$,$ppos8{$chrinc{$key2}}{$key2}$,$type{$chrinc{$key2}}{$key2}$,$markcomp{$chr}{$key2}$,$maf3{$chr}{$key2}$,$exphet3{$chr}{$key2}$,$obshet3{$chr}{$key2}$,$maf2{$chr}{$key2}$,$exphet2{$chr}{$key2}$,$obshet2{$chr}{$key2}$,$A1_1KG{$chr}{$key2}$,$A2_1KG{$chr}{$key2}$,$A1_data{$chr}{$key2}$,$A2_data{$chr}{$key2}";
		if ($k == 1) {	# include inclusion markers only on subpanel 1
			if ($categ{$key2} eq "core") {	# aux inclusion markers may be removed based on the parameters but core should be included all the time
				if (!defined($mrkr8{$chrinc{$key2}}{$key2})) {
					print LOG "$key2 is not in the input dense panel so it cannot be included\n";
					next;
				} elsif (defined($mrkr8{$chrinc{$key2}}{$key2})) {
					push (@subpanel, $temp3);
					push (@glocinc, $gloc8{$chrinc{$key2}}{$key2});
					if ($type{$chrinc{$key2}}{$key2} eq "STS") {
						$stsgloc{sprintf("%.6f", $gloc8{$chrinc{$key2}}{$key2})}++; 
					}
				}
			}
		} elsif ($k == 2) {	# exclude inclusion markers only on subpanel 2
			push (@glocexc, $gloc8{$chrinc{$key2}}{$key2});
		}
	}
	
	print "Creating subpanel $panel\.\.\.\n";
	print LOG "Creating subpanel $panel\.\.\.\n";
	my ($temp4, $mono13) = "";
	my ($count13, $countrow13, $countm, $diff13, $gloc13a, $markcomp13) = 0;
	my @genloc13 = ();
		if ($dirxn eq "fwd") {
		open (IN13, "<$maptmp2") || die ("Could not open $maptmp2 file!\n");
		$countrow13 = 0;
		$countm = 0;
		while (defined ($line13 = <IN13>)) {
			chomp $line13;
			$line13 =~ s/^\s+//g;
			$line13 =~ s/\s+$//g;
			next if (length($line13) == 0);
			$count13 = 0;
			my ($chr13, $rsid13, $gloc13, $ppos13, $type13) = split(/\s+/, $line13);
			my $rsid13a = "";
			if ( (defined($type13)) && ($type13 eq "STS") ) {
				goto NEXT_LINE13_FWD;
			} elsif (defined($matchKGppos{$rsid13})) {
				# replace rsid13 with old rsid
				$gloc13 = $gloc8{$chr13}{$matchKGppos{$rsid13}};
				$markcomp13 = $markcomp{$chr13}{$matchKGppos{$rsid13}};
				$mono13 = $mono{$chr13}{$matchKGppos{$rsid13}};
				$rsid13a = $matchKGppos{$rsid13} . "/" . $rsid13;

				if (!defined($A1_1KG{$chr13}{$matchKGppos{$rsid13}})) { $A1_1KG{$chr13}{$matchKGppos{$rsid13}} = "NA"; }
				if (!defined($A2_1KG{$chr13}{$matchKGppos{$rsid13}})) { $A2_1KG{$chr13}{$matchKGppos{$rsid13}} = "NA"; }
		
				if (!defined($A1_data{$chr13}{$matchKGppos{$rsid13}})) { $A1_data{$chr13}{$matchKGppos{$rsid13}} = "NA"; }
				if (!defined($A2_data{$chr13}{$matchKGppos{$rsid13}})) { $A2_data{$chr13}{$matchKGppos{$rsid13}} = "NA"; }
				
				$temp4 = "$chr13$,$matchKGppos{$rsid13}$,$gloc13$,$ppos13$,SNP$,$markcomp13$,$maf3{$chr13}{$matchKGppos{$rsid13}}$,$exphet3{$chr13}{$matchKGppos{$rsid13}}$,$obshet3{$chr13}{$matchKGppos{$rsid13}}$,$maf2{$chr13}{$matchKGppos{$rsid13}}$,$exphet2{$chr13}{$matchKGppos{$rsid13}}$,$obshet2{$chr13}{$matchKGppos{$rsid13}}$,$A1_1KG{$chr13}{$matchKGppos{$rsid13}}$,$A2_1KG{$chr13}{$matchKGppos{$rsid13}}$,$A1_data{$chr13}{$matchKGppos{$rsid13}}$,$A2_data{$chr13}{$matchKGppos{$rsid13}}";
			} elsif (!defined($matchKGppos{$rsid13})) {
				# use rsid13 for markcomp and mono
				$gloc13 = $gloc8{$chr13}{$rsid13};
				$markcomp13 = $markcomp{$chr13}{$rsid13};
				$mono13 = $mono{$chr13}{$rsid13};
				$rsid13a = $rsid13;

				if (!defined($A1_1KG{$chr13}{$rsid13})) { $A1_1KG{$chr13}{$rsid13} = "NA"; }
				if (!defined($A2_1KG{$chr13}{$rsid13})) { $A2_1KG{$chr13}{$rsid13} = "NA"; }
		
				if (!defined($A1_data{$chr13}{$rsid13})) { $A1_data{$chr13}{$rsid13} = "NA"; }
				if (!defined($A2_data{$chr13}{$rsid13})) { $A2_data{$chr13}{$rsid13} = "NA"; }

				$temp4 = "$chr13$,$rsid13$,$gloc13$,$ppos13$,SNP$,$markcomp13$,$maf3{$chr13}{$rsid13}$,$exphet3{$chr13}{$rsid13}$,$obshet3{$chr13}{$rsid13}$,$maf2{$chr13}{$rsid13}$,$exphet2{$chr13}{$rsid13}$,$obshet2{$chr13}{$rsid13}$,$A1_1KG{$chr13}{$rsid13}$,$A2_1KG{$chr13}{$rsid13}$,$A1_data{$chr13}{$rsid13}$,$A2_data{$chr13}{$rsid13}";
			}
			$countm++;
			my @temp4 = ();
			@temp4 = split(/\s/, $temp4);
			next if ($countm < $startm);
			if ( (defined($maf{$rsid13})) && ($maf{$rsid13} !~ m/NA/) && ($maf{$rsid13} >= $mafmin) && ($maf{$rsid13} <= $mafmax) && (defined($markcomp13)) && ($markcomp13 >= $markcompt) ) {
				if ( ( ($exclumono eq "Y") && ($mono13 eq "N") ) || ($exclumono eq "N") ) {
					if ($k == 1) {
						# check if within glocinc +- mindist
						foreach $gloc13a (@glocinc) {
							$gloc13a = sprintf("%.6f", $gloc13a);
							if ($gloc13 == $gloc13a) {
								# it is one of the inclusion markers so use its genloc as the latest genloc[0]
								unshift(@genloc13, $gloc13);
								print LOG "$rsid13a is one of the inclusion markers\n";
							}
							if (defined($stsgloc{$gloc13a})) {
								# let us use $stsdist
								if ( ($gloc13 > ($gloc13a - $stsdist)) && ($gloc13 < ($gloc13a + $stsdist)) ) {
									# skip this marker
									$count13++;
									print LOG "Exclude: Distance of $gloc13 from $gloc13a is less than the minimum distance from a core inclusion STS marker $stsdist\n";
									push(@temp, $temp4 . " final_distance_based_pruning");
									my $gapexcstart = sprintf("%.6f", $gloc13a - $stsdist);
									my $gapexcend   = sprintf("%.6f", $gloc13a + $stsdist);
									my $gapfillexc  = "$gapexcstart$,$gapexcend";
									push (@gapfillexc, $gapfillexc);
								}
							} elsif (!defined($stsgloc{$gloc13a})) {
								if ( ($gloc13 > ($gloc13a - $mindist)) && ($gloc13 < ($gloc13a + $mindist)) ) {
									# skip this marker
									$count13++;
									print LOG "Exclude: Distance of $gloc13 from $gloc13a is less than the minimum distance $mindist\n";
									push(@temp, $temp4 . " final_distance_based_pruning");
								}
							}
						}
					} elsif ($k == 2) {
						# exclude inclusion markers from panel 2 to allow Mendelian-consistent error-checking for these markers
						foreach $gloc13a (@glocexc) {
							if ($gloc13 == $gloc13a) {
								# it is one of the inclusion markers so exclude it
								# skip this marker
								$count13++;
								print LOG "Exclude: Inclusion marker $rsid13a is excluded from panel 2\n";
								push(@temp, $temp4 . " inclusion_marker_excluded_in_panel_2");
							}
						}
					}
					if ( ( ($count13 == 0) && ($countrow13 == 0) ) || ( ($count13 == 0) && (scalar(@genloc13) == 0) ) ) {		# first row of tmap file
							print LOG "Include (first marker): $chr13$,$rsid13a$,$gloc13$,$ppos13 | $maf{$rsid13} $markcomp13 $mono13\n";
							push (@subpanel, $temp4);
							unshift(@genloc13, $gloc13);
							$countrow13++;
					} elsif ( ($count13 == 0) && ($countrow13 >= 1) && (scalar(@genloc13) >= 1) ) {		# succeeding rows of tmap file
						# check distance
						$diff13 = sprintf ("%.6f", abs($gloc13 - $genloc13[0]));
						if ($diff13 >= $mindist) {
								print LOG "Include: $chr13$,$rsid13a$,$gloc13$,$ppos13 | former_genloc\=$genloc13[0] $diff13 $mindist $maf{$rsid13} $markcomp13 $mono13\n";
								push (@subpanel, $temp4);
								unshift(@genloc13, $gloc13);
								$countrow13++;
						} elsif ($diff13 < $mindist) {
							print LOG "Exclude (below minimum distance): $chr13$,$rsid13a$,$gloc13$,$ppos13 | former_genloc\=$genloc13[0] $diff13 $mindist $maf{$rsid13} $markcomp13 $mono13\n";
							push(@temp, $temp4 . " final_distance_based_pruning");
							$countrow13++;
						}
					} elsif ($count13 >= 1) {
						# skip this marker
						print LOG "Exclude (near inclusion marker / already included as inclusion marker / or excluded inclusion marker if panel2): $chr13$,$rsid13a$,$gloc13$,$ppos13\n";
						push(@temp, $temp4 . " inclusion_marker_pruning");
						$countrow13++;
					}
				}
			} else {
				if (!defined($maf{$rsid13})) {	# it could be an inclusion marker
					foreach my $gloc13a (@glocinc) {
						if ($gloc13 == $gloc13a) {
							# it is one of the inclusion markers so use its genloc as the latest genloc[0]
							unshift(@genloc13, $gloc13);
							print LOG "Inclusion marker: $chr13$,$rsid13a$,$gloc13$,$ppos13\n";
						}
					}
				} else {
					if (!defined($maf{$rsid13})) { $maf{$rsid13} = "No_MAF_info"; }
					if (!defined($markcomp13)) { $markcomp13 = "No_markcomp_info"; }
					if (!defined($mono13)) { $mono13 = "No_mono_info"; }
					print LOG "Exclude: $chr13$,$rsid13a$,$gloc13$,$ppos13 | $maf{$rsid13} $markcomp13 $mono13\n";
					push(@temp, $temp4 . " no_MAF_markcomp_or_monomorphic_info");
				}
			}
			$count13 = 0;
			NEXT_LINE13_FWD:
		}
	} elsif ($dirxn eq "rev") {
		open (IN13, "<$maptmp3") || die ("Could not open $maptmp3 file!\n");
		$countrow13 = 0;
		$countm = 0;
		while (defined ($line13 = <IN13>)) {
			chomp $line13;
			$line13 =~ s/^\s+//g;
			$line13 =~ s/\s+$//g;
			next if (length($line13) == 0);
			$count13 = 0;
			my ($chr13, $rsid13, $gloc13, $ppos13, $type13) = split(/\s+/, $line13);
			my $rsid13a = "";
			if ( (defined($type13)) && ($type13 eq "STS") ) {
				goto NEXT_LINE13_REV;
			} elsif (defined($matchKGppos{$rsid13})) {
				# replace rsid13 with old rsid
				$gloc13 = $gloc8{$chr13}{$matchKGppos{$rsid13}};
				$markcomp13 = $markcomp{$chr13}{$matchKGppos{$rsid13}};
				$mono13 = $mono{$chr13}{$matchKGppos{$rsid13}};
				$rsid13a = $matchKGppos{$rsid13} . "/" . $rsid13;

				if (!defined($A1_1KG{$chr13}{$matchKGppos{$rsid13}})) { $A1_1KG{$chr13}{$matchKGppos{$rsid13}} = "NA"; }
				if (!defined($A2_1KG{$chr13}{$matchKGppos{$rsid13}})) { $A2_1KG{$chr13}{$matchKGppos{$rsid13}} = "NA"; }
		
				if (!defined($A1_data{$chr13}{$matchKGppos{$rsid13}})) { $A1_data{$chr13}{$matchKGppos{$rsid13}} = "NA"; }
				if (!defined($A2_data{$chr13}{$matchKGppos{$rsid13}})) { $A2_data{$chr13}{$matchKGppos{$rsid13}} = "NA"; }

				# exclude PLINK calculations
				$temp4 = "$chr13$,$matchKGppos{$rsid13}$,$gloc13$,$ppos13$,SNP$,$markcomp13$,$maf3{$chr13}{$matchKGppos{$rsid13}}$,$exphet3{$chr13}{$matchKGppos{$rsid13}}$,$obshet3{$chr13}{$matchKGppos{$rsid13}}$,$maf2{$chr13}{$matchKGppos{$rsid13}}$,$exphet2{$chr13}{$matchKGppos{$rsid13}}$,$obshet2{$chr13}{$matchKGppos{$rsid13}}$,$A1_1KG{$chr13}{$matchKGppos{$rsid13}}$,$A2_1KG{$chr13}{$matchKGppos{$rsid13}}$,$A1_data{$chr13}{$matchKGppos{$rsid13}}$,$A2_data{$chr13}{$matchKGppos{$rsid13}}";
			} elsif (!defined($matchKGppos{$rsid13})) {
				# use rsid13 for markcomp and mono
				$gloc13 = $gloc8{$chr13}{$rsid13};
				$markcomp13 = $markcomp{$chr13}{$rsid13};
				$mono13 = $mono{$chr13}{$rsid13};
				$rsid13a = $rsid13;

				if (!defined($A1_1KG{$chr13}{$rsid13})) { $A1_1KG{$chr13}{$rsid13} = "NA"; }
				if (!defined($A2_1KG{$chr13}{$rsid13})) { $A2_1KG{$chr13}{$rsid13} = "NA"; }
		
				if (!defined($A1_data{$chr13}{$rsid13})) { $A1_data{$chr13}{$rsid13} = "NA"; }
				if (!defined($A2_data{$chr13}{$rsid13})) { $A2_data{$chr13}{$rsid13} = "NA"; }
				
				$temp4 = "$chr13$,$rsid13$,$gloc13$,$ppos13$,SNP$,$markcomp13$,$maf3{$chr13}{$rsid13}$,$exphet3{$chr13}{$rsid13}$,$obshet3{$chr13}{$rsid13}$,$maf2{$chr13}{$rsid13}$,$exphet2{$chr13}{$rsid13}$,$obshet2{$chr13}{$rsid13}$,$A1_1KG{$chr13}{$rsid13}$,$A2_1KG{$chr13}{$rsid13}$,$A1_data{$chr13}{$rsid13}$,$A2_data{$chr13}{$rsid13}";
			}
			$countm++;
			my @temp4 = ();
			@temp4 = split(/\s/, $temp4);
			next if ($countm < $startm);
			if ( (defined($maf{$rsid13})) && ($maf{$rsid13} >= $mafmin) && ($maf{$rsid13} <= $mafmax) && ($markcomp13 >= $markcompt) ) {
				if ( ( ($exclumono eq "Y") && ($mono13 eq "N") ) || ($exclumono eq "N") ) {
					if ($k == 1) {
						# check if within glocinc +- mindist
						foreach $gloc13a (@glocinc) {
							if ($gloc13 == $gloc13a) {
								# it is one of the inclusion markers so use its genloc as the latest genloc[0]
								unshift(@genloc13, $gloc13);
								print LOG "$rsid13a is one of the inclusion markers\n";
							}
							if (defined($stsgloc{$gloc13a})) {
								# let us use $stsdist
								if ( ($gloc13 > ($gloc13a - $stsdist)) && ($gloc13 < ($gloc13a + $stsdist)) ) {
									# skip this marker
									$count13++;
									print LOG "Exclude: Distance of $gloc13 from $gloc13a is less than the minimum distance from a core inclusion STS marker $stsdist\n";
									push(@temp, $temp4 . " final_distance_based_pruning");
									my $gapexcstart = sprintf("%.6f", $gloc13a - $stsdist);
									my $gapexcend   = sprintf("%.6f", $gloc13a + $stsdist);
									my $gapfillexc  = "$gapexcstart$,$gapexcend";
									push (@gapfillexc, $gapfillexc);
								}
							} elsif (!defined($stsgloc{$gloc13a})) {
								if ( ($gloc13 > ($gloc13a - $mindist)) && ($gloc13 < ($gloc13a + $mindist)) ) {
									# skip this marker
									$count13++;
									print LOG "Exclude: Distance of $gloc13 from $gloc13a is less than the minimum distance $mindist\n";
									push(@temp, $temp4 . " final_distance_based_pruning");
								}
							}
						}
					} elsif ($k == 2) {
						# exclude inclusion markers from panel 2 to allow Mendelian-consistent error-checking for these markers
						foreach $gloc13a (@glocexc) {
							if ($gloc13 == $gloc13a) {
								# it is one of the inclusion markers so exclude it
								# skip this marker
								$count13++;
								print LOG "Exclude: Inclusion marker $rsid13a is excluded from panel 2\n";
								push(@temp, $temp4 . " inclusion_marker_excluded_in_panel_2");
							}
						}
					}
					if ( ( ($count13 == 0) && ($countrow13 == 0) ) || ( ($count13 == 0) && (scalar(@genloc13) == 0) ) ) {		# first row of tmap file
							print LOG "Include (first marker): $chr13$,$rsid13a$,$gloc13$,$ppos13 | $maf{$rsid13} $markcomp13 $mono13\n";
							push (@subpanel, $temp4);
							unshift(@genloc13, $gloc13);
							$countrow13++;
					} elsif ( ($count13 == 0) && ($countrow13 >= 1) && (scalar(@genloc13) >= 1) ) {		# succeeding rows of tmap file
						# check distance
						$diff13 = sprintf ("%.6f", $genloc13[0] - $gloc13);
						if ($diff13 >= $mindist) {
							if ( ($temp4[12] eq $temp4[14]) && ($temp4[13] eq $temp4[15]) ) {
								print LOG "Include: $chr13$,$rsid13a$,$gloc13$,$ppos13 | former_genloc\=$genloc13[0] $diff13 $mindist $maf{$rsid13} $markcomp13 $mono13\n";
								push (@subpanel, $temp4);
								unshift(@genloc13, $gloc13);
								$countrow13++;
							} elsif ( ($temp4[12] ne $temp4[14]) || ($temp4[13] ne $temp4[15]) ) {
								# minor alleles of 1KG and dataset don't match
								print LOG "Exclude: Alleles of 1KG and dataset don't match | A1_1KG\=$temp4[12] A2_1KG\=$temp4[13] A1_data\=$temp4[14] A2_data\=$temp4[15]\n";
								push(@temp, $temp4 . " allele_matching_based_pruning");
							}
						} elsif ($diff13 < $mindist) {
							print LOG "Exclude (below minimum distance): $chr13$,$rsid13a$,$gloc13$,$ppos13 | former_genloc\=$genloc13[0] $diff13 $mindist $maf{$rsid13} $markcomp13 $mono13\n";
							push(@temp, $temp4 . " final_distance_based_pruning");
							$countrow13++;
						}
					} elsif ($count13 >= 1) {
						# skip this marker
						print LOG "Exclude (near inclusion marker / already included as inclusion marker / or excluded inclusion marker in panel2): $chr13$,$rsid13a$,$gloc13$,$ppos13\n";
						push(@temp, $temp4 . " inclusion_marker_pruning");
						$countrow13++;
					}
				}
			} else {
				if (!defined($maf{$rsid13})) {	# it could be an inclusion marker
					foreach my $gloc13a (@glocinc) {
						if ($gloc13 == $gloc13a) {
							# it is one of the inclusion markers so use its genloc as the latest genloc[0]
							unshift(@genloc13, $gloc13);
							print LOG "Inclusion marker: $chr13$,$rsid13a$,$gloc13$,$ppos13\n";
						}
					}
				} else {
					if (!defined($maf{$rsid13})) { $maf{$rsid13} = "No_MAF_info"; }
					if (!defined($markcomp13)) { $markcomp13 = "No_markcomp_info"; }
					if (!defined($mono13)) { $mono13 = "No_mono_info"; }
					print LOG "Exclude: $chr13$,$rsid13$,$gloc13$,$ppos13 | $maf{$rsid13} $markcomp13 $mono13\n";
					push(@temp, $temp4 . " no_MAF_markcomp_or_monomorphic_info");
				}
			}
			$count13 = 0;
			NEXT_LINE13_REV:
		}
	}
	
	# Print excluded markers
	# Remove duplicates and inclusion markers from this list
	my (@temp5, @temp6) = ();
	my (%inclu5, %tmp6) = ();
	my ($pru5, $tmp6) = "";
	@temp5 = sort { (split(" ", $a))[3] <=> (split(" ", $b))[3] } @temp;
	my ($chr5, $rsid5, $ppos5, $gloc5, $type5) = "";
	my ($chrom6, $rsid6, $ppos6, $gloc6, $rest6) = "";
	foreach $pru5 (@exc2) {	# checking *pru.tmap
		($chr5, $rsid5, $ppos5, $gloc5, $type5) = "";
		($chr5, $rsid5, $ppos5, $gloc5, $type5) = split (/\s+/, $pru5);
		if (!defined($inclu5{$rsid5})) {
			$inclu5{$rsid5}++;
		}
	}
	foreach $tmp6 (@temp5) {
		($chrom6, $rsid6, $ppos6, $gloc6, $rest6) = "";
		($chrom6, $rsid6, $ppos6, $gloc6, $rest6) = split (/\s+/, $tmp6, 5);
		if ( (!defined($inclu5{$rsid6})) && (!defined($tmp6{$tmp6})) ) {
			push (@temp6, $tmp6);
			$tmp6{$tmp6}++;
		}
	}
	@exc = sort { (split(" ", $a))[3] <=> (split(" ", $b))[3] } @temp6;
	print OUT6 join ("\n", @exc);
	close (OUT6);
	
	# Print prepanel
	my @subpanel2 = sort { (split(" ", $a))[2] <=> (split(" ", $b))[2] } @subpanel;
	if ($kstatprep eq "Y") {
		@list16 = @subpanel2;
		goto SKIP_GAPFILLING;
	} elsif ($kstatprep eq "N") {
		print OUT10 join ("\n", @subpanel2);	# sorted by genetic location
		print OUT10 "\n";
		close (OUT10);
	}
	
	panel_characteristics ($prepanel, $prepanelgaps, $prepaneldesc);
	
	# Use prepanel gaps to go back and fill the gaps
	# then concatenate this with @subpanel2 then sort again to create @subpanel3
	# Template for PLINK to get all pairwise LD (entire chromosome or all given data)
	# Copy tfam file first into a new name to avoid overwriting main tfam file
	my $gap = "$oneKG\_gap";
	
	my (@gapfillers, @lastfiller) = ();
	my $n = 0;
	open (IN16, "<$prepanel") || die ("Could not open $prepanel!\n");
	@list16 = <IN16>;
	close (IN16);
	
	open (IN15, "<$prepanelgaps") || die ("Could not open $prepanel!\n");
	while (defined ($line15 = <IN15>)) {
		chomp $line15;
		next if ($line15 =~ m/^\#/);
		next if (length($line15) == 0);
		$line15 =~ s/^\s+//g;
		$line15 =~ s/\s+$//g;
		@gapfillers = ();
		my ($genstart, $genend, $gapsize) = split (" ", $line15);
		
		# get markers within potential regions
		my $numfillers = ($gapsize/$mindist) - 1;
		if ($numfillers =~ m/(\d+)\./) {
			$numfillers = $1;
		}
		my $mindist2 = $mindist - 0.1;
		my $range = sprintf ("%.6f", ($gapsize - ($mindist * ($numfillers + 1))) / $numfillers);
		if ($range > 0.2) {
			print OUT12A "$genstart$,$genend$,$gapsize$,$mindist$,$numfillers$,$range\n";
			print "\n\nPROCESSING $genstart$,$genend$,$gapsize$,$mindist$,$numfillers$,$range\n";
			print LOG "\n\nPROCESSING $genstart$,$genend$,$gapsize$,$mindist$,$numfillers$,$range\n";
		} elsif ($range <= 0.2) {
			# lower the numfillers by 1
			if ($numfillers > 1) {
				$numfillers -= 1;
			}
			$range = sprintf ("%.6f", ($gapsize - ($mindist2 * ($numfillers + 1))) / $numfillers);
			print OUT12A "$genstart$,$genend$,$gapsize$,$mindist2$,$numfillers$,$range\n";
			print "\n\nPROCESSING $genstart$,$genend$,$gapsize$,$mindist2$,$numfillers$,$range\n";
			print LOG "\n\nPROCESSING $genstart$,$genend$,$gapsize$,$mindist2$,$numfillers$,$range\n";
		}
		my ($iter, $iter2, $countfiller, $rangemin, $rangemax) = 0;
		$iter = 0;
		$iter2 = 0;
		$countfiller = 0;
		for ($n = 1; $n <= ($numfillers + 1); $n++) {
			print "Checking numfiller $n countfiller\=$countfiller iter\=$iter iter2\=$iter2\n";
			print LOG "Checking numfiller $n countfiller\=$countfiller iter\=$iter iter2\=$iter2\n";
			if ( ($countfiller == 0) && ($iter >= 1) ) {
				$n--; # since it added 1 to n after doing one iteration (although unsuccessful)
			}
			$rangemin = sprintf ("%.6f", $genstart + ($n * $mindist2) );
			$rangemax = sprintf ("%.6f", $rangemin + $range );
			# if previous try didn't get any results, try next 01.cM
			if ( ($countfiller == 0) && ($iter >= 1) ) {
				$rangemin += $iter*0.1;
				$rangemax += $iter*0.1;
				if ($rangemax <= $genend) {
					print "Repeating procedure with new range $rangemin\-$rangemax and n is again $n\n";
					print LOG "Repeating procedure with new range $rangemin\-$rangemax and n is again $n\n";
				} elsif ($rangemax > $genend) {
					goto BEYOND_GENEND;
				}
			}
			ITERATE:
			if ( ($iter2 >= 1) && ($countfiller == 0) && ($iter == 0) ){
				$n = $numfillers + 1;
				$rangemin = sprintf ("%.6f", $lastfiller[0] + $mindist2);
				$rangemax = sprintf ("%.6f", $genend - $mindist2);
				print "Iterating with new range $rangemin\-$rangemax and n is set to $n\n";
				print LOG "Iterating with new range $rangemin\-$rangemax and n is set to $n\n";
			}
			# Copy tfam file then create tped file
			chdir("$auxdir");
			system ("cp -p $oneKG\.tfam $auxdir2\/$gap\.tfam");
			# Get flanking markers for tped
			chdir("$auxdir2");
			my (@allmarkers, @allflank, @flank5, @flank3, @handle) = ();
			my $count16 = 0;

			foreach $line16 (@list16) {
				chomp $line16;
				next if ($line16 =~ m/^\#/);
				next if (length($line16) == 0);
				$line16 =~ s/^\s+//g;
				$line16 =~ s/\s+$//g;
				my ($chr16, $marker16, $genloc16, $phypos16, $type16, $rest16) = split (" ", $line16);
				my $temp16 = "$chr16$,$marker16$,$genloc16$,$phypos16";
				if ( (defined($type16)) && ($type16 eq "STS") ) {
					$count16++;
					next;
				}
				unshift (@handle, $temp16);
				if ($n == 1) {
					if ($genloc16 == $genstart) {
						# grab preceding marker and current marker
						if (scalar(@handle) == 1) {
							push (@flank5, $handle[0]);
						} elsif (scalar(@handle) >= 2) {
							push (@flank5, $handle[1]);
							push (@flank5, $handle[0]);
						}
					}
				} elsif ($n > 1) {
					if ( (scalar(@lastfiller) == 0) && ($genloc16 == $genstart) ) {
						# grab preceding marker and current marker
						if (scalar(@handle) == 1) {
							push (@flank5, $handle[0]);
						} elsif (scalar(@handle) >= 2) {
							push (@flank5, $handle[1]);
							push (@flank5, $handle[0]);
						}
						########
					} elsif ( (scalar(@lastfiller) >= 1) && ($lastfiller[0] > $genstart) && ($genloc16 == $lastfiller[0]) ) {
						# grab preceding marker and current marker
						if (scalar(@handle) == 1) {
							push (@flank5, $handle[0]);
						} elsif (scalar(@handle) >= 2) {
							push (@flank5, $handle[1]);
							push (@flank5, $handle[0]);
						}
					} elsif ( (scalar(@lastfiller) >= 1) && ($lastfiller[0] < $genstart) && ($genloc16 == $genstart) ) {
						# grab preceding marker and current marker
						if (scalar(@handle) == 1) {
							push (@flank5, $handle[0]);
						} elsif (scalar(@handle) >= 2) {
							push (@flank5, $handle[1]);
							push (@flank5, $handle[0]);
						}
					}
				}
				if ( ($genloc16 == $genend) && ($count16 == ($#list16) ) ) {
					# this means that the first 3' flanking marker is already at index 0 of @handle)
					push (@flank3, $handle[0]);
					#print "2177 handle\[0\]\=$handle[0]\n";
					last;
				} elsif ($genloc16 > $genend) {
					# this means that the 3' flanking markers are already at index 1 and 0 of @handle)
					if (scalar(@flank3) == 0) {
						push (@flank3, $handle[1]);
						push (@flank3, $handle[0]);
					}
				}
				$count16++;
			}
			close (IN16);
			
			push (@allmarkers, @flank5);
			push (@allflank, @flank5);
			push (@allmarkers, @flank3);
			push (@allflank, @flank3);
			(@flank5, @flank3) = ();
			open (IN17, "<$exctmap") || die ("Could not open $exctmap!\n");
			while (defined ($line17 = <IN17>)) {
				chomp $line17;
				next if ($line17 =~ m/^\#/);
				next if (length($line17) == 0);
				$line17 =~ s/^\s+//g;
				$line17 =~ s/\s+$//g;
				my ($chr17, $marker17, $genloc17, $phypos17, $type17, $remarks17) = split (" ", $line17);
				if ($genloc17 =~ m/NA/) {
					print "line17\=$line17\n";
				}
				my $temp17 = "$chr17$,$marker17$,$genloc17$,$phypos17";
				if ( (defined($type17)) && ($type17 eq "STS") ) {
					next;
				} elsif  ( ($genloc17 >= $rangemin) && ($genloc17 <= $rangemax) ) {
					print "\t$chr17$,$marker17$,$genloc17$,$phypos17$,$type17$,$remarks17\n";
					print LOG "\t$chr17$,$marker17$,$genloc17$,$phypos17$,$type17$,$remarks17\n";
					if ($remarks17 =~ m/maf\=(\d\.\d+)/) {
						my $maf17 = $1;
						# decrease MAF minimum by 0.05
						if ($maf17 <= $mafmin - 0.05) { next; }
						elsif ($maf17 >= $mafmax) { next; }
					} else {
						if (defined($matchKGppos{$marker17})) {
							if ( (defined($markcomp{$matchKGppos{$marker17}})) && ($markcomp{$matchKGppos{$marker17}} < $markcompt) ) {
								next;
							} elsif ( (defined($mono{$chr17}{$matchKGppos{$marker17}})) && ($mono{$chr17}{$matchKGppos{$marker17}} eq "Y") ) {
								next;
							}
						} elsif (!defined($matchKGppos{$marker17})) {
							if ( (defined($markcomp{$marker17})) && ($markcomp{$marker17} < $markcompt) ) {
								next;
							} elsif ( (defined($mono{$chr17}{$marker17})) && ($mono{$chr17}{$marker17} eq "Y") ) {
								next;
							}
						}
					}
					
					push (@allmarkers, $temp17);
					push (@gapfillers, $temp17);
				}
				if ($genloc17 > $rangemax) {
					last;
				}
			}
			close (IN16);
			
			print "Markers for tped...\n";
			print LOG "Markers for tped...\n";
			my @allmarkerstmp = uniq(@allmarkers);
			my @allmarkers2 = sort { (split(" ", $a))[2] <=> (split(" ", $b))[2] } @allmarkerstmp;
			
			print join (" | ", @allmarkers2);
			print "\n";
			print LOG join (" | ", @allmarkers2);
			print LOG "\n";
			if ( (scalar(@allflank) == 3) && (scalar(@allmarkers2) == 3) ) {
				# no markers are within this region or nothing passed
				$iter++;
				next;
			} elsif ( (scalar(@allflank) == 4) && (scalar(@allmarkers2) == 4) ) {
				# no markers are within this region or nothing passed
				$iter++;
				next;
			}
			
			
			chdir("$auxdir2");
			# Grep using physical position
			if ( -e "$auxdir2\/$gap\.tped" ) {
				system ("rm $auxdir2\/$gap\.tped");
			}
			my %seen4grep = ();
			foreach my $temp18 (@allmarkers) {
				my ($chr18, $marker18, $genloc18, $phypos18) = split (" ", $temp18);
				my $grepper18 = "\" $phypos18 \"";
				if (!defined($seen4grep{$phypos18})) {
					system ("grep $grepper18 $auxdir\/$oneKG\.tped >> $auxdir2\/$gap\.tped");
					$seen4grep{$phypos18}++;
				} elsif (defined($seen4grep{$phypos18})) {
					next;
				}
			}
			%seen4grep = ();
			system("$plink --tfile $gap --noweb --allow-no-sex --r2 --inter-chr --ld-window-r2 0 --out $gap");
			if (scalar(@lastfiller) == 0) {
				system("cp -p $gap\.tped $gap\_$genstart\_$rangemin\-$rangemax\.tped");
				system("cp -p $gap\.ld $gap\_$genstart\_$rangemin\-$rangemax\.ld");
				system("cp -p $gap\.log $gap\_$genstart\_$rangemin\-$rangemax\.log");
			} elsif (scalar(@lastfiller) >= 1) {
				system("cp -p $gap\.tped $gap\_$lastfiller[0]\_$rangemin\-$rangemax\.tped");
				system("cp -p $gap\.ld $gap\_$lastfiller[0]\_$rangemin\-$rangemax\.ld");
				system("cp -p $gap\.log $gap\_$lastfiller[0]\_$rangemin\-$rangemax\.log");
			}
			foreach my $gapfiller (@gapfillers) {
				print "check gapfiller $gapfiller\n";
				print LOG "check gapfiller $gapfiller\n";
				my ($chr19, $marker19, $genloc19, $phypos19) = split (" ", $gapfiller);
				my $grepper19 = " $marker19 ";
				my $ldfile = "$gap\.ld";
				my $aboveld = 0;
				foreach my $allflank (@allflank) {
					my ($chr18a, $marker18a, $genloc18a, $phypos18a) = split (" ", $allflank);
					open (IN20, "<$ldfile") || die ("Could not open $ldfile!\n");
					while (defined ($line20 = <IN20>)) {
						chomp $line20;
						next if ($line20 =~ m/^\#/);
						next if (length($line20) == 0);
						$line20 =~ s/^\s+//g;
						$line20 =~ s/\s+$//g;
						my ($chr20a, $phypos20a, $marker20a, $chr20b, $phypos20b, $marker20b, $r2_20) = split (/\s+/, $line20);
						if ( ( ($marker20a eq $marker18a) && ($marker20b eq $marker19) ) || ( ($marker20a eq $marker19) && ($marker20b eq $marker18a) ) ) {
							if ($r2_20 > $r2max) {
								$aboveld++;
							}
						}
					}
				}
				my $temp20 = "";
				
				# Check if STS distance is defined
				# If potental gapfiller is within this range, we cannot use this marker
				if ( (defined($stsdist)) && ($stsdist != 0) ) {
					# exclude all potential markers within the gapfillexc ranges
					foreach my $rangeexc (@gapfillexc) {
						my ($rangeexcs, $rangeexce) = split (/\s+/, $rangeexc);
						if ( ($genloc19 > ($rangeexcs)) && ($genloc19 < ($rangeexce)) ) {
							print "$gapfiller cannot be used as gapfiller for $genstart\-$genend since it is within the boundaries ($rangeexcs\-$rangeexce) of a core inclusion STS marker\n";
							print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend since it is within the boundaries ($rangeexcs\-$rangeexce) of a core inclusion STS marker\n";
							goto NEXT_GAPFILLER;
						}
					}
				}
				if ($aboveld >= 1) {
					print "$gapfiller cannot be used as gapfiller for $genstart\-$genend due to LD\n";
					print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend due to LD\n";
					next;
				} elsif ($aboveld == 0) {
					# This may be our gapfiller
					if (defined($matchKGppos{$marker19})) {
						if ( (defined($markcomp{$chr19}{$matchKGppos{$marker19}})) && ($markcomp{$chr19}{$matchKGppos{$marker19}} >= $markcompt) ) {
							if ( (defined($mono{$chr19}{$matchKGppos{$marker19}})) && ($mono{$chr19}{$matchKGppos{$marker19}} eq "N") ) {
								if ( (defined($mainmaf{$matchKGppos{$marker19}})) && ($mainmaf{$matchKGppos{$marker19}} >= $mafmin - 0.05) && ($mainmaf{$matchKGppos{$marker19}} <= $mafmax) && (!defined($exclude{$matchKGppos{$marker19}})) ) {
									$temp20 = "$chr19$,$matchKGppos{$marker19}$,$gloc8{$chr19}{$matchKGppos{$marker19}}$,$phypos19$,SNP$,$markcomp{$chr19}{$matchKGppos{$marker19}}$,$maf3{$chr19}{$matchKGppos{$marker19}}$,$exphet3{$chr19}{$matchKGppos{$marker19}}$,$obshet3{$chr19}{$matchKGppos{$marker19}}$,$maf2{$chr19}{$matchKGppos{$marker19}}$,$exphet2{$chr19}{$matchKGppos{$marker19}}$,$obshet2{$chr19}{$matchKGppos{$marker19}}$,$A1_1KG{$chr19}{$matchKGppos{$marker19}}$,$A2_1KG{$chr19}{$matchKGppos{$marker19}}$,$A1_data{$chr19}{$matchKGppos{$marker19}}$,$A2_data{$chr19}{$matchKGppos{$marker19}}";
									if (scalar(@lastfiller) == 0) {
										print "Gapfiller A\=$temp20\n\n";
										print LOG "Gapfiller A\=$temp20\n\n";
										push (@subpanel2, $temp20);
										unshift (@lastfiller, $gloc8{$chr19}{$matchKGppos{$marker19}});
										$countfiller++;
										last;
									} elsif ( (scalar(@lastfiller) >= 1) || ($iter2 >= 1) ) {
										if ( (defined($gloc8{$chr19}{$matchKGppos{$marker19}})) && (($genend - $gloc8{$chr19}{$matchKGppos{$marker19}}) >= $mindist2) && (($gloc8{$chr19}{$matchKGppos{$marker19}} - $lastfiller[0]) >= $mindist2) ) {
											print "Gapfiller A\=$temp20\n\n";
											print LOG "Gapfiller A\=$temp20\n\n";
											push (@subpanel2, $temp20);
											unshift (@lastfiller, $gloc8{$chr19}{$matchKGppos{$marker19}});
											$countfiller++;
											last;
										} elsif ( (defined($gloc8{$chr19}{$matchKGppos{$marker19}})) && (($genend - $gloc8{$chr19}{$matchKGppos{$marker19}}) < $mindist2) && (($gloc8{$chr19}{$matchKGppos{$marker19}} - $lastfiller[0]) >= $mindist2) ) {
											print "$gapfiller cannot be used as gapfiller for $genstart\-$genend since nearest downstream marker is less than $mindist2 cM away\n";
											print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend since nearest downstream marker is less than $mindist2 cM away\n";
										}
									}
								} elsif ( (defined($mainmaf{$matchKGppos{$marker19}})) && ($mainmaf{$matchKGppos{$marker19}} < ($mafmin - 0.05)) || ($mainmaf{$matchKGppos{$marker19}} > $mafmax) ) {
									print "$gapfiller cannot be used as gapfiller for $genstart\-$genend because MAF of $mainmaf{$matchKGppos{$marker19}}\n";
									print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend because MAF of $mainmaf{$matchKGppos{$marker19}}\n";
								}
							} elsif ( (defined($mono{$chr19}{$matchKGppos{$marker19}})) && ($mono{$chr19}{$matchKGppos{$marker19}} eq "Y") ) {
								print "$gapfiller cannot be used as gapfiller for $genstart\-$genend because it is monomorphic in your dataset\n";
								print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend because it is monomorphic in your dataset\n";
							}
						} elsif ( (defined($markcomp{$chr19}{$matchKGppos{$marker19}})) && ($markcomp{$chr19}{$matchKGppos{$marker19}} < $markcompt) ) {
							print "$gapfiller cannot be used as gapfiller for $genstart\-$genend because marker completion in your dataset is less than $markcompt\n";
							print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend because marker completion in your dataset is less than $markcompt\n";
						}
					} elsif (!defined($matchKGppos{$marker19})) {
						if ( (defined($markcomp{$chr19}{$marker19})) && ($markcomp{$chr19}{$marker19} >= $markcompt) ) {
							if ( (defined($mono{$chr19}{$marker19})) && ($mono{$chr19}{$marker19} eq "N") ) {
								if ( (defined($mainmaf{$marker19})) && ($mainmaf{$marker19} >= $mafmin - 0.05) && ($mainmaf{$marker19} <= $mafmax) && (!defined($exclude{$marker19})) ) {
									$temp20 = "$chr19$,$marker19$,$gloc8{$chr19}{$marker19}$,$phypos19$,SNP$,$markcomp{$chr19}{$marker19}$,$maf3{$chr19}{$marker19}$,$exphet3{$chr19}{$marker19}$,$obshet3{$chr19}{$marker19}$,$maf2{$chr19}{$marker19}$,$exphet2{$chr19}{$marker19}$,$obshet2{$chr19}{$marker19}$,$A1_1KG{$chr19}{$marker19}$,$A2_1KG{$chr19}{$marker19}$,$A1_data{$chr19}{$marker19}$,$A2_data{$chr19}{$marker19}";
									if (scalar(@lastfiller) == 0) {
										print "Gapfiller B\=$temp20\n\n";
										print LOG "Gapfiller B\=$temp20\n\n";
										push (@subpanel2, $temp20);
										unshift (@lastfiller, $gloc8{$chr19}{$marker19});
										$countfiller++;
										last;
									} elsif ( (scalar(@lastfiller) >= 1) || ($iter2 >= 1) ) {
										if ( (defined($gloc8{$chr19}{$marker19})) && (($genend - $gloc8{$chr19}{$marker19}) >= $mindist2) && (($gloc8{$chr19}{$marker19} - $lastfiller[0]) >= $mindist2) ) {
											print "Gapfiller B\=$temp20\n\n";
											print LOG "Gapfiller B\=$temp20\n\n";
											push (@subpanel2, $temp20);
											unshift (@lastfiller, $gloc8{$chr19}{$marker19});
											$countfiller++;
											last;
										} elsif ( (defined($gloc8{$chr19}{$marker19})) && (($genend - $gloc8{$chr19}{$marker19}) < $mindist2) && (($gloc8{$chr19}{$marker19} - $lastfiller[0]) >= $mindist2) ) {
											print "$gapfiller cannot be used as gapfiller for $genstart\-$genend since nearest downstream marker is less than $mindist2 cM away\n";
											print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend since nearest downstream marker is less than $mindist2 cM away\n";
										}
									}
								} elsif ( (defined($mainmaf{$marker19})) && ( ($mainmaf{$marker19} < ($mafmin - 0.05)) || ($mainmaf{$marker19} > $mafmax) ) ) {
									print "$gapfiller cannot be used as gapfiller for $genstart\-$genend because MAF of $mainmaf{$marker19}\n";
									print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend because MAF of $mainmaf{$marker19}\n";
								}
							} elsif ( (defined($mono{$chr19}{$marker19})) && ($mono{$chr19}{$marker19} eq "Y") ) {
								print "$gapfiller cannot be used as gapfiller for $genstart\-$genend because it is monomorphic in your dataset\n";
								print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend because it is monomorphic in your dataset\n";
							}
						} elsif ( (defined($markcomp{$chr19}{$marker19})) && ($markcomp{$chr19}{$marker19} < $markcompt) ) {
							print "$gapfiller cannot be used as gapfiller for $genstart\-$genend because marker completion in your dataset is less than $markcompt\n";
							print LOG "$gapfiller cannot be used as gapfiller for $genstart\-$genend because marker completion in your dataset is less than $markcompt\n";
						}
					}
				}
				close (IN20);
				NEXT_GAPFILLER:
			}

			@list16 = ();
			@list16 = sort { (split(" ", $a))[2] <=> (split(" ", $b))[2] } @subpanel2;
			(@allmarkers, @allflank, @flank5, @flank3, @handle, @gapfillers) = ();
			$iter = 0;
			$countfiller = 0;
			
			`rm -r $auxdir2\/$gap\.tped`;
		}
		if ( ( (scalar(@lastfiller) >= 1) && ($genend - $lastfiller[0]) >= (2*$mindist2) ) && ($lastfiller[0] > $genstart) && ($lastfiller[0] < $genend) ) {
			print "We can still look for another gapfiller since the last gapfiller is still more than twice $mindist2 cM away from $genend\n";
			print "lastfiller\=$lastfiller[0]\n";
			print LOG "We can still look for another gapfiller since the last gapfiller is still more than twice $mindist2 cM away from $genend\n";
			print LOG "lastfiller\=$lastfiller[0]\n";
			$iter2++;
			print "iter2\=$iter2\n";
			print LOG "iter2\=$iter2\n";
			if ( -e "$auxdir2\/$gap\.tped" ) {
				`rm -r $auxdir2\/$gap\.tped`;
			}
			if ($iter2 <= 5) {
				goto ITERATE;
			} elsif ($iter2 > 5) {
				print "Stop iterating\n";
				$iter2 = 0;
			}
		}
		BEYOND_GENEND:
		$iter2 = 0;
	}
	close (OUT12A);
	`rm -r $auxdir2\/$gap\.ld`;
	`rm -r $auxdir2\/$gap\.log`;
	
	SKIP_GAPFILLING:
	if ($kstatprep eq "Y") {
		if ($option == 1) {
			system ("cp -p $idfile $chrdir\/chr$chr\.tind");
		} elsif ($option == 2) {
			system ("cp -p $idin $chrdir\/chr$chr\.tind");
		}
	}
	my ($count16, $gdist16, $pdist16) = 0;
	my (@gloc16, @ppos16) = ();
	foreach my $line16a (@list16) {
		chomp $line16a;
		next if ($line16a =~ m/^\#/);
		next if (length($line16a) == 0);
		$line16a =~ s/^\s+//g;
		$line16a =~ s/\s+$//g;
		my ($f1, $f2, $f3, $f4, $f5, $f6, $f7, $f8, $f9, $f10, $f11, $f12, $f13, $f14, $f15, $f16) = split (" ", $line16a);
		next if ( ($kstatprep eq "Y") && ($f5 eq "STS") );
		if ($count16 == 0) {
			$gdist16 = sprintf ("%.6f", 0);
			unshift (@gloc16, $f3);
			$pdist16 = sprintf ("%.6f", 0);
			unshift (@ppos16, $f4);
		} elsif ($count16 >= 1) {
			$gdist16 = sprintf ("%.6f", $f3 - $gloc16[0]);
			unshift (@gloc16, $f3);
			if ( (defined($ppos16[0])) && ($f4 !~ m/NA/) ) {
				$pdist16 = sprintf ("%.6f", ($f4 - $ppos16[0])/1000000);
				unshift (@ppos16, $f4);
			} elsif ( (!defined($ppos16[0])) || ($f4 =~ m/NA/) ) {
				$pdist16 = "NA";
			}
		}
		if ( ($kstatprep eq "Y") && ($f5 eq "SNP") ) {
			print OUT13 "$f1$,$f2$,$f3$,$f4$,$f5$,$f6$,$f7$,$f8$,$f9$,$f10$,$f11$,$f12$,$f13$,$f14$,$f15$,$f16$,$gdist16$,$pdist16\n";
			print OUT15 "$f1$,$f2$,$markgen{$f1}{$f2}\n";
		} elsif ($kstatprep eq "N") {
			print OUT13 "$f1$,$f2$,$f3$,$f4$,$f5$,$f6$,$f7$,$f8$,$f9$,$f10$,$f11$,$f12$,$f13$,$f14$,$f15$,$f16$,$gdist16$,$pdist16\n";
		}
		$count16++;
	}
	close (OUT13);
	if ($kstatprep eq "Y") {
		close (OUT15);
	}
	
	foreach my $subpanel3 (@list16) {
		chomp $subpanel3;
		my ($s0, $s1, $s2, $s3, $s4, $rest) = split (" ", $subpanel3, 6);
		$panels[$k]{$s3}++;
	}
	
	
	close (IN15);
	
	panel_characteristics3 ($panelfile, $paneldesc);
	
	
	print "Subpanel $panel created\n";
	print LOG "Subpanel $panel created\n";
	
	# Delete some files (comment out the rows below if you want to keep these files in aux directory)
	#print "$oneKG\_$window\_$increment\_$r2part\n";
	#`rm $oneKG\_$window\_$increment\_$r2part\.*`;
	
	
	# Delete aux2 directory (comment out the row below if you want to keep aux2 directory)
	# `rm -r $auxdir2`;
	
	(@subpanel, @subpanel2, @list16) = ();
	chdir("$scriptdir");
	%mainmaf = ();
}

sub panel_characteristics {
	my $panelfile = $_[0];
	my $panelgaps = $_[1];
	my $outfile   = $_[2];
	$mindist = $mindist;
	my (@genloc, @phypos, @ghold, @phold, @markcomp, @gdiff, @pdiff, @MbpercM) = ();
	my (@af1KG, @ehet1KG, @ohet1KG, @afdata, @ehetdata, @ohetdata) = ();
	my ($mcount, $gdiff, $pdiff) = 0;
	open (IN, "<$panelfile") || die ("Could not open $panelfile!\n");
	while (defined ($line1 = <IN>)) {
		chomp $line1;
		next if ($line1 =~ m/^\#/);
		next if (length($line1) == 0);
		$line1 =~ s/^\s+//g;
		$line1 =~ s/\s+$//g;
		my ($chr1, $marker, $genloc, $phypos, $type, $markcomp, $af1KG, $ehet1KG, $ohet1KG, $afdata, $ehetdata, $ohetdata) = split (/\s/, $line1);
		if ($genloc !~ m/NA/) {
			$genloc = sprintf ("%.6f", $genloc);
			push (@genloc, $genloc);
		}
		if ($phypos !~ m/NA/) {
			$phypos = sprintf ("%.6f", $phypos/1000000);
			push (@phypos, $phypos);
		}
		if ($type eq "SNP") {
			if ($markcomp !~ m/NA/) { push(@markcomp, $markcomp); }
			if ($af1KG !~ m/NA/) { push(@af1KG, $af1KG); }
			if ($ehet1KG !~ m/NA/) { push(@ehet1KG, $ehet1KG); }
			if ($ohet1KG !~ m/NA/) { push(@ohet1KG, $ohet1KG); }
			if ($afdata !~ m/NA/) { push(@afdata, $afdata); }
			if ($ehetdata !~ m/NA/) { push(@ehetdata, $ehetdata); }
			if ($ohetdata !~ m/NA/) { push(@ohetdata, $ohetdata); }
		}
		if ($mcount == 0) {
			if ($genloc !~ m/NA/) {
				unshift(@ghold, $genloc);
			}
			if ($phypos !~ m/NA/) {
				unshift(@phold, $phypos);
			}

		} elsif ($mcount >= 1) {
			if ($genloc !~ m/NA/) {
				$gdiff = sprintf ("%.6f", $genloc - $ghold[0]);
				my $gapdist = 2 * $mindist;
				if ($gdiff >= $gapdist) {		# >= 2 X user-specified minimum distance
						print OUT12 "$ghold[0]$,$genloc$,$gdiff\n";
				}
				push (@gdiff, $gdiff);
				unshift(@ghold, $genloc);
			}
			if ($phypos !~ m/NA/) {
				$pdiff = $phypos - $phold[0];
				push (@pdiff, $pdiff);
				unshift(@phold, $phypos);
			}
			if ( (defined($pdiff)) && (defined($gdiff)) && ($gdiff > 0) ) {
				my $MbpercM = sprintf ("%.6f", $pdiff/$gdiff);
				push (@MbpercM, $MbpercM);
			}
			
		}
		if ($genloc !~ m/NA/) {
			$mcount++;
		}
	}
	close (IN);
		close (OUT12);


	my ($count, $min, $lq, $med, $uq, $max, $mean, $var, $stdev) = 0;
	print OUT11 "Parameter$,Number_of_Markers$,Mean$,Variance$,Standard_deviation$,Minimum$,Lower_quartile$,Median$,Upper_quartile$,Maximum\n";

	my $stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@gdiff);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT11 "Intermarker_distance_cM$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@pdiff);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT11 "Intermarker_distance_Mbp$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@MbpercM);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT11 "Mbp_per_cM$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@markcomp);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.2f", $mean);
	$var  = sprintf ("%.2f", $var);
	$stdev = sprintf ("%.2f", $stdev);
	$min = sprintf ("%.2f", $min);
	$lq  = sprintf ("%.2f", $lq);
	$med = sprintf ("%.2f", $med);
	$uq  = sprintf ("%.2f", $uq);
	$max = sprintf ("%.2f", $max);
	print OUT11 "Marker_completion$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@af1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT11 "MAF_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ehet1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT11 "Expected_heterozygosity_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ohet1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT11 "Observed_heterozygosity_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@afdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT11 "MAF_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ehetdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT11 "Expected_heterozygosity_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ohetdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT11 "Observed_heterozygosity_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	close (OUT11);
}


sub panel_characteristics2 {
	my $panelfile  = $_[0];
	my $outfile    = $_[1];
	
	my (@genloc, @phypos, @ghold, @phold, @markcomp, @gdiff, @pdiff, @MbpercM) = ();
	my (@af1KG, @ehet1KG, @ohet1KG, @afdata, @ehetdata, @ohetdata) = ();
	my ($mcount, $gdiff, $pdiff) = 0;
	open (IN, "<$panelfile") || die ("Could not open $panelfile!\n");
	while (defined ($line1 = <IN>)) {
		chomp $line1;
		next if ($line1 =~ m/^\#/);
		next if (length($line1) == 0);
		$line1 =~ s/^\s+//g;
		$line1 =~ s/\s+$//g;
		my ($chr1, $marker, $genloc, $phypos, $type, $markcomp, $af1KG, $ehet1KG, $ohet1KG, $afdata, $ehetdata, $ohetdata) = split (/\s/, $line1);
		$genloc = sprintf ("%.6f", $genloc);
		$phypos = sprintf ("%.6f", $phypos/1000000);	#phypos in Mbp
		if ($genloc !~ m/NA/) { push (@genloc, $genloc); }
		if ($phypos !~ m/NA/) { push (@phypos, $phypos); }
		if ($markcomp !~ m/NA/) { push(@markcomp, $markcomp); }
		if ($af1KG !~ m/NA/) { push(@af1KG, $af1KG); }
		if ($ehet1KG !~ m/NA/) { push(@ehet1KG, $ehet1KG); }
		if ($ohet1KG !~ m/NA/) { push(@ohet1KG, $ohet1KG); }
		if ($afdata !~ m/NA/) { push(@afdata, $afdata); }
		if ($ehetdata !~ m/NA/) { push(@ehetdata, $ehetdata); }
		if ($ohetdata !~ m/NA/) { push(@ohetdata, $ohetdata); }

		if ($mcount == 0) {
			unshift(@ghold, $genloc);
			unshift(@phold, $phypos);

		} elsif ($mcount >= 1) {
			$gdiff = sprintf ("%.6f", $genloc - $ghold[0]);
			push (@gdiff, $gdiff);
			unshift(@ghold, $genloc);
			$pdiff = $phypos - $phold[0];
			push (@pdiff, $pdiff);
			unshift(@phold, $phypos);
			if ($gdiff > 0) {
				my $MbpercM = sprintf ("%.6f", $pdiff/$gdiff);
				push (@MbpercM, $MbpercM);
			}
			
		}
		$mcount++;
	}
	close (IN);

	my ($count, $min, $lq, $med, $uq, $max, $mean, $var, $stdev) = 0;
	print OUT9A "Parameter$,Number_of_Markers$,Mean$,Variance$,Standard_deviation$,Minimum$,Lower_quartile$,Median$,Upper_quartile$,Maximum\n";

	my $stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@gdiff);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT9A "Intermarker_distance_cM$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@pdiff);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT9A "Intermarker_distance_Mbp$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@MbpercM);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT9A "Mbp_per_cM$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@markcomp);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.2f", $mean);
	$var  = sprintf ("%.2f", $var);
	$stdev = sprintf ("%.2f", $stdev);
	$min = sprintf ("%.2f", $min);
	$lq  = sprintf ("%.2f", $lq);
	$med = sprintf ("%.2f", $med);
	$uq  = sprintf ("%.2f", $uq);
	$max = sprintf ("%.2f", $max);
	print OUT9A "Marker_completion$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@af1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT9A "MAF_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ehet1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT9A "Expected_heterozygosity_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ohet1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT9A "Observed_heterozygosity_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@afdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT9A "MAF_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ehetdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT9A "Expected_heterozygosity_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ohetdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT9A "Observed_heterozygosity_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	close (OUT9A);
}

sub panel_characteristics3 {
	my $panelfile  = $_[0];
	my $outfile    = $_[1];
	
	my (@genloc, @phypos, @ghold, @phold, @markcomp, @gdiff, @pdiff, @MbpercM) = ();
	my (@af1KG, @ehet1KG, @ohet1KG, @afdata, @ehetdata, @ohetdata) = ();
	my ($mcount, $gdiff, $pdiff) = 0;
	open (IN, "<$panelfile") || die ("Could not open $panelfile!\n");
	while (defined ($line1 = <IN>)) {
		chomp $line1;
		next if ($line1 =~ m/^\#/);
		next if (length($line1) == 0);
		$line1 =~ s/^\s+//g;
		$line1 =~ s/\s+$//g;
		my ($chr1, $marker, $genloc, $phypos, $type, $markcomp, $af1KG, $ehet1KG, $ohet1KG, $afdata, $ehetdata, $ohetdata) = split (/\s/, $line1);
		if ($genloc !~ m/NA/) {
			$genloc = sprintf ("%.6f", $genloc);
			push (@genloc, $genloc);
		}
		if ($phypos !~ m/NA/) {
			$phypos = sprintf ("%.6f", $phypos/1000000);
			push (@phypos, $phypos);
		}
		if ($type eq "SNP") {
			if ($markcomp !~ m/NA/) { push(@markcomp, $markcomp); }
			if ($af1KG !~ m/NA/) { push(@af1KG, $af1KG); }
			if ($ehet1KG !~ m/NA/) { push(@ehet1KG, $ehet1KG); }
			if ($ohet1KG !~ m/NA/) { push(@ohet1KG, $ohet1KG); }
			if ($afdata !~ m/NA/) { push(@afdata, $afdata); }
			if ($ehetdata !~ m/NA/) { push(@ehetdata, $ehetdata); }
			if ($ohetdata !~ m/NA/) { push(@ohetdata, $ohetdata); }
		}
		if ($mcount == 0) {
			if ($genloc !~ m/NA/) {
				unshift(@ghold, $genloc);
				$gdiff = sprintf ("%.6f", $genloc - $ghold[0]);
			}
			if ($phypos !~ m/NA/) {
				unshift(@phold, $phypos);
				$pdiff = $phypos - $phold[0];
			}
		} elsif ($mcount >= 1) {
			if ($genloc !~ m/NA/) {
				$gdiff = sprintf ("%.6f", $genloc - $ghold[0]);
				push (@gdiff, $gdiff);
				unshift(@ghold, $genloc);
			}
			if ($phypos !~ m/NA/) {
				$pdiff = $phypos - $phold[0];
				push (@pdiff, $pdiff);
				unshift(@phold, $phypos);
			}
			if ( (defined($pdiff)) && (defined($gdiff)) && ($gdiff > 0) ) {
				my $MbpercM = sprintf ("%.6f", $pdiff/$gdiff);
				push (@MbpercM, $MbpercM);
			}
			
		}
		if ($genloc !~ m/NA/) {
			$mcount++;
		}
	}
	close (IN);

	my ($count, $min, $lq, $med, $uq, $max, $mean, $var, $stdev) = 0;
	print OUT14 "Parameter$,Number_of_Markers$,Mean$,Variance$,Standard_deviation$,Minimum$,Lower_quartile$,Median$,Upper_quartile$,Maximum\n";

	my $stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@gdiff);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT14 "Intermarker_distance_cM$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@pdiff);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT14 "Intermarker_distance_Mbp$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@MbpercM);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	$count += 1;
	print OUT14 "Mbp_per_cM$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@markcomp);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.2f", $mean);
	$var  = sprintf ("%.2f", $var);
	$stdev = sprintf ("%.2f", $stdev);
	$min = sprintf ("%.2f", $min);
	$lq  = sprintf ("%.2f", $lq);
	$med = sprintf ("%.2f", $med);
	$uq  = sprintf ("%.2f", $uq);
	$max = sprintf ("%.2f", $max);
	print OUT14 "Marker_completion$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@af1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT14 "MAF_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ehet1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT14 "Expected_heterozygosity_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ohet1KG);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT14 "Observed_heterozygosity_1KG$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@afdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT14 "MAF_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ehetdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT14 "Expected_heterozygosity_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	$stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@ohetdata);
	$count = $stat->count();				# number of values
	$mean  = $stat->mean();					# mean
	$var   = $stat->variance();				# variance
	$stdev = $stat->standard_deviation();	# standard deviation
	$min   = $stat->quantile(0);			# minimal value
	$lq    = $stat->quantile(1);			# lower quartile = lowest cut off (25%) of data = 25th percentile
	$med   = $stat->quantile(2);			# median = it cuts data set in half = 50th percentile
	$uq    = $stat->quantile(3);			# upper quartile = highest cut off (25%) of data, or lowest 75% = 75th percentile
	$max   = $stat->quantile(4);			# maximal value
	$mean = sprintf ("%.6f", $mean);
	$var  = sprintf ("%.6f", $var);
	$stdev = sprintf ("%.6f", $stdev);
	$min = sprintf ("%.6f", $min);
	$lq  = sprintf ("%.6f", $lq);
	$med = sprintf ("%.6f", $med);
	$uq  = sprintf ("%.6f", $uq);
	$max = sprintf ("%.6f", $max);
	print OUT14 "Observed_heterozygosity_dataset$,$count$,$mean$,$var$,$stdev$,$min$,$lq$,$med$,$uq$,$max\n";

	close (OUT14);
}

sub uniq {
	my %seen;
	grep !$seen{$_}++, @_;
}
