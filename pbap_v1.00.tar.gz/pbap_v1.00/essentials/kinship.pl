#!/usr/bin/perl -w
#
# Yoonha Choi and Mark Marchani   Date: July 12, 2007
#
# Purpose:
#  Compute kinship coefficient from estimated k-statistics by
#  - kinship coeff = 1/2*k2 + 1/4 *k1
#
# Usage:
#  ./kinship.pl <Infile> <Outfile>
#  e.g.) ./kinship.pl comb.out comb.kin
#
# Input file: the result file from "kstat.pl"
#  columns - sub_1 sub_2  k0  k1  k2  N_mrk  N_itr
#  e.g) comb.out
#
# Output file:
#  columns - sub_1 sub_2 kinship
#
#####

########## ARGUEMENT ################

if(@ARGV<2){
  print "\nUSAGE: ./kinship.pl <Infile> <Outfile>\n";
  print "EXAMPLE: ./kinship.pl comb.out comb.kin\n";
  exit(0);
}

($infile,$outfile) = @ARGV;

############ MAIN #################

open(IN,"<$infile")or die "Couldn't open $infile \n";
open(OUT,">$outfile")or die "Couldn't open $outfile \n";
printf OUT ("%10s %10s %10s\n","sub_1","sub_2","kin");

my $header = <IN>;
while(<IN>){

  my @line=split(" ",$_);
  my $line_length = @line;
  unless ($line_length == 5 || $line_length == 7 || $line_length == 11)
    {
     die "Wrong number of arguments in the line read.  There are $line_length items in the line.\n";
     }

  if ($line_length == 5 || $line_length == 7) 
    { $sub1 = $line[0];
      $sub2 = $line[1];
      $k1   = $line[3];
      $k2   = $line[4];

      $kin = 1/2*$k2 + 1/4*$k1;
      printf OUT ("%10s %10s %10s\n",$sub1,$sub2,$kin);
      } else        
        { $sub1 = $line[0];
          $sub2 = $line[1];
          $d1   = $line[2];
          $d3   = $line[4];
          $d5   = $line[6];
          $d7   = $line[8];
          $d8   = $line[9];

          $kin = $d1 + 1/2 * ($d3 + $d5 + $d7) + 1/4 * $d8;
          printf OUT ("%10s %10s %10s\n",$sub1,$sub2,$kin);
          
         }
}
close(IN);
close(OUT);

