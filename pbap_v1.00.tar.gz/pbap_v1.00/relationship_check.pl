#!/usr/bin/perl
# ./relcheck.pl
# By Alejandro Q. Nato, Jr., Ph.D.
# This script compares pairwise kinship coefficients based on the pedigree 
# structure with the empirical kinship coefficients estimated using genotype
# data by using the output files of kped.pl and kstat.pl.
# Limitation: we can only compare individuals with genotype data
# Essential file: essentials/curve_fit.out

# 09/18/2013-09/19/2013, 09/23/2013
# Modifications: 01/14/2014-10/15/2014, 08/03/2015


use strict;
use warnings;
use diagnostics;

use Time::HiRes qw( gettimeofday );

$, = " ";	# set output field separator

my ($line, $line1, $line2, $line3, $line4, $line5) = "";
my (@list, @list1, @list2, @list3, @list4, @list5) = ();
my (@info, @info1, @info2, @info3, @info4, @info5) = ();

my ($line6, $line7, $line8, $line9, $line10) = "";
my (@list6, @list7, @list8, @list9, @list10) = ();
my (@info6, @info7, @info8, @info9, @info10) = ();

my $in1        = $ARGV[0];	# kped.pl output file (absolute path of kped.out)
my $in2        = $ARGV[1];	# kstat.pl output file (absolute path of kstat.out)
my $markers    = $ARGV[2];	# number of markers
my $ci         = $ARGV[3];	# % confidence interval (80, 90, 95, 99, 99.5)
my $essentials = $ARGV[4];	# essentials directory
my $outdir     = $ARGV[5];	# output directory (absolute path)

my $script = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;

if ($#ARGV < 0) {
	$script = $0;
	$script =~ s/^(.+)\///g;
	$script =~ s/^\.\///g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (Sept 2013)\n\n";
	print "This script compares pairwise kinship coefficients based on the pedigree\n";
	print "structure with the empirical kinship coefficients estimated using genotype\n";
	print "data by using the output files of kped.pl and kstat.pl.\n\n";

	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script kped.pl_output_file* kstat.pl_output_file* number_of_markers [80|90|95|99|99.5]** essentials_directory* output_directory*\n";
	print "       *use absolute path\n";
	print "       **percent confidence interval\n\n";
	exit;
}
if ($essentials =~ m/\/$/) { chop $essentials; }
if ($outdir =~ m/\/$/) { chop $outdir; }

my $out1 = $outdir."/relcheck_$ci\.out";
my $out2 = $outdir."/allpairwise_$ci\.txt";
my $out3  = $outdir."/relcheck_$ci\.pss";	# unrelated based on pedigree / related based on genotype
my $out4 = $outdir."/relcheck_$ci\.puip";	# related based on pedigree / unrelated based on genotype
my $out5 = $outdir."/relcheck_$ci\.cxr";	# complex relationship (in loops etc)
my $out6 = $outdir."/relcheck_$ci\.ndr";	# relationships that were not determined (in loops etc)

my $log  = $outdir."/relcheck_$ci\.log";

if (! -e $outdir) {
	`mkdir -p $outdir`;
}
if ( -e $out3) { `rm $out3`; }
if ( -e $out4) { `rm $out4`; }
if ( -e $out5) { `rm $out5`; }
if ( -e $out6) { `rm $out6`; }

open(OUT1, ">$out1") || die ("Could not create $out1 file!\n");
print OUT1 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,ExpMinKC$,ExpMaxKC$,Expk1$,Estk1$,ExpMink1$,ExpMaxk1$,Reason(s)_for_Flagging\n";

open(OUT2, ">$out2") || die ("Could not create $out2 file!\n");
print OUT2 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,Expk1$,Estk1$,Estk0$,Estk2\n";

open(LOG, ">$log") || die ("Could not create $log file!\n");
open (LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "################################################################################\n";
print LOG "#                                  relcheck.pl                                 #\n";
print LOG "#                            Alejandro Q. Nato, Jr.                            #\n";
print LOG "#                           Statistical Genetics Lab                           #\n";
print LOG "#                    University of Washington, Seattle, WA                     #\n";
print LOG "################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

print "INPUT FILE 1 (kped.out)  : $in1\n";
print "INPUT FILE 2 (kstat.out) : $in2\n";
print "OUTPUT FILE              : $out1\n\n";

print LOG "INPUT FILE 1 (kped.out)  : $in1\n";
print LOG "INPUT FILE 2 (kstat.out) : $in2\n";
print LOG "OUTPUT FILE              : $out1\n\n";

print LOG "LOG:\n";

##########
my ($id1a, $id2a, $id1b, $id2b, $rel, $prel) = "";
my ($kc1, $kc2, $ci1) = 0;
my ($k0, $k1, $k2) = 0;
my (%kc, %rel) = ();

if ($ci == 80) { $ci1 = 800; }
elsif ($ci == 90) { $ci1 = 900; }
elsif ($ci == 95) { $ci1 = 950; }
elsif ($ci == 99) { $ci1 = 990; }
elsif ($ci == 99.5) { $ci1 = 995; }

if ($markers =~ m/(\d+)\.\d+/) { 
	$markers = $1;
}

# Get number of individuals based on kstat.out
my $numindiv = 0;
my $numlines = `wc -l $in2`;
if ($numlines =~ m/(\d+)/) {
	$numlines = $1;
}
$numlines -= 1;	# don't count the header
$numindiv=((-1+sqrt(1+(4*($numlines*2))))/2)+1;
print "Number of individuals: $numindiv\n";
print "Number of markers: $markers\n\n";
print LOG "Number of individuals: $numindiv\n";
print LOG "Number of markers: $markers\n\n";

# Create the hash
open (IN1, "<$in1") || die ("Could not open $in1 file!\n");
@list1 = <IN1>;
close (IN1);
foreach $line1 (@list1) {
	chomp $line1;
	$line1 =~ s/^\s+//g;
	$line1 =~ s/\s+$//g;
	next if (length ($line1) == 0);
	next if ($line1 =~ m/Individual/);
	($id1a, $id2a, $kc1, $rel) = split (/\s/, $line1);
	$kc{$id1a}{$id2a} = $kc1;
	$kc{$id2a}{$id1a} = $kc1;
	$rel{$id1a}{$id2a} = $rel;
	$rel{$id2a}{$id1a} = $rel;
}
my $krel = "";
my $expkc = 0;
# Flag individuals outside the confidence intervals only for those with genotype data
open (IN2, "<$in2") || die ("Could not open $in2 file!\n");
@list2 = <IN2>;
close (IN2);
foreach $line2 (@list2) {
	chomp $line2;
	$line2 =~ s/^\s+//g;
	$line2 =~ s/\s+$//g;
	next if (length ($line2) == 0);
	next if ($line2 =~ m/Individual/);
	($id1b, $id2b, $k0, $k1, $k2, $kc2) = split (/\s+/, $line2);
	# Get known relationship based on the pedigree structure
	if ( (defined($rel{$id1b}{$id2b})) && (defined($kc{$id1b}{$id2b})) ) {
		# relationship as defined by pedigree structure
		$krel = $rel{$id1b}{$id2b};
		$expkc = $kc{$id1b}{$id2b};
	}
	my $fam1b = (split(/\_/, $id1b))[0];
	my $fam2b = (split(/\_/, $id2b))[0];
	if ($fam1b ne $fam2b) {
		# let us flag only those pairs with kinship coefficients above 0.3
		$krel = "U";
		$expkc = 0;
	}
	
	$k0 = sprintf("%.6f", $k0);
	$k1 = sprintf("%.6f", $k1);
	$k2 = sprintf("%.6f", $k2);
	$kc2 = sprintf("%.6f", $kc2);
	if ($expkc !~ m/ND/) {
		$expkc = sprintf("%.6f", $expkc);
	}
	my $expk1 = 0;
	if ($krel eq "PO") { $expk1 = 1.00; }
	elsif ( ($krel eq "FS") || ($krel eq "HS") || ($krel eq "AV") || ($krel eq "GG") ){ $expk1 = 0.50; }
	elsif ($krel eq "DFC") { $expk1 = 0.375; }
	elsif ( ($krel eq "FC") || ($krel eq "GAV") || ($krel eq "GGG") ) { $expk1 = 0.25; }
	elsif ($krel eq "FC1R") { $expk1 = 0.125; }
	elsif ($krel eq "U") { $expk1 = 0.00; }
	elsif ( ($krel eq "CX") || ($krel eq "ND") ) { 
		$expk1 = "ND";
		if ($fam1b eq $fam2b) {
			if ($krel eq "CX") {
				if ( ! -e $out5) {
					open(OUT5, ">$out5") || die ("Could not create $out5 file!\n");
					print OUT5 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,Expk1$,Estk1$,Estk0$,Estk2\n";
					print OUT5 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
				} elsif ( -e $out5) {
					print OUT5 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
				}
			} elsif ($krel eq "ND") {
				if ( ! -e $out6) {
					open(OUT6, ">$out6") || die ("Could not create $out6 file!\n");
					print OUT6 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,Expk1$,Estk1$,Estk0$,Estk2\n";
					print OUT6 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
				} elsif ( -e $out6) {
					print OUT6 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
				}
			}
		}
	}
	
	my $temp2 = "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2";
	print OUT2 "$temp2\n";
	# check k1 and kc based on $krel and $ci
	my $in3 = "$essentials\/curve_fit.$ci1";
	$ci = sprintf("%.3f", $ci/100);
	open (IN3, "<$in3") || die ("Could not open $in3 file!\n");
	@list3 = <IN3>;
	close (IN3);
	
	if ($krel ne "U") {
		if ( ($kc2 <= 0.015625) && ($expkc !~ m/ND/) && ($expkc > 0.015625) ) {
			if ( ! -e $out4) {
				open(OUT4, ">$out4") || die ("Could not create $out4 file!\n");
				print OUT4 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,Expk1$,Estk1$,Estk0$,Estk2\n";
				print OUT4 "$temp2\n";
			} elsif ( -e $out4) {
				print OUT4 "$temp2\n";
			}
		} elsif ( ($kc2 <= 0.015625) && ($expkc =~ m/ND/) ) {
			if ( ! -e $out4) {
				open(OUT4, ">$out4") || die ("Could not create $out4 file!\n");
				print OUT4 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,Expk1$,Estk1$,Estk0$,Estk2\n";
				print OUT4 "$temp2\n";
			} elsif ( -e $out4) {
				print OUT4 "$temp2\n";
			}
		}
	}
	
	my ($yk1min, $yk1max, $ykcmin, $ykcmax) = 0;
	my ($k1minA, $k1minB, $k1minC) = 0;
	my ($k1maxA, $k1maxB, $k1maxC) = 0;
	my ($kcminA, $kcminB, $kcminC) = 0;
	my ($kcmaxA, $kcmaxB, $kcmaxC) = 0;
	my $rel3 = "";
	foreach $line3 (@list3) {
		chomp $line3;
		$line3 =~ s/^\s+//g;
		$line3 =~ s/\s+$//g;
		next if (length ($line3) == 0);
		next if ($line3 =~ m/Relationship/);
		($rel3, $k1minA, $k1minB, $k1minC, $k1maxA, $k1maxB, $k1maxC, $kcminA, $kcminB, $kcminC, $kcmaxA, $kcmaxB, $kcmaxC) = split (/\s+/, $line3);
		if ($rel3 eq $krel) {
			# Check if kc is within ykcmin-ykcmax and yk1min-yk1max based on the number of markers
			my $markers2 = 0;
			if ($markers <= 9000) {
				$markers2 = $markers;
			} elsif ($markers > 9000) {
				$markers2 = 9000;
			}
			$yk1min = sprintf ("%.6f", ($k1minA*($markers2^2)) + ($k1minB*$markers2) + $k1minC);
			$yk1max = sprintf ("%.6f", ($k1maxA*($markers2^2)) + ($k1maxB*$markers2) + $k1maxC);
			$ykcmin = sprintf ("%.6f", ($kcminA*($markers2^2)) + ($kcminB*$markers2) + $kcminC);
			$ykcmax = sprintf ("%.6f", ($kcmaxA*($markers2^2)) + ($kcmaxB*$markers2) + $kcmaxC);
			if ($ykcmin < 0) { $ykcmin = sprintf ("%.6f", 0); }
			if ($ykcmax > 1) { $ykcmax = sprintf ("%.6f", 1); }
			if ($yk1min < 0) { $yk1min = sprintf ("%.6f", 0); }
			if ($yk1max > 1) { $yk1max = sprintf ("%.6f", 1); }
			if ( ($kc2>=$ykcmin) && ($kc2<=$ykcmax) && ($k1>=$yk1min) && ($k1<=$yk1max) ) {
				# values are okay so we don't need to flag this relationship
			} elsif ( ($krel eq "U") && ($kc2 >= 0.0625) ) {
				# potential sample swap within pedigree
				if ( ! -e $out3) {
					open(OUT3, ">$out3") || die ("Could not create $out3 file!\n");
					print OUT3 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,Expk1$,Estk1$,Estk0$,Estk2\n";
					print OUT3 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
				} elsif ( -e $out3) {
					print OUT3 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
				}
			} elsif ( ($krel eq "PO") && ($k1 > 0.94) && ($kc2>=0.2375) && ($kc2<=0.2625) ) {
				# do not flag
				next;
			} else {
				if ( (($kc2<$ykcmin) || ($kc2>$ykcmax)) && ($k1>=$yk1min) && ($k1<=$yk1max) ) {
					print OUT1 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$ykcmin$,$ykcmax$,$expk1$,$k1$,$yk1min$,$yk1max$,EstKC\n";
					if ( ($krel eq "U") && ($kc2 >= 0.0625) ) {
						if ( ! -e $out3) {
							open(OUT3, ">$out3") || die ("Could not create $out3 file!\n");
							print OUT3 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,Expk1$,Estk1$,Estk0$,Estk2\n";
							print OUT3 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
						} elsif ( -e $out3) {
							print OUT3 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
						}
					}
				} elsif ( ($kc2>=$ykcmin) && ($kc2<=$ykcmax) && (($k1<$yk1min) || ($k1>$yk1max)) ) {
					print OUT1 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$ykcmin$,$ykcmax$,$expk1$,$k1$,$yk1min$,$yk1max$,Estk1\n";
				} elsif ( (($kc2<$ykcmin) || ($kc2>$ykcmax)) && (($k1<$yk1min) || ($k1>$yk1max)) ) {
					print OUT1 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$ykcmin$,$ykcmax$,$expk1$,$k1$,$yk1min$,$yk1max$,Estk1_and_EstKC\n";
					if ( ($krel eq "U") && ($kc2 >= 0.0625) ) {
						if ( ! -e $out3) {
							open(OUT3, ">$out3") || die ("Could not create $out3 file!\n");
							print OUT3 "Individual1$,Individual2$,Known_Relationship$,ExpKC$,EstKC$,Expk1$,Estk1$,Estk0$,Estk2\n";
							print OUT3 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
						} elsif ( -e $out3) {
							print OUT3 "$id1b$,$id2b$,$krel$,$expkc$,$kc2$,$expk1$,$k1$,$k0$,$k2\n";
						}
					}
				}
			}
		}
	}
}
close (OUT1);
close (OUT2);
if ( -e $out3) {
	close (OUT3);
}
if ( -e $out4) {
	close (OUT4);
}
if ( -e $out5) {
	close (OUT5);
}
##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);

print "\nTotal real time   : " . parsetime ($real);
print   "Total user time   : " . parsetime ($user);
print   "Total system time : " . parsetime ($system);
print LOG "\nTotal real time   : " . parsetime ($real);
print LOG   "Total user time   : " . parsetime ($user);
print LOG   "Total system time : " . parsetime ($system);
print "\nDone\n\n";
close (LOG);

##### SUBROUTINES #####

sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}

