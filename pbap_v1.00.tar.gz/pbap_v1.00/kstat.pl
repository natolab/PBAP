#!/usr/bin/perl
# ./kstat.pl
# By Alejandro Q. Nato, Jr., Ph.D.
# This script estimates empirical pairwise kinship coefficients based on that
# genotype data by using kstat (C-program) written by Dr. Yoonha Choi.

# 08/13/2013-08/28/2013
# Modifications: 09/17/2013-09/24/2014, 07/28/2015


use strict;
use warnings;
use diagnostics;

use Time::HiRes qw( gettimeofday );

$, = " ";	# set output field separator

my ($line, $line1, $line2, $line3, $line4, $line5) = "";
my (@list, @list1, @list2, @list3, @list4, @list5) = ();
my (@info, @info1, @info2, @info3, @info4, @info5) = ();

my ($line6, $line7, $line8, $line9, $line10) = "";
my (@list6, @list7, @list8, @list9, @list10) = ();
my (@info6, @info7, @info8, @info9, @info10) = ();

my $parfile = $ARGV[0];	# parameter file (absolute path)
my ($script, $script1) = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;

if ($#ARGV < 0) {
	$script  = $0;
	$script  =~ s/^(.+)\///g;
	$script  =~ s/^\.\///g;
	$script1 = $script;
	$script1 =~ s/\.pl//g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (Aug 2013; updated September 2013-September 2014, July 2015)\n\n";
	print "This script estimates empirical pairwise kinship coefficients\n";
	print "based on genotype data .\n\n";

	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script $script1\_parameter_file*\n";
	print "       *use absolute path\n\n";

	print "Parameter file should contain the following:\n\n";
	print "\tLine  1 - Chromosome(s)\n";
	print "\t             It would be best to use genotypes of the entire genome when running kstat.pl\n";
	print "\t             e.g., if there is genotype data for chromosomes 1-22, put \"1-22\"\n";
	print "\t             or if you only have genotype data only for chromosome 3, put \"3\"\n";
	print "\tLine  2 - Directory for output files\n";
	print "\t             Directory will be created if it does not exist\n";
	print "\tLine  3 - Additional codes for missing data\n";
	print "\t             PBAP codes for missing data: -0-, MISSING, MIS, miss, NA, -9, -1, 0, and -\n";
	print "\t             \"0\" will not be considered as missing in map files\n";
	print "\t             If you don't have additional codes aside from the ones mentioned above, put \"no_extra_code\"\n";
	print "\t             Otherwise, put codes for missing data in your pedigree, phenotype, and map files here\n";
	print "\t             Format (space-delimited): e.g., \"-0- MISSING MIS miss NA -9 -1 0 -\"\n";
	print "\tLine  4 - Directory containing kstat and kinship.pl (e.g., /home/username/pbap/essentials) and operating system bit count\n";


	print "\tLine  5 - Directory containing pedigree files\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine  6 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where pedigree files are located\n";
	print "\tLine  7 - [(prefix=)(suffix)] of chromosome number in input pedigree filenames\n";
	print "\t             e.g., if if your files are named chr*-ped.txt, put \"prefix=chr suffix=-ped.txt\"\n";
	print "\tLine  8 - Input pedigree file has a header or not: header=[T|F]\n";
	
	print "\tLine  9 - Directory containing genotype data\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 10 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where genotype files are located\n";
	print "\tLine 11 - [(prefix=)(suffix)] of chromosome number in input genotype filenames\n";
	print "\t             e.g., if if your files are named chr*-geno.txt, put \"prefix=chr suffix=-geno.txt\"\n";
	print "\tLine 12 - Input genotype file has a header or not: header=[T|F]\n";
	print "\tLine 13 - Option: [1|2] for input file(s) containing IDs of genotyped individuals\n";
	print "\t             1: Use output files of either transpose_fileset.pl or marker_subpanels.pl\n";
	print "\t             2: Use a file containing the list of genotyped individuals (supplied by user)\n";
	print "\t             If you chose option 2, line 14 should contain the absolute path of input file\n";
	print "\t             and leave lines 15-16 blank.\n";
	print "\tLine 14 - If option 1 was chosen in line 13,\n";
	print "\t             indicate directory containing files with IDs of genotyped individuals\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\t          If option 2 was chosen in line 13,\n";
	print "\t             indicate input file containing list of IDs of genotyped individuals (absolute path)\n";
	print "\tLine 15 - If option 1 was chosen in line 13,\n";
	print "\t             [(prefix=)(suffix)] of chromosome number in names of subdirectories where files containing\n";
	print "\t             IDs of genotyped individuals are located\n";
	print "\t          If option 2 was chosen in line 13,\n";
	print "\t             Input file containing IDs of genotyped individuals has a header or not: header=[T|F]\n";
	print "\tLine 16 - [(prefix=)(suffix)] of chromosome number in files containing IDs of genotyped individuals\n";
	print "\t             e.g., if if your files are named chr*-ind.txt, put \"prefix=chr suffix=-ind.txt\"\n";
	print "\tLine 17 - Input file containing IDs of genotyped individuals has a header or not: header=[T|F]\n";
	
	print "\tNotes: 1) Blank lines and lines that start with a pound sign (#) will be ignored\n";
	print "\t       2) Use absolute paths for all directories\n";
	print "\t       3) To avoid mismatching, all individual IDs should be concatenated with family IDs,\n";
	print "\t             e.g., \"FamilyID.IndividualID\" or \"FamilyID_IndividualID\"\n";
	print "\t       4) For subdirectories in lines 6, 10, and  15 if files in lines 7, 11, and 16 are directly\n";
	print "\t             under the directories in lines 5, 9, and 14, respectively, put \"no dir\"\n";
	print "\t             Examples (if subdirectories are present):\n";
	print "\t             If subdirectories are named chr*, put \"prefix=chr suffix=none\"\n";
	print "\t             If subdirectories are named chr*geno, put \"prefix=chr suffix=geno\"\n";
	print "\t             If subdirectories just contain the chromosome number without any prefix or suffix, you can put \"none\"\n\n";
	exit;
}

my $count = 0;
my ($option, $genoname, $genopre, $genosuf, $genoin, $idname, $idpre, $idsuf, $idin) = "";
my ($mtype, $transposed, $delnorm, $delplinkt, $includeg, $includep, $prevail) = "";
my ($mafname, $mafpre, $mafsuf, $mafin) = "";
my ($pedname, $pedpre, $pedsuf, $pedin) = "";
my ($maingdir, $genodir, $genodirpre, $genodirsuf, $genodirin) = "";
my ($mainidir, $iddir, $iddirpre, $iddirsuf, $iddirin, $outdir) = "";
my ($mainpdir, $peddir, $peddirpre, $peddirsuf, $pedddirin) = "";
my ($mainfdir, $mafdir, $mafdirpre, $mafdirsuf, $mafdirin) = "";
my ($genofdir, $genofile, $genoh, $idfdir, $idfile, $idh, $missing) = "";
my ($maffdir, $maffile, $mafh, $pedfdir, $pedfile, $pedh) = "";
my ($kstat, $mafopt) = "";
my ($chr, $chrs, $chre, $i, $nummarker) = 0;
my ($famid, $subid) = "";
my (@idin, @missing, @fam4) = ();
my (%freq, %nummrkr, %imgeno, %A1, %A2, %maf2) = ();
my ($count1, $count2) = 0;

open (IN1, "<$parfile") || die ("Could not open $parfile!\n");
@list1 = <IN1>;
close (IN1);
print "\nThese are the parameters that you specified:\n";
foreach $line1 (@list1) {
	chomp $line1;
	next if ( ($line1 =~ m/\t|\#/) && ( ($line1 =~ m/line|:|\"|\=/i) || ($line1 !~ m/\d/)) );
	next if (length($line1) == 0);
	$line1 =~ s/^\s+//g;
	$line1 =~ s/\s+$//g;
	$count++;
	print "line $count: $line1\n";
	if ($count == 1) { $chr      = $line1; }
	elsif ($count == 2) { $outdir   = $line1; }
	elsif ($count == 3) { $missing  = $line1; }
	
	elsif ($count == 4) { $kstat  = $line1; }

	elsif ($count == 5) { $mainpdir = $line1; }
	elsif ($count == 6) { $peddir  = $line1; }
	elsif ($count == 7) { $pedname = $line1; }
	elsif ($count == 8) { $pedh    = $line1; }
	
	elsif ($count == 9) { $maingdir = $line1; }
	elsif ($count == 10) { $genodir  = $line1; }
	elsif ($count == 11) { $genoname = $line1; }
	elsif ($count == 12) { $genoh    = $line1; }
	elsif ($count == 13) { $option   = $line1; }
	elsif ( (defined($option)) && ($option == 1) ) {
		if ($count == 14) { $mainidir = $line1; }
		elsif ($count == 15)  { $iddir    = $line1; }
		elsif ($count == 16) { $idname   = $line1; }
		elsif ($count == 17) { $idh      = $line1; }
	} elsif ( (defined($option)) && ($option == 2) ) {
		if    ($count == 14)  { $idin     = $line1; }
		elsif ($count == 15) { $idh      = $line1; }
	}
}
print "\n";
if ($mainfdir =~ m/\/$/) { chop $mainfdir; }
if ($mainpdir =~ m/\/$/) { chop $mainpdir; }
if ($maingdir =~ m/\/$/) { chop $maingdir; }
if ( (defined($mainidir)) && ($mainidir =~ m/\/$/) ) { chop $mainidir; }
if ($outdir =~ m/\/$/)   { chop $outdir; }

my $out1 = $outdir."/kstat.out";	# kinship
my $err  = $outdir."/kstat.err";
my $log  = $outdir."/kstat.log";

if (! -e $outdir) {
	print "outdir\=$outdir will be created\n";
	`mkdir -p $outdir`;
}
if ( -e $err ) {
	`rm $err`;
}

# Create log file
open(LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "################################################################################\n";
print LOG "#                                 PBAP kstat.pl                                #\n";
print LOG "#                            Alejandro Q. Nato, Jr.                            #\n";
print LOG "#                           Statistical Genetics Lab                           #\n";
print LOG "#                    University of Washington, Seattle, WA                     #\n";
print LOG "################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

# Skip $missing[0] for map files
@missing = qw/0 NA - -0- MISSING MIS miss -9 -1/;
my %missing = ();
foreach my $m (@missing) {
	$missing{$m}++;
}
if ($missing =~ m/^no_extra_code$/i) {
	# do nothing
} elsif ($missing !~ m/^no_extra_code$/i) {
	my @addmiss = split (" ", $missing);
	foreach my $n (@addmiss) {
		if (!defined($missing{$n})) {
			push (@missing, $n);
			$missing{$n}++;
		}
	}
}
print LOG "PARAMETERS SPECIFIED:\n";
print LOG "Chromosome(s) with genotype data : ";

my @chrA = ();
if ($chr =~ m/\-|\s+/) {
	($chrs, $chre) = split (/\-|\s+/, $chr);
	print LOG "$chrs\-$chre\n";
	print "Start chromosome : $chrs\n";
	print "End chromosome   : $chre\n";
	my $i = 0;
	for ($i = $chrs; $i <= $chre; $i++) {
		push (@chrA, $i);
	}
} else {
	$chrs = $chre = $chr;
	push (@chrA, $chr);
	print LOG "$chrs\n";
}

$mafopt = "dataset";
$mafopt =~ s/^\s+//g;
$mafopt =~ s/\s$//g;
print "Source of MAF information : $mafopt\n";
print LOG "Source of MAF information        : $mafopt\n";

# MAF file
if ($mafopt =~ m/dataset/i) {
	# no maffile needed
} elsif ($mafopt =~ m/MAF/i) {
	if ($mafdir eq "no dir") {
		# MAF files are directly under mainfdir
		$maffdir = $mainfdir;
	} elsif ($mafdir ne "no dir") {
		if ($mafdir eq "none") {
			$mafdirpre = "";
			$mafdirsuf = "";
		} elsif ($mafdir =~ m/prefix\=(.+) suffix\=(.+)/) {
			$mafdirpre = $1;
			$mafdirsuf = $2;
			if ($mafdirpre eq "none") { $mafdirpre = ""; }
			if ($mafdirsuf eq "none") { $mafdirsuf = ""; }
		} elsif ( ($mafdir =~ m/prefix\=(.+)/) && ($mafdir !~ m/suffix\=(.+)/) ) {
			$mafdirpre = $1;
			$mafdirsuf = "";
			if ($mafdirpre eq "none") { $mafdirpre = ""; }
		} elsif ( ($mafdir !~ m/prefix\=(.+)/) && ($mafdir =~ m/suffix\=(.+)/) ) {
			$mafdirpre = "";
			$mafdirsuf = $1;
			if ($mafdirsuf eq "none") { $mafdirsuf = ""; }
		}
	   	$maffdir = $mainfdir . "/" . $mafdirpre . "*" . $mafdirsuf;
	}
	if ($mafname =~ m/prefix\=(.+) suffix\=(.+)/) {
		$mafpre = $1;
		$mafsuf = $2;
		if ($mafpre eq "none") { $mafpre = ""; }
		if ($mafsuf eq "none") { $mafsuf = ""; }
	} elsif ( ($mafname =~ m/prefix\=(.+)/) && ($mafname !~ m/suffix\=(.+)/) ) {
		$mafpre = $1;
		$mafsuf = "";
		if ($mafpre eq "none") { $mafpre = ""; }
	} elsif ( ($mafname !~ m/prefix\=(.+)/) && ($mafname =~ m/suffix\=(.+)/) ) {
		$mafpre = "";
		$mafsuf = $1;
		if ($mafsuf eq "none") { $mafsuf = ""; }
	}
	$maffile = $maffdir . "/" . $mafpre . "*" . $mafsuf;
	print "MAF file : $maffile\n";
	print LOG "MAF file                         : $maffile\n";
}


# Pedigree file
if ($peddir eq "no dir") {
	# pedigree files are directly under mainfdir
	$pedfdir = $mainpdir;
} elsif ($peddir ne "no dir") {
	if ($peddir eq "none") {
		$peddirpre = "";
		$peddirsuf = "";
	} elsif ($peddir =~ m/prefix\=(.+) suffix\=(.+)/) {
		$peddirpre = $1;
		$peddirsuf = $2;
		if ($peddirpre eq "none") { $peddirpre = ""; }
		if ($peddirsuf eq "none") { $peddirsuf = ""; }
	} elsif ( ($peddir =~ m/prefix\=(.+)/) && ($peddir !~ m/suffix\=(.+)/) ) {
		$peddirpre = $1;
		$peddirsuf = "";
		if ($peddirpre eq "none") { $peddirpre = ""; }
	} elsif ( ($peddir !~ m/prefix\=(.+)/) && ($peddir =~ m/suffix\=(.+)/) ) {
		$peddirpre = "";
		$peddirsuf = $1;
		if ($peddirsuf eq "none") { $peddirsuf = ""; }
	}
	$pedfdir = $mainpdir . "/" . $peddirpre . "*" . $peddirsuf;
}
if ($pedname =~ m/prefix\=(.+) suffix\=(.+)/) {
	$pedpre = $1;
	$pedsuf = $2;
	if ($pedpre eq "none") { $pedpre = ""; }
	if ($pedsuf eq "none") { $pedsuf = ""; }
} elsif ( ($pedname =~ m/prefix\=(.+)/) && ($pedname !~ m/suffix\=(.+)/) ) {
	$pedpre = $1;
	$pedsuf = "";
	if ($pedpre eq "none") { $pedpre = ""; }
} elsif ( ($pedname !~ m/prefix\=(.+)/) && ($pedname =~ m/suffix\=(.+)/) ) {
	$pedpre = "";
	$pedsuf = $1;
	if ($pedsuf eq "none") { $pedsuf = ""; }
}
$pedfile = $pedfdir . "/" . $pedpre . "*" . $pedsuf;
print "Pedigree file : $pedfile\n";
print LOG "Pedigree file                    : $pedfile\n";


($count1, $count2) = 0;

if ($genodir eq "no dir") {
	# genotype files are directly under maingdir
	$genofdir = $maingdir;
} elsif ($genodir ne "no dir") {
	if ($genodir eq "none") {
		$genodirpre = "";
		$genodirsuf = "";
	} elsif ($genodir =~ m/prefix\=(.+) suffix\=(.+)/) {
		$genodirpre = $1;
		$genodirsuf = $2;
		if ($genodirpre eq "none") { $genodirpre = ""; }
		if ($genodirsuf eq "none") { $genodirsuf = ""; }
	} elsif ( ($genodir =~ m/prefix\=(.+)/) && ($genodir !~ m/suffix\=(.+)/) ) {
		$genodirpre = $1;
		$genodirsuf = "";
		if ($genodirpre eq "none") { $genodirpre = ""; }
	} elsif ( ($genodir !~ m/prefix\=(.+)/) && ($genodir =~ m/suffix\=(.+)/) ) {
		$genodirpre = "";
		$genodirsuf = $1;
		if ($genodirsuf eq "none") { $genodirsuf = ""; }
	}
	$genofdir = $maingdir . "/" . $genodirpre . $chr . $genodirsuf;
}
if ($genoname =~ m/prefix\=(.+) suffix\=(.+)/) {
	$genopre = $1;
	$genosuf = $2;
	if ($genopre eq "none") { $genopre = ""; }
	if ($genosuf eq "none") { $genosuf = ""; }
} elsif ( ($genoname =~ m/prefix\=(.+)/) && ($genoname !~ m/suffix\=(.+)/) ) {
	$genopre = $1;
	$genosuf = "";
	if ($genopre eq "none") { $genopre = ""; }
} elsif ( ($genoname !~ m/prefix\=(.+)/) && ($genoname =~ m/suffix\=(.+)/) ) {
	$genopre = "";
	$genosuf = $1;
	if ($genosuf eq "none") { $genosuf = ""; }
}
$genofile = $genofdir . "/" . $genopre . "*" . $genosuf;
print "Genotype file(s) : $genofile\n";
print LOG "Genotype file(s)                 : $genofile\n";

if ($option == 1) {
	# Compare all individual ID files per chromosome and use the IDs that are
	# present across all chromosomes
	if ($iddir eq "no dir") {
		# ID files are directly under mainidir
		$idfdir = $mainidir;
	} elsif ($iddir ne "no dir") {
		if ($iddir eq "none") {
			$iddirpre = "";
			$iddirsuf = "";
		} elsif ($iddir =~ m/prefix\=(.+) suffix\=(.+)/) {
			$iddirpre = $1;
			$iddirsuf = $2;
			if ($iddirpre eq "none") { $iddirpre = ""; }
			if ($iddirsuf eq "none") { $iddirsuf = ""; }
		} elsif ( ($iddir =~ m/prefix\=(.+)/) && ($iddir !~ m/suffix\=(.+)/) ) {
			$iddirpre = $1;
			$iddirsuf = "";
			if ($iddirpre eq "none") { $iddirpre = ""; }
		} elsif ( ($iddir !~ m/prefix\=(.+)/) && ($iddir =~ m/suffix\=(.+)/) ) {
			$iddirpre = "";
			$iddirsuf = $1;
			if ($iddirsuf eq "none") { $iddirsuf = ""; }
		}
		$idfdir = $mainidir . "/" . $iddirpre . $chr . $iddirsuf;
	}
	if ($idname =~ m/prefix\=(.+) suffix\=(.+)/) {
		$idpre = $1;
		$idsuf = $2;
		if ($idpre eq "none") { $idpre = ""; }
		if ($idsuf eq "none") { $idsuf = ""; }
	} elsif ( ($idname =~ m/prefix\=(.+)/) && ($idname !~ m/suffix\=(.+)/) ) {
		$idpre = $1;
		$idsuf = "";
		if ($idpre eq "none") { $idpre = ""; }
	} elsif ( ($idname !~ m/prefix\=(.+)/) && ($idname =~ m/suffix\=(.+)/) ) {
		$idpre = "";
		$idsuf = $1;
		if ($idsuf eq "none") { $idsuf = ""; }
	}
	$idfile = $idfdir . "/" . $idpre . "*" . $idsuf;
	print "IDs of genotyped individuals : $idfile\n\n";
	print LOG "IDs of genotyped individuals     : $idfile\n\n";

	
	# check individual ID files now
	(@list2, @idin) = ();
	%freq = ();
	my $numchr = scalar(@chrA);
	print "Empirical kinship coefficient estimation\n";
	if ( ($numchr > 1) && ($chr =~ m/\-|\s/) ) {
		print "   will only include individuals who have genotype data in chromosomes $chrs through $chre\n";
	} elsif ($numchr == 1) {
		print "   will only include individuals who have genotype data in chromosome $chr\n";
		print "   Please be reminded that kstat.pl results may not be accurate when you use only one chromosome\n";
	}
	foreach $i (@chrA) {
		my $idftemp = "";
		if ($iddir eq "no dir") {
			$idftemp = $idfdir . "/" . $idpre . $i . $idsuf;
		} else {
			$idftemp = $mainidir . "/" . $iddirpre . $i . $iddirsuf . "/" . $idpre . $i . $idsuf;
		}
		open (IN2, "<$idftemp") || die ("Could not open $idftemp file!\n");
		@list2 = <IN2>;
		close (IN2);
		$count2 = 0;
		foreach $line2 (@list2) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if (length($line2) == 0);
			$count2++;
			next if ( ($idh =~ m/T/) && ($count2 == 1) );
			$freq{$line2}++;
		}
		close (IN2);
	}
	# use the last list2 to check the individual IDs that are present in all ID files
	$count2 = 0;
	foreach $line2 (@list2) {
		chomp $line2;
		$line2 =~ s/^\s+//g;
		$line2 =~ s/\s+$//g;
		next if (length($line2) == 0);
		$count2++;
		next if ( ($idh =~ m/T/) && ($count2 == 1) );
		if ($freq{$line2} == $numchr) {
			push (@idin, $line2);
		}
	}
	close (IN2);
	
} elsif ($option == 2) {
	# use the file supplied by the user as the $idin
	print "IDs of genotyped individuals : $idin\n\n";
	print LOG "IDs of genotyped individuals     : $idin\n\n";
	(@list2, @idin) = ();
	open (IN2, "<$idin") || die ("Could not open $idin file!\n");
	$count2 = 0;
	while (defined ($line2 = <IN2>)) {
		chomp $line2;
		$line2 =~ s/^\s+//g;
		$line2 =~ s/\s+$//g;
		next if (length($line2) == 0);
		$count2++;
		next if ( ($idh =~ m/T/) && ($count2 == 1) );
		push (@idin, $line2);
	}
	close (IN2);
}

print LOG "Output directory                 : $outdir\n\n";

# Use row-marker (transposed) genotype file and ID file to create hashes
$nummarker = 0;
(@list3, @list4, @fam4) = ();
(%nummrkr, %imgeno, %A1, %A2, %maf2) = ();
my ($marker3, $chrmrkr3, $chr_marker3, $geno3, $famid4, $subid4, $famid_subid4, $famid_subid6, $chr_marker7) = "";
my ($chr3, $count3) = 0;
my (@marker3, @geno3) = ();
my (%exclude, %swap) = ();
my $allmaf = "";
if ($mafopt =~ m/MAF/i) {
	$allmaf = $outdir . "/allchr.maf";
	open (ALLMAF, ">$allmaf") || die ("Could not create $allmaf!");
}
foreach $i (@chrA) {
	my ($mafftemp, $pedftemp, $genoftemp, $idftemp) = "";
	if ($peddir eq "no dir") {
		$pedftemp = $pedfdir . "/" . $pedpre . $i . $pedsuf;
	} else {
		$pedftemp = $mainpdir . "/" . $peddirpre . $i . $peddirsuf . "/" . $pedpre . $i . $pedsuf;
	}
	if ($mafopt =~ m/MAF/i) {
		if ($mafdir eq "no dir") {
			$mafftemp = $maffdir . "/" . $mafpre . $i . $mafsuf;
		} else {
			$mafftemp = $mainfdir . "/" . $mafdirpre . $i . $mafdirsuf . "/" . $mafpre . $i . $mafsuf;
		}
		
		# Create a hash of the alleles to make sure that the genotypes are recoded correctly for kstat
		open (MAF, "<$mafftemp") || die ("Could not open $mafftemp!");
		while (defined (my $mafline=<MAF>)) {
			chomp $mafline;
			$mafline =~ s/^\s+//g;
			$mafline =~ s/\s+$//g;
			my ($mafmarker, $mafA1, $mafA2, $maf2) = split (/\s+/, $mafline);
			$mafmarker =~ s/^\s+//g;
			$mafmarker =~ s/\s+$//g;
			$mafA1 =~ s/^\s+//g;
			$mafA1 =~ s/\s+$//g;
			$mafA2 =~ s/^\s+//g;
			$mafA2 =~ s/\s+$//g;
			$maf2 =~ s/^\s+//g;
			$maf2 =~ s/\s+$//g;
			$A1{$mafmarker} = $mafA1;
			$A2{$mafmarker} = $mafA2;
			$maf2{$mafmarker} = $maf2;
			print ALLMAF "$maf2\n";
		}
		close (MAF);
	}
	# Parse the Family IDs from the Pedigree file
	open (PED, "<$pedftemp") || die ("Could not open $pedftemp!");
	my @fam = ();
	my %seen = ();
	while (defined (my $pedline=<PED>)) {
		chomp $pedline;
		$pedline =~ s/^\s+//g;
		$pedline =~ s/\s+$//g;
		my ($fam, $rest) = split (/\s+/, $pedline, 2);
		if (!exists($seen{$fam})) {
			$seen{$fam}++;
			push (@fam, $fam);
		} elsif (exists($seen{$fam})) {
			next;
		}
	}
	close (PED);

	@fam = sort (@fam);
	@fam4 = @fam;
	
	if ($genodir eq "no dir") {
		$genoftemp = $genofdir . "/" . $genopre . $i . $genosuf;
	} else {
		$genoftemp = $maingdir . "/" . $genodirpre . $i . $genodirsuf . "/" . $genopre . $i . $genosuf;
	}
	if ($option == 1) {
		if ( (defined($iddir)) && ($iddir eq "no dir") ) {
			$idftemp   = $idfdir . "/" . $idpre . $i . $idsuf;
		} else {
			$idftemp   = $mainidir . "/" . $iddirpre . $i . $iddirsuf . "/" . $idpre . $i . $idsuf;
		}
	}
	open (IN3, "<$genoftemp") || die ("Could not open $genoftemp file!\n");
	$count1 = 0;
	while (defined ($line3 = <IN3>)) {
		chomp $line3;
		$count3 = 0;
		$line3 =~ s/^\s+//g;
		$line3 =~ s/\s+$//g;
		next if (length($line3) == 0);
		$count1++;
		next if ( ($genoh =~ m/T/) && ($count1 == 1) );
		($chr3, $marker3, $geno3) = split(/\t|\s+/, $line3, 3);
		$chrmrkr3 = "$chr3$,$marker3";
		push (@marker3, $chrmrkr3);
		@geno3 = split (/\t|\s+/, $geno3);
		
		my %seen = ();
		foreach my $item (@geno3) {
			next if (defined($missing{$item}));
			$seen{$item}++;
		}
		my @uniq = keys %seen;
		@uniq = sort (@uniq);
		
		if (scalar(@uniq) >= 3) {
			print "Marker $marker3 on chromosome $chr3 has more than two unique alleles: ";
			print LOG "Marker $marker3 on chromosome $chr3 has more than two unique alleles: ";
			$exclude{$chr3}{$marker3}++;
			print join (" ", @uniq);
			print "\n";
		}
		my ($nt1, $nt2, $type) = "";
		my ($j, $k, $countu) = 0;
		$countu = scalar(@uniq);
		if ( (grep(/0|1|2/, @uniq)) && (!grep(/A|C|G|T/i, @uniq)) ){ 
			$type = "numeric";
			$k = 0;
			for ($j = 0; $j < $countu; $j++) {
				next if (defined($missing{$uniq[$j]}));
				if ($k == 0) { $nt1 = $uniq[$j]; }
				elsif ($k == 1) { $nt2 = $uniq[$j]; }
				$k++;
			}
		} elsif ( (grep(/\-|A|C|G|T|0/i, @uniq)) && (!grep(/1|2/, @uniq)) ) { 
			$type = "alpha";
			$k = 0;
			for ($j = 0; $j < $countu; $j++) {
				next if (defined($missing{$uniq[$j]}));
				if ($k == 0) { $nt1 = $uniq[$j]; }
				elsif ($k == 1) { $nt2 = $uniq[$j]; }
				$k++;
			}
		}
		$nt1 =~ s/^\s+//g;
		$nt1 =~ s/\s+$//g;
		$nt2 =~ s/^\s+//g;
		$nt2 =~ s/\s+$//g;
		chomp $nt1;
		chomp $nt2;
		
		my ($a1, $a2) = 0;
		my ($geno3a, $geno3b, $imgeno) = "";
		
		if ($option == 1) {
			open (IN4, "<$idftemp") || die ("Could not open $idftemp file!\n");
		} elsif ($option == 2) {
			open (IN4, "<$idin") || die ("Could not open $idin file!\n");
		}
		while (defined ($line4 = <IN4>)) {
			chomp $line4; 
			$line4 =~ s/^\s+//g;
			$line4 =~ s/\s+$//g;
			next if (length($line4) == 0);
			$imgeno = "";
			foreach my $fam4 (@fam) {
				if ($line4 =~ m/^($fam4)[\.|\-|\_](.+)/) {
					$famid4 = $1;
					$subid4 = $2;
					last;
				}
			}
			$a1 = ($count3*2);
			$a2 = ($count3*2) + 1;
			$geno3a = $geno3[$a1];
			$geno3b = $geno3[$a2];
			$geno3a =~ s/^\s+//g;
			$geno3a =~ s/\s+$//g;
			$geno3b =~ s/^\s+//g;
			$geno3b =~ s/\s+$//g;
			my $genotemp = $geno3a." ".$geno3b;
			### recode for kstat
			my $j = 0;
			for ($j = 0; $j <= $#missing; $j++) {
				if ($genotemp =~ m/^$missing[$j] $missing[$j]$/) {
					$genotemp = "0 0";
					$imgeno = -1;
					last;
				}
			}
			if ( ($genotemp ne "0 0") && ($genotemp ne "- -") ) {
				if ($mafopt =~ m/dataset/i) {
					if ( (defined($nt1)) && ($genotemp =~ m/^$nt1 $nt1$/) ) {
						$imgeno = 0;
					} elsif ( (defined($nt1)) && (defined($nt2)) && ( ($genotemp =~ m/^$nt1 $nt2$/) || ($genotemp =~ m/^$nt2 $nt1$/) ) ) {
						$imgeno = 1; 
					} elsif ( (defined($nt2)) && ($genotemp =~ m/^$nt2 $nt2$/) ) {
						$imgeno = 2;
					}
				} elsif ($mafopt =~ m/MAF/i) {
					# we need to recode depending on the alleles
					if ($A1{$marker3} eq $nt1) {
						# we don't need to change anything
						if ( (defined($nt1)) && ($genotemp =~ m/^$nt1 $nt1$/) ) {
							$imgeno = 0;
						} elsif ( (defined($nt1)) && (defined($nt2)) && ( ($genotemp =~ m/^$nt1 $nt2$/) || ($genotemp =~ m/^$nt2 $nt1$/) ) ) {
							$imgeno = 1; 
						} elsif ( (defined($nt2)) && ($genotemp =~ m/^$nt2 $nt2$/) ) {
							$imgeno = 2;
						}
					} elsif ($A2{$marker3} eq $nt1) {
						if (!defined($swap{$marker3})) {
							print "swap alleles: chr\=$chr3 marker\=$marker3 a1\=$A1{$marker3} a2\=$A2{$marker3} af2\=$maf2{$marker3} nt1\=$nt1 nt2\=$nt2\n";
							print LOG "swap alleles: chr\=$chr3 marker\=$marker3 a1\=$A1{$marker3} a2\=$A2{$marker3} af2\=$maf2{$marker3} nt1\=$nt1 nt2\=$nt2\n";
							$swap{$marker3}++;
						}
						# we have to flip the recoding
						if ( (defined($nt1)) && ($genotemp =~ m/^$nt1 $nt1$/) ) {
							$imgeno = 2;
						} elsif ( (defined($nt1)) && (defined($nt2)) && ( ($genotemp =~ m/^$nt1 $nt2$/) || ($genotemp =~ m/^$nt2 $nt1$/) ) ) {
							$imgeno = 1; 
						} elsif ( (defined($nt2)) && ($genotemp =~ m/^$nt2 $nt2$/) ) {
							$imgeno = 0;
						}
					}
				}
			}
			### done recoding
			$chr_marker3 = $chr3 . "_" . $marker3;
			$famid_subid4 = $famid4 . "_" . $subid4;
			$imgeno{$chr3}{$marker3}{$famid4}{$subid4} = $imgeno;
			$imgeno{$chr_marker3}{$famid_subid4} = $imgeno;
			$count3++;
		}
		($a1, $a2, $count3) = 0;
		$nummarker++;
		close (IN4);
	}
	# Number of markers for this chromosome
	$nummrkr{$i} = $nummarker;
	close (IN3);
}

if ($mafopt =~ m/MAF/i) {
	close (ALLMAF);
}


# Use @idin and map file to create the row-subject genotype files needed for kstat
# We don't want to sort the IDs of genotyped individuals because they match the
# order of genotypes in the transposed genotype files.
my $outdir2 = $outdir . "/geno";
my $outdir3 = $outdir . "/kstat";
if (! -e $outdir2) {
	print "outdir2\=$outdir2 will be created\n";
	`mkdir -p $outdir2`;
}
if (! -e $outdir3) {
	print "outdir3\=$outdir3 will be created\n";
	`mkdir -p $outdir3`;
}

my ($count4, $chr7, $numindiv, $tnumindiv, $totalmarkers) = 0;
my ($out2, $out2a, $out3, $out3a, $out4, $out5, $temp, $famid6, $subid6, $marker7) = "";
my @famid = ();
@list5 = ();
$count4 = 0;
$out3 = "$outdir2\/allped_kstat\.geno";
if ( -e $out3) {
	`rm -r $out3`;
}
$out3a = "$outdir3\/kstat\.tmp";
$out4 = "$outdir3\/kstat\.txt";
$out5 = "$outdir3\/kc\.txt";
open (OUT4, ">$out4") || die ("Could not create $out4 file!\n");
print OUT4 "Individual1$,Individual2$,k0$,k1$,k2\n";
open (OUT5, ">$out5") || die ("Could not create $out5 file!\n");


# To handle genotype files that are not ordered by pedigree, let us order them by pedigree
my %indiv = ();
$tnumindiv = 0;
foreach my $fam4 (@fam4) {
	@list5 = ();
	$temp = "";
	print "Recoding genotypes for pedigree $fam4\n";
	print LOG "Pedigree $fam4 : ";
	foreach $line4 (@idin) {
		chomp $line4;
		$line4 =~ s/^\s+//g;
		$line4 =~ s/\s+$//g;
		next if (length($line4) == 0);
		if ($line4 =~ m/^($fam4)[\.|\-|\_](.+)/) {
			$famid = $1;
			$subid = $2;
			$temp = "$famid$,$subid";
			if (!defined($indiv{$temp})) {
				print "ID -- $famid$,$subid\n";
				$indiv{$temp}++;
				push (@list5, $temp);
			} elsif (defined($indiv{$temp})) {
				next;
			}
		} else {
			next;
		}
	}
	
	# Create genotype file for this pedigree
	$out2  = "$outdir2\/ped$fam4\_kstat\.geno";
	open (OUT2, ">$out2") || die ("Could not create $out2 file!\n");
	createPedGeno(@list5);
	`cat $out2 >> $out3`;
}

# Now let us run kstat using genotype data of all the pedigrees
print "\nRunning kstat now...\n";
print "Input file                  : $out3\n";
print "Output file                 : $out1\n";
print "Total number of individuals : $tnumindiv\n";
print "Total number of markers     : $totalmarkers\n";
print LOG "\nInput file                  : $out3\n";
print LOG "Output file                 : $out1\n";
print LOG "Total number of individuals : $tnumindiv\n";
print LOG "Total number of markers     : $totalmarkers\n";
# Parse $kstat
my ($kstatdir, $systembit) = split (/\s+/, $kstat);
my $systemkstat = "$kstatdir\/kstat$systembit";
# Check dimensions of input file
my $allindiv = `wc -l $out3 | awk '{FS=" "}{print \$1}'`;
chomp $allindiv;
my $preallmarkers = `head -1 $out3 | wc -w`;
chomp $preallmarkers;
my $allmarkers = $preallmarkers - 1;
if ( ($allindiv == $tnumindiv) && ($allmarkers == $totalmarkers) ) {
	print "The dimensions of the input file match the total number of individuals and markers above\n";
	print "Will now execute $systemkstat $out3 $out3a $allindiv $allmarkers\n";
	system("$systemkstat $out3 $out3a $allindiv $allmarkers");
} else {
	print "Will execute $systemkstat $out3 $out3a $allindiv $allmarkers\n";
	system("$systemkstat $out3 $out3a $allindiv $allmarkers");
}

system("tail -n +2 $out3a >> $out4");
close (OUT4);

open (IN5, "<$out4") || die ("Could not open $out4 file!\n");
my %k012 = ();
while (defined ($line5 = <IN5>)) {
	chomp $line5;
	$line5 =~ s/^\s+//g;
	$line5 =~ s/\s+$//g;
	next if ( ($line5 =~ m/Individual/) || (length($line5) == 0) );
	my ($subid5a, $subid5b, $k012) = split (/\t|\s+/, $line5, 3);
	$k012{$subid5a}{$subid5b} = $k012;
	$k012{$subid5b}{$subid5a} = $k012;
}
close (IN5);

open(OUT1, ">$out1") || die ("Could not create $out1 file!\n");
print OUT1 "Individual1$,Individual2$,k0$,k1$,k2$,Kinship_Coefficient\n";
my $kinshippl = "$kstatdir\/kinship.pl";
system("$kinshippl $out4 $out5");
close (OUT5);
open(TMP, "<$out5") || die ("Could not open $out5 file!\n");
while (defined ($line8 = <TMP>)) {
	chomp $line8;
	$line8 =~ s/^\s+//g;
	$line8 =~ s/\s+$//g;
	next if ($line8 =~ m/sub_1/);
	my ($famid_subid8a, $famid_subid8b, $kc8) = split (/\s+/, $line8);
	my ($fam8, $famid8a, $subid8a, $famid8b, $subid8b) = "";
	foreach $fam8 (@fam4) {
		if ($famid_subid8a =~ m/^($fam8)[\.|\-|\_](.+)/) {
			$famid8a = $1;
			$subid8a = $2;
			last;
		}
	}
	foreach $fam8 (@fam4) {
		if ($famid_subid8b =~ m/^($fam8)[\.|\-|\_](.+)/) {
			$famid8b = $1;
			$subid8b = $2;
			last;
		}
	}
	$kc8 = sprintf("%.10f", $kc8);
	$subid8a = "$famid8a\_$subid8a";
	$subid8b = "$famid8b\_$subid8b";
	my $k012i = $k012{$subid8a}{$subid8b};
	my ($k0, $k1, $k2) = split (/\s+/, $k012i);
	print OUT1 "$subid8a$,$subid8b$,$k0$,$k1$,$k2$,$kc8\n";
}
close (TMP);
close (OUT1);

##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);

print "\nTotal real time   : " . parsetime ($real);
print   "Total user time   : " . parsetime ($user);
print   "Total system time : " . parsetime ($system);
print LOG "\nTotal real time   : " . parsetime ($real);
print LOG   "Total user time   : " . parsetime ($user);
print LOG   "Total system time : " . parsetime ($system);
print "\nDone\n\n";
close (LOG);

##### SUBROUTINES #####

sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}

sub createPedGeno {
	my @ped = @_;
	@marker3 = @marker3;
	$out2 = $out2;
	$out3 = $out3;
	$numindiv = 0;
	$numindiv = scalar(@ped);
	$totalmarkers = scalar(@marker3);
	$tnumindiv += $numindiv;
	foreach $line6 (@ped) {
		chomp $line6;
		$line6 =~ s/^\s+//g;
		$line6 =~ s/\s+$//g;
		next if (length($line6) == 0);
		($famid6, $subid6) = split(" ", $line6);
		print OUT2 "$famid6\_$subid6";
		foreach $line7 (@marker3) {
			chomp $line7;
			($chr7, $marker7) = split (" ", $line7);
			$chr_marker7 = $chr7 . "_" . $marker7;
			$famid_subid6 = $famid6 . "_" . $subid6;
			if (defined($exclude{$chr7}{$marker7})) { next; }
			print OUT2 "$,$imgeno{$chr7}{$marker7}{$famid6}{$subid6}";
		}
		print OUT2 "\n";
	}
	close (OUT2);
	print LOG "$numindiv individuals in pedigree $totalmarkers markers\n";
	
}


