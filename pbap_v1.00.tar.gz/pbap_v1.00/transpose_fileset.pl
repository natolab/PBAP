#!/usr/bin/perl
# transpose_fileset.pl
# By Alejandro Q. Nato, Jr., Ph.D.
# This script prepares normal and transposed file formats
# from separate pedigree, genotype, and map files that have 
# a normal (row-subject) file format.

# 06/18/2013-07/25/2013
# Modifications: 08/05/2013-03/17/2015



use strict;
use warnings;
use diagnostics;

use Time::HiRes qw( gettimeofday );

my ($line, $line1, $line2, $line3, $line4, $line5, $line6, $line7, $line8, $line9)  = "";
my (@list, @list1, @list2, @list3, @list4, @list5, @list6, @list7, @list8, @list9)  = ();
my (@info, @info1, @info2, @info3, @info4, @info5, @info6, @info7, @info8, @info9)  = ();
my ($famid, $indiv, $pat, $mat, $sex, $famid2, $match, $geno, $pheno, $size) = 0;
my ($id1, $id2, $id3, $id4) = "";
my (@list2a, @list3a, @list4a) = ();
my ($chrom, $parfile, $singlefam) = "";

$, = " ";	# set output field separator

if ($#ARGV == 1) {
	$chrom   = $ARGV[0];	# chromosome
	$parfile = $ARGV[1];	# parameter file (use absolute path)
} elsif ($#ARGV == 2) {
	$chrom   = $ARGV[0];	# chromosome
	$parfile = $ARGV[1];	# parameter file (use absolute path)
	$singlefam = $ARGV[2];	# single family (useful for parallel runs)
}

my ($script, $script1) = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;


if ($#ARGV < 0) {
	$script  = $0;
	$script  =~ s/^(.+)\///g;
	$script  =~ s/^\.\///g;
	$script1 = $script;
	$script1 =~ s/\.pl//g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (June-July 2013; updated August 2013-March 2015)\n\n";
	print "This script prepares normal and transposed filesets\n";
	print "from separate pedigree, phenotype, genotype, and map files\n";
	print "that have a row-subject format.\n\n";
	
	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script chromosome $script1\_parameter_file* family_ID**\n";
	print "       *use absolute path\n";
	print "       **(optional): indicate family ID here if you only want to run $script1 on one family\n\n";
	
	print "Parameter file should contain the following:\n\n";
	print "\tLine  1 - Directory containing $script\n";
	print "\tLine  2 - Directory for output files\n";
	print "\t             Directory will be created if it does not exist\n";
	print "\t             Chromosome subdirectories will automatically be created under this directory\n";
	print "\tLine  3 - Additional codes for missing data\n";
	print "\t             PBAP codes for missing data: -0-, MISSING, MIS, miss, NA, -9, -1, 0, and -\n";
	print "\t             \"0\" will not be considered as missing in map files\n";
	print "\t             If you don't have additional codes aside from the ones mentioned above, put \"no_extra_code\"\n";
	print "\t             Otherwise, put codes for missing data in your pedigree, phenotype, and map files here\n";
	print "\t             Format (space-delimited): e.g., \"-0- MISSING MIS miss NA -9 -1 0 -\"\n";

	print "\tLine  4 - Input pedigree filename\n";
	print "\t             Use one pedigree file that includes all families\n";
	print "\t             Use any of the following formats:\n";
	print "\t             FamilyID, FamilyID.IndividualID, FamilyID.FatherID, FamilyID.MotherID, Sex\n";
	print "\t             FamilyID, IndividualID, FatherID, MotherID, Sex\n";
	print "\t             FamilyID.IndividualID, FamilyID.FatherID, FamilyID.MotherID, Sex\n";
	print "\t             FamilyID, IndividualID, FatherID, MotherID, Sex, Affectation Status (or Phenotype), Genotypes\n";
	print "\tLine  5 - Input pedigree file has a header or not: header=[T|F]\n";

	print "\tLine  6 - Input phenotype filename: [phenotype_filename|none]\n";
	print "\t             Use one phenotype file that includes all families\n";
	print "\t                or put \"none\" if there is no phenotype file (put \"none\" in lines 7-11, too)\n";
	print "\t             Examples of formats:\n";
	print "\t             FamilyID.IndividualID, Phenotype(s)\n";
	print "\t             FamilyID, IndividualID, FatherID, MotherID, Sex, Affectation Status (or Phenotype), Genotypes\n";
	print "\tLine  7 - Input phenotype file has a header or not: header=[T|F]\n";
	print "\tLine  8 - Columns in phenotype file containing FamilyID and Individual ID\n";
	print "\t             e.g., if column 1 contains FamilyID.IndividualID, put \"1\"\n";
	print "\t             if column 2 contains FamilyID.IndividualID, put \"2\"\n";
	print "\t             if columns 1 and 2 contain FamilyID and IndividualID, respectively,  put \"1 2\"\n";
	print "\tLine  9 - Contiguous columns in phenotype file for phenotypes/covariates of interest\n";
	print "\t             e.g., if there's only one phenotype and it is in column 5, put \"5\"\n";
	print "\t             If there are several phenotypes/covariates and are in columns 5-10, put \"5-10\"\n";
	print "\t             Missing phenotype data will be recoded as \"NA\" except for MORGAN-format (recoded as 0)\n";
	print "\t             If you are using one *.ped file for the pedigree, phenotype, and genotype files\n";
	print "\t             where phenotype data is in column 6, put \"6\"\n";
	print "\tLine 10 - Column in phenotype file for normal fileset ped file and PLINK-format tfam file\n";
	print "\t             e.g., if phenotype is in column 5, put \"5\"\n";
	print "\t             Missing phenotype data will be recoded as \"NA\"\n";
	print "\tLine 11 - Description of phenotype: pheno=[description of phenotype]\n";
	print "\t             This will help user track which phenotype was included in PLINK-format files\n";

	print "\tLine 12 - Phenotype conversion file (for MORGAN-format pedigree file)\n";
	print "\t             Use one file for the entire dataset. If you don't have a phenotype conversion file,\n";
	print "\t                put \"none number_of_integer_phenotypes number_of_real_phenotypes\" for this line\n";
	print "\t                e.g., \"none 1 0\" if you only have one phenotype and it is an integer/binary\n";
	print "\t             If you have a phenotype file but don't specify a phenotype conversion file,\n";
	print "\t                PBAP assumes that you already have the correct format so phenotype values and\n";
	print "\t                phenotype columns won't be changed\n";
	print "\t             Format (space-delimited):\n";
	print "\t                Column Number in Phenotype File, Type [Binary|Continuous|Integer|String], Affectation Status, Value(s)\n";
	print "\t                If phenotype is binary, specify value(s) for affectation status 0, 1, and 2\n";
	print "\t                If phenotype is continuous, integer, or string and you want to keep it as is,\n";
	print "\t                   specify value(s) only for affectation status 0 (missing)\n";
	print "\t                If phenotype is continuous, integer, or string and you want to convert it into a binary variable,\n";
	print "\t                   specify value(s) only for affectation status 0, 1, and 2\n";
	print "\t                For value(s), you can specify a single value, a set of values (comma-delimited),\n";
	print "\t                   or a range of values (dash-delimited)\n";
	print "\t                   e.g., set of values: 2,5,7,8\n";
	print "\t                         range of values: 2-10\n";
	
	print "\tLine 13 - Directory containing map files\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 14 - [(prefix=) (suffix=)] of chromosome number in names of subdirectories\n";
	print "\t             where map files are located\n";
	print "\tLine 15 - [(prefix=) (suffix=)] of chromosome number in input map filenames\n";
	print "\t             e.g., if if your files are named chr*-map.txt, put \"prefix=chr suffix=-map.txt\"\n";
	print "\tLine 16 - Input map file has a header or not: header=[T|F]\n";
	print "\tLine 17 - Columns in map file for chromosome, marker, genetic location, and physical position,\n";
	print "\t             e.g., if chromosome, marker, genetic location, and physical position\n";
	print "\t             are in columns 2, 1, 6, and 5, respectively, put \"2 1 6 5\"\n";
	print "\t             Marker genetic locations should be in Haldane cM\n";

	print "\tLine 18 - Directory containing genotype data\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 19 - [(prefix=) (suffix=)] of chromosome number in names of subdirectories\n";
	print "\t             where genotype files are located\n";
	print "\tLine 20 - [(prefix=) (suffix=)] of chromosome number in input genotype filenames\n";
	print "\t             e.g., if if your files are named chr*-geno.txt, put \"prefix=chr suffix=-geno.txt\"\n";
	print "\tLine 21 - Input genotype file has a header or not: header=[T|F]\n";
	print "\tLine 22 - Columns in genotype file containing FamilyID and Individual ID\n";
	print "\t             e.g., if column 1 contains FamilyID.IndividualID, put \"1\"\n";
	print "\t             if column 2 contains FamilyID.IndividualID, put \"2\"\n";
	print "\t             If columns 1 and 2 contain FamilyID and IndividualID, respectively,  put \"1 2\"\n";
	print "\tLine 23 - Column containing the allele of the first marker\n";
	print "\t             e.g., If you are using one *.ped file for the pedigree, phenotype, and genotype files\n";
	print "\t             where genotype data starts at column 7, put \"7\"\n";
	print "\t             If your genotype file is already in the PBAP format,\n";
	print "\t             i.e., columns are FamilyID.IndividualID and Genotypes, put \"2\"\n";

	print "\tLine 24 - Delete normal fileset (ped/map): [Y|N]\n";
	print "\tLine 25 - Delete Plink-format transposed fileset (tfam/tped): [Y|N]\n";
	print "\tLine 26 - Marker Type: [SNP|STR]\n";
	print "\tLine 27 - Option: [include|exclude] markers without genetic locations\n";
	print "\tLine 28 - Option: [include|exclude] markers without physical positions\n";
	print "\tLine 29 - Priority: option for [genetic|physical] in line 27 or 28 overrides the other\n";

	print "\tLine 30 - File containing substitutes of current FamilyIDs\n";
	print "\t             MORGAN implements a maximum of 15 characters for the ID of an individual\n";
	print "\t             If you'll use makeped, it implements a maximum of 11 characters\n";
	print "\t             PBAP only employs the maximum of 15 characters\n";
	print "\t             The total number of characters for FamilyID_SubjectID should be less than 14\n";
	print "\t             since an underscore will be inserted\n";
	print "\t             Use this file to change/shorten the FamilyIDs of certain individuals\n";
	print "\t             Format (space-delimited): Current_FamilyID, New_FamilyID\n";
	print "\t             If you don't need to shorten any Family ID (i.e., no file), put \"none\"\n";
	print "\tLine 31 - If you have a FamilyID substitution file in line 30\,\n";
	print "\t             renumber the IndividualIDs within each family from 1 through n: [Y|N]\n";
	print "\t             If yes, only the FamilyIDs listed in the FamilyID substitution file will be renumbered\n";
	print "\t             If you don't have a FamilyID substitution file in line 30, put \"N\"\n";
	print "\tLine 32 - If you have an IndividualID substitution file instead of FamilyID substitution file\,\n";
	print "\t             and you don't want PBAP to renumber IndividualIDs, put filename here\n";
	print "\t             Format (space-delimited): CurrentFamilyID, CurrentIndividualID, NewFamilyID, NewIndividualID\n";
	print "\t             If you don't have an IndividualID substitution file, put \"none\"\n";
	
	print "\tNotes: 1) Blank lines and lines that start with a pound sign (#) will be ignored\n";
	print "\t       2) Use absolute paths for all directories and filenames unless specified otherwise\n";
	print "\t       3) To avoid mismatching, all subject IDs should be concatenated with family IDs,\n";
	print "\t             e.g., \"FamilyID.IndividualID\" or \"FamilyID_IndividualID\"\n";
	print "\t             Maximum number of characters for FamilyID + IndividualID is 14 in preparation for MORGAN\n"; 
	print "\t       4) Pedigree and phenotype file codes for missing (e.g., NA, -0-, MIS, miss, -1, -9, 0, or -) will be\n";
	print "\t             converted to 0 and NA, respectively\n";
	print "\t       5) For subdirectories in lines 14 and 19, if files in lines 15 and 20 are directly\n";
	print "\t             under the directories in lines 13 and 18, respectively, put \"no dir\"\n";
	print "\t             Examples (if subdirectories are present):\n";
	print "\t             If subdirectories are named chr*, put \"prefix=chr suffix=none\" or simply \"prefix=chr\"\n";
	print "\t             If subdirectories are named chr*geno, put \"prefix=chr suffix=geno\"\n";
	print "\t       6) Lines 4-5, 6-12, 13-17, and 18-23 are for the pedigree, phenotype, map and genotype files, respectively\n\n";
	exit;
}

my $count = 0;
my ($scriptdir, $outdir) = "";
my ($pedfile, $pedh) = "";
my ($phenofile, $phenoh, $phenoindiv, $phenocol, $phenodesc, $phenotped, $phenoconv) = "";
my ($mapname, $maph, $mapel) = "";
my ($genoname, $genoh, $genoindiv, $genocol) = "";

my ($mainmdir, $mapdir, $mapdirpre, $mapdirsuf, $mapdirin, $mappre, $mapsuf) = "";
my ($maingdir, $genodir, $genodirpre, $genodirsuf, $genodirin, $genopre, $genosuf) = "";
my ($mapfdir, $mapfile, $genofdir, $genofile) = "";

my ($transposed, $missing, $mtype, $delnorm, $delplinkt) = "";
my ($includeg, $includep, $prevail, $substfile, $renumber, $idsubfile) = "";

my @missing = ();

open (IN, "<$parfile") || die ("Could not open $parfile!\n");
@list = <IN>;
close (IN);
print "\nThese are the parameters that you specified:\n";
foreach $line (@list) {
	chomp $line;
	next if ($line =~ m/^\#/);
	next if ($line =~ m/^\s*$/);
	next if ( ($line =~ m/\t|\#/) && ( ($line =~ m/line|:|\"|\=/i) || ($line !~ m/\d/)) );
	next if (length($line) == 0);
	$line =~ s/^\s+//g;
	$line =~ s/\s+$//g;
	$count++;
	print "line $count: $line\n";
	if ($count == 1) { $scriptdir      = $line; }
	elsif ($count == 2) { $outdir      = $line; }
	elsif ($count == 3) { $missing     = $line; }
	
	elsif ($count == 4) { $pedfile     = $line; }
	elsif ($count == 5) { $pedh        = $line; }
	
	elsif ($count == 6)  { $phenofile  = $line; }
	elsif ($count == 7)  { $phenoh     = $line; }
	elsif ($count == 8)  { $phenoindiv = $line; }
	elsif ($count == 9)  { $phenocol   = $line; }
	elsif ($count == 10) { $phenotped  = $line; }
	elsif ($count == 11) { $phenodesc  = $line; }
	elsif ($count == 12) { $phenoconv  = $line; }
	
	elsif ($count == 13) { $mainmdir   = $line; }
	elsif ($count == 14) { $mapdir     = $line; }
	elsif ($count == 15) { $mapname    = $line; }
	elsif ($count == 16) { $maph       = $line; }
	elsif ($count == 17) { $mapel      = $line; }
	
	elsif ($count == 18) { $maingdir   = $line; }
	elsif ($count == 19) { $genodir    = $line; }
	elsif ($count == 20) { $genoname   = $line; }
	elsif ($count == 21) { $genoh      = $line; }
	elsif ($count == 22) { $genoindiv  = $line; }
	elsif ($count == 23) { $genocol    = $line; }
	
	elsif ($count == 24) { $delnorm    = $line; }
	elsif ($count == 25) { $delplinkt  = $line; }
	elsif ($count == 26) { $mtype      = $line; }
	elsif ($count == 27) { $includeg   = $line; }
	elsif ($count == 28) { $includep   = $line; }
	elsif ($count == 29) { $prevail    = $line; }
	elsif ($count == 30) { $substfile  = $line; }
	elsif ($count == 31) { $renumber   = $line; }
	elsif ($count == 32) { $idsubfile  = $line; }
}
print "\n";
if ($scriptdir =~ m/\/$/) { chop $scriptdir; }
if ($mainmdir =~ m/\/$/) { chop $mainmdir; }
if ($maingdir =~ m/\/$/) { chop $maingdir; }
if ($outdir =~ m/\/$/)   { chop $outdir; }

my $outdir_old = $outdir;
if (!defined($singlefam)) {
	$outdir = $outdir . "/allpeds/chr" . $chrom;
} elsif (defined($singlefam)) {
	$outdir = $outdir . "/ped" . $singlefam . "/chr" . $chrom;
}

if (! -e $outdir) {
	print "outdir\=$outdir will be created\n";
	`mkdir -p $outdir`;
}

my $log = $outdir . "/transpose_fileset_chr" . $chrom . ".log";
my $auxdir = $outdir."/aux";
chomp $auxdir;
if ($auxdir =~ m/\/$/) { chop $auxdir; }
if ( ! -e $auxdir ) {
	print "auxdir\=$auxdir will be created\n";
	`mkdir -p $auxdir`;
}

open (LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "######################################################################################################\n";
print LOG "#                                    PBAP transpose_fileset.pl                                       #\n";
print LOG "#                                      Alejandro Q. Nato, Jr.                                        #\n";
print LOG "#                                     Statistical Genetics Lab                                       #\n";
print LOG "#                              University of Washington, Seattle, WA                                 #\n";
print LOG "######################################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

# Skip $missing[0] for map files
@missing = qw/0 NA - -0- MISSING MIS miss -9 -1/;
my %missing = ();
foreach my $m (@missing) {
	$missing{$m}++;
}
if ($missing =~ m/^no_extra_code$/i) {
	# do nothing
} elsif ($missing !~ m/^no_extra_code$/i) {
	my @addmiss = split (" ", $missing);
	foreach my $n (@addmiss) {
		if (!defined($missing{$n})) {
			push (@missing, $n);
			$missing{$n}++;
		}
	}
}

my ($pfamid, $pindiv, $pid, $pfamcol, $pindcol, $pidcol) = "";
my ($gfamid, $gindiv, $gid, $gfamcol, $gindcol, $gidcol) = "";
my ($pcolumn1, $pcolumn2, $numpheno) = 0;

if ($phenocol =~ m/\-/) {
	($pcolumn1, $pcolumn2) = split(/\-/, $phenocol);
	$numpheno = $pcolumn2 - $pcolumn1 + 1;
} else {
	$pcolumn1 = $pcolumn2 = $phenocol;
}
if ($phenodesc =~ m/pheno\=(.+)/) {
	$phenodesc = $1;
}
if ($genoindiv =~ m/\s+/) {
	# FamilyID and IndividualID are in separate columns
	($gfamcol, $gindcol) = split (" ", $genoindiv);
	$gfamcol -= 1;
	$gindcol -= 1;
} elsif ($genoindiv !~ m/\s+/) {
	# ID contains both FamilyID and IndividualID
	$gidcol = $genoindiv - 1;
}

if ($#ARGV == 1) {
	print LOG "Command-line arguments used: $chrom$,$parfile\n\n";
} elsif ($#ARGV == 2) {
	print LOG "Command-line arguments used: $chrom$,$parfile$,$singlefam\n\n";
}

print LOG "PARAMETERS SPECIFIED:\n";
print LOG "Output directory                                   : $outdir\n";
print LOG "Output filenames                                   : chr\*\.\*\n";

if ($missing =~ m/^none$/i) {
	print "Codes for missing data : none\n";
	print LOG "Codes for missing data                             : none\n";
} elsif ($missing !~ m/^none$/i) {
	print "Codes for missing data : " . join (", ", @missing) . "\n";
	print LOG "Codes for missing data                             : " . join (", ", @missing) . "\n";
}

# Pedigree file
print LOG "Pedigree file                                      : $pedfile \($pedh\)\n";

# Phenotype file
if ($phenofile !~ m/^none/) {
	print LOG "Phenotype file                                     : $phenofile \($phenoh\)\n";
	print LOG "Column(s) for ID in phenotype file                 : ";
	if ($phenoindiv !~ m/\s+/) {
		# ID contains both FamilyID and IndividualID
		print LOG "$phenoindiv\n";
		$pidcol = $phenoindiv - 1;
	} elsif ($phenoindiv =~ m/\s+/) {
		# FamilyID and IndividualID are in separate columns
		($pfamcol, $pindcol) = split (" ", $phenoindiv);
		print LOG "$pfamcol and $pindcol\n";
		$pfamcol -= 1;
		$pindcol -= 1;
	}
	print LOG "Column(s) for phenotype(s) in phenotype file       : ";
	if ($pcolumn1 == $pcolumn2) { print LOG "$pcolumn1\n"; } else { print LOG "$pcolumn1\-$pcolumn2\n"; }
	print LOG "Column for phenotype for ped and tfam files        : $phenotped\n";
	print LOG "Description of phenotype                           : $phenodesc\n";
} elsif ($phenofile =~ m/^none/) {
	print LOG "Phenotype file                                     : none\n";
}

# Map file
if ($mapdir eq "no dir") {
	# map files are directly under mainmdir
	$mapfdir = $mainmdir;
} elsif ($mapdir ne "no dir") {
	if ($mapdir eq "none") {
		$mapdirpre = "";
		$mapdirsuf = "";
	} elsif ($mapdir =~ m/prefix\=(.+) suffix\=(.+)/) {
		$mapdirpre = $1;
		$mapdirsuf = $2;
		if ($mapdirpre eq "none") { $mapdirpre = ""; }
		if ($mapdirsuf eq "none") { $mapdirsuf = ""; }
	} elsif ( ($mapdir =~ m/prefix\=(.+)/) && ($mapdir !~ m/suffix\=(.+)/) ) {
		$mapdirpre = $1;
		$mapdirsuf = "";
		if ($mapdirpre eq "none") { $mapdirpre = ""; }
	} elsif ( ($mapdir !~ m/prefix\=(.+)/) && ($mapdir =~ m/suffix\=(.+)/) ) {
		$mapdirpre = "";
		$mapdirsuf = $1;
		if ($mapdirsuf eq "none") { $mapdirsuf = ""; }
	}
	$mapfdir = $mainmdir . "/" . $mapdirpre . $chrom . $mapdirsuf;
}
if ($mapname =~ m/prefix\=(.+) suffix\=(.+)/) {
	$mappre = $1;
	$mapsuf = $2;
	if ($mappre eq "none") { $mappre = ""; }
	if ($mapsuf eq "none") { $mapsuf = ""; }
} elsif ( ($mapname =~ m/prefix\=(.+)/) && ($mapname !~ m/suffix\=(.+)/) ) {
	$mappre = $1;
	$mapsuf = "";
	if ($mappre eq "none") { $mappre = ""; }
} elsif ( ($mapname !~ m/prefix\=(.+)/) && ($mapname =~ m/suffix\=(.+)/) ) {
	$mappre = "";
	$mapsuf = $1;
	if ($mapsuf eq "none") { $mapsuf = ""; }
}
$mapfile = $mapfdir . "/" . $mappre . $chrom . $mapsuf;
print "Map file : $mapfile\n";
print LOG "Map file                                           : $mapfile \($maph\)\n";
my ($chr, $marker, $genloc, $phypos) = split (" ", $mapel);
print LOG "Map columns                                        : chr\=$chr marker\=$marker genetic location\=$genloc physical position\=$phypos\n";

# Genotype file
if ($genodir eq "no dir") {
	# genotype files are directly under maingdir
	$genofdir = $maingdir;
} elsif ($genodir ne "no dir") {
	if ($genodir eq "none") {
		$genodirpre = "";
		$genodirsuf = "";
	} elsif ($genodir =~ m/prefix\=(.+) suffix\=(.+)/) {
		$genodirpre = $1;
		$genodirsuf = $2;
		if ($genodirpre eq "none") { $genodirpre = ""; }
		if ($genodirsuf eq "none") { $genodirsuf = ""; }
	} elsif ( ($genodir =~ m/prefix\=(.+)/) && ($genodir !~ m/suffix\=(.+)/) ) {
		$genodirpre = $1;
		$genodirsuf = "";
		if ($genodirpre eq "none") { $genodirpre = ""; }
	} elsif ( ($genodir !~ m/prefix\=(.+)/) && ($genodir =~ m/suffix\=(.+)/) ) {
		$genodirpre = "";
		$genodirsuf = $1;
		if ($genodirsuf eq "none") { $genodirsuf = ""; }
	}
	$genofdir = $maingdir . "/" . $genodirpre . $chrom . $genodirsuf;
}
if ($genoname =~ m/prefix\=(.+) suffix\=(.+)/) {
	$genopre = $1;
	$genosuf = $2;
	if ($genopre eq "none") { $genopre = ""; }
	if ($genosuf eq "none") { $genosuf = ""; }
} elsif ( ($genoname =~ m/prefix\=(.+)/) && ($genoname !~ m/suffix\=(.+)/) ) {
	$genopre = $1;
	$genosuf = "";
	if ($genopre eq "none") { $genopre = ""; }
} elsif ( ($genoname !~ m/prefix\=(.+)/) && ($genoname =~ m/suffix\=(.+)/) ) {
	$genopre = "";
	$genosuf = $1;
	if ($genosuf eq "none") { $genosuf = ""; }
}
$genofile = $genofdir . "/" . $genopre . $chrom . $genosuf;
print "Genotype file : $genofile\n";
print LOG "Genotype file                                      : $genofile\($genoh\)\n";

# Other parameters
print LOG "Delete normal fileset (ped/map)                    : $delnorm\n";
print LOG "Delete Plink-format transposed fileset (tfam/tped) : $delplinkt\n";
print LOG "Marker type                                        : $mtype\n";
print LOG "Markers without genetic locations                  : $includeg\n";
print LOG "Markers without physical positions                 : $includep\n";
print LOG "Priority                                           : $prevail\n\n";
my (%origfam, %substfam, %oldid, %subsid) = ();
my ($oldfam, $newfam, $oldid, $subsid) = "";
if ($substfile !~ m/^none$/) {
	open (SUBST, "<$substfile") || die ("Could not open $substfile file!\n");
	print "\nCurrent_FamilyID New_FamilyID\n";
	while (defined (my $subst = <SUBST>)) {
		chomp $subst;
		$subst =~ s/^\s+//g;
		$subst =~ s/\s+$//g;
		next if (length($subst) == 0);
		next if ($subst =~ m/^\#/);
		($oldfam, $newfam) = split (/\s+/, $subst);
		$substfam{$oldfam} = $newfam;
		$origfam{$newfam}  = $oldfam;
		print "$oldfam $substfam{$oldfam}\n";
	}
	print "\n";
	close (SUBST);
} elsif ($idsubfile !~ m/^none$/) {
	open (IDSUB, "<$idsubfile") || die ("Could not open $idsubfile file!\n");
	print "\nCurrent_FamilyID Current_IndividualID New_FamilyID New_IndividualID\n";
	while (defined (my $subst = <IDSUB>)) {
		chomp $subst;
		$subst =~ s/^\s+//g;
		$subst =~ s/\s+$//g;
		next if (length($subst) == 0);
		next if ($subst =~ m/^\#/);
		($oldfam, $oldid, $newfam, $subsid) = split (/\s+/, $subst);
		$substfam{$oldfam} = $newfam;
		$origfam{$newfam}  = $oldfam;
		if ($oldid =~ m/^$oldfam[\.|\-|\_](.+)/) {
			$oldid = $1;
		}
		$subsid{$oldfam}{$oldid}  = $subsid;
		$oldid{$newfam}{$subsid} = $oldid;
		
		# add hash where all delimiters are converted to underscore
		my $oldfam2 = $oldfam;
		my $oldid2  = $oldid;
		$oldfam2 =~ s/[\.|\-|\_]/\_/g;
		$oldid2 =~ s/[\.|\-|\_]/\_/g;
		$subsid{$oldfam2}{$oldid2}  = $subsid;
		print "$oldfam$,$oldid$,$substfam{$oldfam}$,$subsid{$oldfam}{$oldid}\n";
	}
	print "\n";
	close (IDSUB);
}

# Output files for pipeline
my $tpedo = $outdir."/chr".$chrom.".tpedo";
my $mped  = $outdir."/chr".$chrom.".mped";
my $tphen = $outdir."/chr".$chrom.".tphen";
my $tgen  = $outdir."/chr".$chrom.".tgen";
my $tmap  = $outdir."/chr".$chrom.".tmap";
my $tind  = $outdir."/chr".$chrom.".tind";
my $tpedo1 = $tpedo; $tpedo1 =~ s/$outdir\///g;
my $mped1  = $mped;  $mped1  =~ s/$outdir\///g;
my $tphen1 = $tphen; $tphen1 =~ s/$outdir\///g;
my $tgen1  = $tgen;  $tgen1  =~ s/$outdir\///g;
my $tmap1  = $tmap;  $tmap1  =~ s/$outdir\///g;
my $tind1  = $tind;  $tind1  =~ s/$outdir\///g;
print LOG "MAIN OUTPUT FILES (under $outdir):\n";
print LOG "Pedigree file (Family ID, Individual ID, Father ID, Mother ID, Sex)                  : $tpedo1\n";
if ($phenofile !~ m/^none/) {
	print LOG "MORGAN-format pedigree file (Individual ID, Father ID, Mother ID, Sex, Phenotype(s)) : $mped1\n";
	print LOG "Phenotype file (Individual ID, Phenotype(s))                                         : $tphen1\n";
}
print LOG "Genotype file (Chromosome, Marker, Genotypes)                                        : $tgen1\n";
print LOG "Map file (Chromosome, Marker, Genetic Location, Physical Position)                   : $tmap1\n";
print LOG "Genotyped individuals (IDs of genotyped individuals)                                 : $tind1\n\n";

# Normal fileset filenames
my $pedout    = $outdir."/chr".$chrom.".ped";
my $mapout = $outdir."/chr".$chrom.".map";
open (OUT1, ">$pedout") || die ("Could not create $pedout file!\n");	# pedigree file per chromosome
open (OUT2, ">$mapout") || die ("Could not create $mapout file!\n");	# map file per chromosome
my $pedout1 = $pedout; $pedout1 =~ s/$outdir\///g;
my $mapout1 = $mapout; $mapout1 =~ s/$outdir\///g;

# Plink-format transposed fileset filenames
my $tfamout = $outdir."/chr".$chrom.".tfam";
my $tpedout = $outdir."/chr".$chrom.".tped";
my $tfamout1 = $tfamout; $tfamout1 =~ s/$outdir\///g;
my $tpedout1 = $tpedout; $tpedout1 =~ s/$outdir\///g;

if ($delnorm =~ m/N|No/i) {
	print LOG "NORMAL FILESET (under $outdir):\n";
	print LOG "Pedigree file (Family ID, Individual ID, Father ID, Mother ID, Sex, Phenotype, Genotypes) : $pedout1\n";
	print LOG "Map file (Chromosome, Marker, Genetic Location, Physical Position)                        : $mapout1\n\n";
}
if ($delplinkt =~ m/N|No/i) {
	print LOG "PLINK-FORMAT TRANSPOSED FILESET (under $outdir):\n";
	print LOG "Pedigree file (Family ID, Individual ID, Father ID, Mother ID, Sex, Phenotype)              : $tfamout1\n";
	print LOG "SNP-genotype file (Chromosome, Marker, Genetic Location, Physical Position, Genotypes)      : $tpedout1\n\n";
}
my $nofout  = $auxdir."/chr".$chrom.".nof";
my $tnogen  = $auxdir."/chr".$chrom.".nogen";
my $pnip    = $auxdir."/chr".$chrom.".pnip";
my $gnip    = $auxdir."/chr".$chrom.".gnip";
my $transID = $auxdir."/chr".$chrom.".trans";
my $nofout1 = $nofout;    $nofout1 =~ s/$auxdir\///g;
my $tnogen1 = $tnogen;    $tnogen1 =~ s/$auxdir\///g;
my $pnip1   = $pnip; $pnip1 =~ s/$auxdir\///g;
my $gnip1   = $gnip; $gnip1 =~ s/$auxdir\///g;

if (-e $tnogen) {
	system ("rm $tnogen");
}
if (-e $pnip) {
	system ("rm $pnip");
}
if (-e $gnip) {
	system ("rm $gnip");
}
if (-e $nofout) {
	system ("rm $nofout");
}
if (-e $transID) {
	system ("rm $transID");
}
print LOG "AUXILIARY FILES (under $auxdir):\n";
if ( ($substfile !~ m/none/) || ($idsubfile !~ m/none/) ) {
	print LOG "- These files contain list of individuals or markers that are not included in the output genotype file\n";
	print LOG "  and an ID translation file contain old and new IDs of individuals.\n";
} elsif ( ($substfile =~ m/none/) && ($idsubfile =~ m/none/) ) {
	print LOG "- These files contain list of individuals or markers that are not included in the output genotype file.\n";
}
# Create a hash of the Family IDs and FamilyID_IndividualID
my (%phenotype, %allpheno, %genotype) = ();
my $allpheno = "";
my $idlength = 0;
my (@exceed, @longid) = ();
my (%fam, %fidiid, %dupiid, %longfam, %exceed, %genoexceed, %newid, %origid, %newfamid, %origfamid, %newindiv, %origindiv) = ();
my (%famid, %dadid, %momid) = ();
$count = 0;
open (IN1, "<$pedfile") || die ("Could not open $pedfile file!\n");			# pedigree file (original set of individuals)
@list1 = <IN1>;
close (IN1);
if ($pedh =~ m/T/) {
	shift @list1;
}
my @listsort1 = sort @list1;
foreach $line1 (@listsort1) {
	chomp $line1;
	next if ($line1 eq "");
	$line1 =~ s/^\s+//g;
	$line1 =~ s/\s+$//g;
	$count++;
	@info1 = split(/\t|\s+/, $line1);
	$size = scalar(@info1);
	if ($size == 4) {
		# get FamilyID from the Individual IDs
		my $id1a   = $info1[0];
		my $id1b   = $info1[1];
		$id1a =~ s/\.|\-/\_/g;
		$id1b =~ s/\.|\-/\_/g;
		if ( ($id1a =~ m/\_/) && ($id1b =~ m/\_/) ) {
			my @idparts1 = split (/\_/, $id1a);
			my @idparts2 = split (/\_/, $id1b);
			my $size1a = scalar(@idparts1);
			my $size1b = scalar(@idparts2);
			my $size1 = 0;
			if ($size1a <= $size1b) {
				$size1 = $size1a;
			} elsif ($size1b < $size1a) {
				$size1 = $size1b;
			}
			my $i = 0;
			$famid = "";
			for ($i = 0; $i < $size1; $i++) {
				if ($idparts1[$i] eq $idparts2[$i]) {
					$famid .= $idparts1[$i];
				} elsif ($idparts1[$i] ne $idparts2[$i]) {
					last;
				}
			}
			if ($id1a =~ m/^$famid\_(.+)/) {
				$indiv = $1;
			}
			
		} elsif ( ($id1a =~ m/\_/) && ($id1b !~ m/\_/) ) {
			# use $id1a
			($famid, $indiv) =  split(/\_([^\_]+)$/, $id1a);
		} elsif ( ($id1a !~ m/\_/) && ($id1b !~ m/\_/) ) {
			# ask the user to check pedigree file
			# can't determine family ID
			print "Check your pedigree file. PBAP cannot determine family ID of $id1a and $id1b\n";
			exit;
		}
	} elsif ($size >= 5) {
		$famid = $info1[0];
		$id1   = $info1[1];
		$id1 =~ s/^\s+//g;
		$id1 =~ s/\s+$//g;
		if ($id1 =~ m/^$famid\_(.+)/) {
			$indiv = $1;
		} else {
			$indiv = $id1;
		}
	}
	if ( (defined($singlefam)) && ($famid ne $singlefam) ) {
		next;
	}
	my $id1c = "";
	if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {	# use the Family ID substitution file (Line 29) and renumber
		if (defined($substfam{$famid})) { 
			$fam{$famid}++;	# hash for original famid
			$famid = $substfam{$famid};
			$fam{$famid}++;	# hash for new famid
		} elsif (!defined($substfam{$famid})) { 
			$fam{$famid}++;	# hash for original famid
		}
		# Put into hash
		my ($origid, $newid) = "";
		if ( (defined($origfam{$famid})) && (defined($substfam{$origfam{$famid}})) ) {
			# famid was replaced
			if ( ! -e $transID) {
				open (TRANSID, ">$transID") || die ("Could not create $transID file!\n");
				print LOG "ID translation file                                                        : $transID\n";
			}
			print TRANSID "$origfam{$famid}$,$indiv$,$famid$,$fam{$famid}\n";
			$origid = "$origfam{$famid}" . "_" . "$indiv";
			$newid = "$famid\_" . "$fam{$famid}";
			#print "origID\=$origid newID\=$newid\n";
			$origid{$newid} = $origid;
			$origfamid{$newid} = $origfam{$famid};
			$origindiv{$newid} = $indiv;
			$newid{$origid} = $newid;
			$newfamid{$origid} = $famid;
			$newindiv{$origid} = $fam{$famid};
			$id1c = $newid;
		} elsif ( (!defined($origfam{$famid})) || (!defined($substfam{$famid})) ) {
			goto REGULAR0;
		}
	} elsif ($idsubfile !~ m/none/) {	# use the Individual ID substitution file (Line 31)
		$fam{$famid}++;
		if ( (defined($indiv)) && (defined($substfam{$famid})) && (defined($subsid{$famid}{$indiv})) ) {
			$indiv = $subsid{$famid}{$indiv};
			$famid = $substfam{$famid};
			$id1c = "$famid\_$indiv";
			if ( ! -e $transID) {
				open (TRANSID, ">$transID") || die ("Could not create $transID file!\n");
				print LOG "ID translation file                                                        : $transID\n";
			}
			print TRANSID "$origfam{$famid}$,$oldid{$famid}{$indiv}$,$famid$,$indiv\n";
		} else {
			$id1c = "$famid\_$indiv";
		}
	} else {	# use the Family ID substitution file (Line 29) if it exists, and do not renumber Individual IDs
		REGULAR0:
		$fam{$famid}++;
		if (defined($substfam{$famid})) {
			$famid = $substfam{$famid};
			$id1c = "$famid\_$indiv";
			if ( ! -e $transID) {
				open (TRANSID, ">$transID") || die ("Could not create $transID file!\n");
				print LOG "ID translation file                                                        : $transID\n";
			}
			print TRANSID "$origfam{$famid}$,$indiv$,$famid$,$indiv\n";
		} elsif (!defined($substfam{$famid})) {
			$id1c = "$famid\_$indiv";
		}
	}
	if (!defined($fidiid{$id1c})) {
		$fidiid{$id1c}++;
		if ( (defined($origfam{$famid})) && (defined($oldid{$famid}{$indiv})) ) {
			# add to hash
			my $id1e = "$origfam{$famid}\_$oldid{$famid}{$indiv}";
			my $oldid_underscore = $oldid{$famid}{$indiv};
			$oldid_underscore =~ s/\.|\-|\_/\_/g;
			$fidiid{$id1e}++;
			$fidiid{"$oldid{$famid}{$indiv}"}++;
			$fidiid{$oldid_underscore}++;
		}
	} elsif (defined($fidiid{$id1c})) {
		$dupiid{$id1c}++;
	}
	if ($phenofile =~ m/^none/) {
		$phenotype{$id1c} = "NA";
		$allpheno{$id1c} = "NA";
	}
	$idlength = length($id1c);
	if ($idlength <= 15) {
		# do nothing
	} elsif ($idlength > 15) {
		# Check if there are individuals in this family with genotype data
		# If there are only 3 individuals with genotype data, it is fine
		#    
		# If there are at least 4 individuals with genotype data, inform the user
		#    since these will be included by setup_gl_auto and run_gl_auto will complain
		$longfam{$famid}++;
		push (@longid, $id1c);
		@list4 = ();
		my @list4a = ();
		my ($famid4a, $indiv4a, $id4a) = "";
		open (IN4, "<$genofile") || die ("Could not open $genofile file!\n");		# genotype file (famid.indiv, genotypes)
		@list4 = <IN4>;
		close (IN4);
		if (defined($origfam{$famid})) {
			@list4a = grep(/^$origfam{$famid}/, @list4);
		} elsif (!defined($origfam{$famid})) {
			@list4a = grep(/^$famid/, @list4);
		}
		@list4 = ();
		foreach my $line4a (@list4a) {
			chomp $line4a;
			$line4a =~ s/^\s+//g;
			$line4a =~ s/\s+$//g;
			my @info4a = split(/\t|\s+/, $line4a);
			if ($genoindiv !~ m/\s+/) {
				# ID contains both FamilyID and IndividualID
				$id4a = $info4a[$gidcol];
				$id4a =~ s/\.|\-/\_/g;
				my @idparts4 = split (/\_/, $id4a);
				my $i = 0;
				my $idparts4 = "";
				# with substfile but don't renumber
				if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
					# Use newfamid and newindiv hashes
					if (defined($newfamid{$id4a})) {
						$famid4a = $newfamid{$id4a};
						$indiv4a = $newindiv{$id4a};
					} elsif (!defined($newfamid{$id4a})) {
						goto REGULAR;
					}
				} elsif ($idsubfile !~ m/none/) {
					goto REGULAR;
				} else {
					REGULAR:
					for ($i = 0; $i <= $#idparts4; $i++) {
						if ($i == 0) {
							$idparts4 = $idparts4[$i];
							if (defined($substfam{$idparts4})) { 
								$id4 =~ s/$idparts4/$substfam{$idparts4}/g;
								$idparts4 = $substfam{$idparts4};
							}
						} elsif ($i >= 1) {
							$idparts4 .= "_" . $idparts4[$i];
						}
						if (defined($fam{$idparts4})) {
							$famid4a = $idparts4;
						} elsif (defined($origfam{$idparts4})) {
							$famid4a = $idparts4;
						} elsif (!defined($fam{$idparts4})) {
							last;
						}
					}
					if ($id4a =~ m/^$famid4a\_(.+)/) {
						$indiv4a = $1;
					}  elsif ($id4a =~ m/^$origfam{$famid4a}\_(.+)/) {
						$indiv4a = $1;
					}
					if (defined($subsid{$famid4a}{$indiv4a})) {
						$indiv4a = $subsid{$famid4a}{$indiv4a};
					} elsif ( (defined($origfam{$famid4a})) && (defined($subsid{$origfam{$famid4a}}{$indiv4a})) ) {
						$indiv4a = $subsid{$origfam{$famid4a}}{$indiv4a};
					}
				}
			} elsif ($genoindiv =~ m/\s+/) {
				# FamilyID and IndividualID are in separate columns
				$famid4a = $info4a[$gfamcol];
				$id4a    = $info4a[$gindcol];
				$id4a =~ s/\.|\-/\_/g;
				if ($id4a =~ m/^$famid4a\_(.+)/) {
					$indiv4a = $1;
				} else {
					$indiv4a = $id4a;
				}
				if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
					# Use newfamid and newindiv hashes
					if (defined($newfamid{"$famid4a\_$indiv4a"})) {
						$famid4a = $newfamid{"$famid4a\_$indiv4a"};
						$indiv4a = $newindiv{"$famid4a\_$indiv4a"};
					} elsif (!defined($newfamid{"$famid4a\_$indiv4a"})) {
						goto REGULAR1A;
					}
				} elsif ($idsubfile !~ m/none/) {
			
			
				} else {
					REGULAR1A:
					if (defined($substfam{$famid4a})) { 
						$famid4a = $substfam{$famid4a}; 
					}
					if (defined($subsid{$famid4a}{$indiv4a})) {
						$indiv4a = $subsid{$famid4a}{$indiv4a};
					} elsif ( (defined($origfam{$famid4a})) && (defined($subsid{$origfam{$famid4a}}{$indiv4a})) ) {
						$indiv4a = $subsid{$origfam{$famid4a}}{$indiv4a};
					}
				}
			}
			my $id4b = "$famid4a\_$indiv4a";
			
			if ($id4b eq $id1c) {
				print "IndividualID\=$famid4a\_$indiv4a idlength\=" . length("$famid4a\_$indiv4a") . "\n";
				$genoexceed{$famid4a}++;
			}
		}
		if ( (!defined($exceed{$famid})) && (defined($genoexceed{$famid})) && ($longfam{$famid} >= 4) && ($genoexceed{$famid} >= 4) ) {
			push (@exceed, $famid);
			$exceed{$famid}++;
		}
	}
}
close (IN1);
if ( -e $transID ) {
	close (TRANSID);
}
if (keys %dupiid) {
	print "The following individuals have more than one entry in your pedigree file\n";
	print LOG "The following individuals have more than one entry in your pedigree file\n";
	foreach my $key (sort keys %dupiid) {
		print "$key\n";
		print LOG "$key\n";
	}
	exit;
}


$count = 0;
my ($selpheno, $fullpheno) = "";
my %phenoh = ();
if ($phenofile !~ m/^none/) {
	open (IN2, "<$phenofile") || die ("Could not open $phenofile file!\n");		# phenotype file (famid.indiv, phenotype)
	my ($pcol, $countphen) = 0;
	($selpheno, $fullpheno) = "";
	while (defined ($line2 = <IN2>)) {
		chomp $line2;
		$line2 =~ s/^\s+//g;
		$line2 =~ s/\s+$//g;
		next if ( ($line2 =~ m/^\#/) || (length($line2) == 0) );
		$count++;
		if ( ($phenoh =~ m/T/) && ($count == 1) ) {
			# Get the header
			print "Phenotype header: $line2\n";
			my @phenoh = split(/\s+/, $line2);
			my $h = 0;
			for ($h = ($pcolumn1 - 1); $h <= ($pcolumn2 - 1); $h++) {
				my $i = $h + 1;
				$phenoh{$i} = $phenoh[$h];
			}
			next;
		}
		@info2 = split(/\t|\s+/, $line2);
		my ($famid4, $indiv4) = "";
		$id4 = "";
		if ($phenoindiv !~ m/\s+/) {
			# ID contains both FamilyID and IndividualID
			$id4 = $info2[$pidcol];
			$id4 =~ s/\.|\-/\_/g;
			my @idparts4 = split (/\_/, $id4); 
			my $numparts = scalar (@idparts4);
			my $i = 0;
			my $idparts4 = "";
			if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
				# Skip individuals not needed if singlefam was specified
				if (defined($singlefam)) {
					if ($id4 !~ m/($singlefam)_(.+)/) {
						next;
					}
				}
				# Use newfamid and newindiv hashes
				if (defined($newfamid{$id4})) {
					$famid4 = $newfamid{$id4};
					$indiv4 = $newindiv{$id4};
				} elsif (!defined($newfamid{$id4})) {
					#print "newfamid does not exist $id4\n";
					goto REGULAR2;
				}
			} elsif ($idsubfile !~ m/none/) {
				#print "there is an idsubfile\n";
				goto REGULAR2;
			
			} else {
				REGULAR2:
				for ($i = 0; $i <= $#idparts4; $i++) {
					if ($i == 0) {
						$idparts4 = $idparts4[$i];
						if (defined($substfam{$idparts4})) { 
							$id4 =~ s/$idparts4/$substfam{$idparts4}/g;
							$idparts4 = $substfam{$idparts4};
						}
					} elsif ($i >= 1) {
						$idparts4 .= "_" . $idparts4[$i];
					}
					if (defined($fam{$idparts4})) {
						$famid4 = $idparts4;
					} elsif (defined($origfam{$idparts4})) {
						$famid4 = $idparts4;
					} elsif (!defined($fam{$idparts4})) {
						last;
					}
				}
				if ($id4 =~ m/^$famid4\_(.+)/) {
					$indiv4 = $1;
				} elsif ($id4 =~ m/^$origfam{$famid4}\_(.+)/) {
					$indiv4 = $1;
				}
				if (defined($subsid{$famid4}{$indiv4})) {
					$indiv4 = $subsid{$famid4}{$indiv4};
				} elsif ( (defined($origfam{$famid4})) && (defined($subsid{$origfam{$famid4}}{$indiv4})) ) {
					$indiv4 = $subsid{$origfam{$famid4}}{$indiv4};
				}
			}
		} elsif ($phenoindiv =~ m/\s+/) {
			# FamilyID and IndividualID are in separate columns
			$famid4 = $info2[$pfamcol];
			$id4    = $info2[$pindcol];
			$id4 =~ s/\.|\-/\_/g;
			if ($id4 =~ m/^$famid4\_(.+)/) {
				$indiv4 = $1;
			} else {
				$indiv4 = $id4;
			}
			if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
				# Use newfamid and newindiv hashes
				if (defined($newfamid{"$famid4\_$indiv4"})) {
					$famid4 = $newfamid{"$famid4\_$indiv4"};
					$indiv4 = $newindiv{"$famid4\_$indiv4"};
				} elsif (!defined($newfamid{"$famid4\_$indiv4"})) {
					goto REGULAR2A;
				}
			} elsif ($idsubfile !~ m/none/) {
				goto REGULAR2A;
			
			} else {
				REGULAR2A:
				if (defined($substfam{$famid4})) { 
					$famid4 = $substfam{$famid4}; 
				}
				if (defined($subsid{$famid4}{$indiv4})) {
					$indiv4 = $subsid{$famid4}{$indiv4};
				} elsif ( (defined($origfam{$famid4})) && (defined($subsid{$origfam{$famid4}}{$indiv4})) ) {
					$indiv4 = $subsid{$origfam{$famid4}}{$indiv4};
				}
			}
		}
		if ( (defined($singlefam)) && ($famid4 ne $singlefam) && ($origfam{$famid4} ne $singlefam) ) {
			next;
		}
		#### If new ID exists, it is still using old ID at this point
		my $id4c = $id4;	# to allow putting it the phenotype hash
		
		if ( (defined($famid4)) && (defined($indiv4)) ) {
			$id4 = "$famid4\_$indiv4";
		}
		my $currpheno = $info2[$phenotped-1];
		foreach my $missing2 (@missing) {
			if ($currpheno =~ m/^$missing2$/i) {
				$currpheno = "NA";
				last;
			}
		}
		$phenotype{$id4} = $currpheno;
		if ($id4c ne $id4) {
			$phenotype{$id4c} = $currpheno;
			#print "phenotype{$id4c}\=$phenotype{$id4c}\n";
		}
	
		($pcol, $countphen) = 0;
		($fullpheno, $selpheno) = "";
		if ($pcolumn1 == $pcolumn2) {
			$pheno = $info2[$pcolumn1-1];
			foreach my $missing2 (@missing) {
				if ($pheno =~ m/^$missing2$/i) {
					$pheno = "NA";
					last;
				}
			}
			$fullpheno = $pheno;
		} elsif ($pcolumn1 != $pcolumn2) {
			$countphen = 0;
			for ($pcol=$pcolumn1; $pcol<=$pcolumn2; $pcol++) {
				$pheno = $info2[$pcol-1];
				foreach my $missing2 (@missing) {
					if ($pheno =~ m/^$missing2$/i) {
						$pheno = "NA";
						last;
					}
				}
				if ($countphen == 0) { 
					$fullpheno = $pheno;
				} elsif ($countphen >= 1) {
					$fullpheno .= " ".$pheno;
				}
				$countphen++;
			}
		}
		$countphen = 0;
		$allpheno{$id4} = $fullpheno;
		if ($id4c ne $id4) {
			$allpheno{$id4c} = $fullpheno;
			#print "allpheno{$id4c}\=$allpheno{$id4c}\n";
		}
		if (!defined($fidiid{$id4})) {
			# Phenotyped individual is not in the pedigree file
			if ( ! -e $pnip) {
				open (PNIP, ">$pnip") || die ("Could not create $pnip file!\n");
				print LOG "Individuals with phenotype(s) but are not in the pedigree file             : $pnip1\n";
			}
			if ($allpheno{$id4} ne "NA") {
				print PNIP "$id4\n";
			}
		}
	}
	close (IN2);
}

if (scalar(@exceed) >= 1) {
	print "\nThe number of characters for FamilyID_SubjectID of the following pedigree(s)\n";
	print "   exceeds the maximum of 15 characters implemented by MORGAN.\n";
	print "   Limit the total number of characters to 14 (an underscore will be inserted)\n";
	print "   by making the Family ID shorter so that gl_auto with not complain\n";
	print "   Create the file described in line 30 of transpose_fileset_parameter_file\n";
	print "   for your substitute Family IDs then rerun transpose_fileset.pl\n";
	print join ("\n", @exceed);
	print "\n\n";
	exit;
}
close (PNIP);

$count = 0;
my ($famid4, $indiv4) = "";
open (IN4, "<$genofile") || die ("Could not open $genofile file!\n");		# genotype file (famid.indiv, genotypes)
while (defined ($line4 = <IN4>)) {
	chomp $line4;
	$line4 =~ s/^\s+//g;
	$line4 =~ s/\s+$//g;
	$line4 =~ s/-0-/NA/g;
	next if ( ($line4 =~ m/^\#/) || (length($line4) == 0) );
	$count++;
	next if ( ($genoh =~ m/T/) && ($count == 1) );
	# use value of $genocol for splitting
	my @info4 = split(/\t|\s+/, $line4, $genocol);
	if ($genoindiv !~ m/\s+/) {
		# ID contains both FamilyID and IndividualID
		$id4 = $info4[$gidcol];
		$id4 =~ s/\.|\-/\_/g;
		my @idparts4 = split (/\_/, $id4);
		my $i = 0;
		my $idparts4 = "";
		($famid4, $indiv4) = "";

		if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
			# Use newfamid and newindiv hashes
			if (defined($newfamid{$id4})) {
				$famid4 = $newfamid{$id4};
				$indiv4 = $newindiv{$id4};
			} elsif (!defined($newfamid{$id4})) {
				goto REGULAR3;
			}
		} elsif ($idsubfile !~ m/none/) {
			#print "E2\n";
			goto REGULAR3;
		} else {
			REGULAR3:
			for ($i = 0; $i <= $#idparts4; $i++) {
				if ($i == 0) {
					$idparts4 = $idparts4[$i];
					if (defined($substfam{$idparts4})) {
						$id4 =~ s/$idparts4/$substfam{$idparts4}/g;
						$idparts4 = $substfam{$idparts4};
					}
				} elsif ($i >= 1) {
					$idparts4 .= "_" . $idparts4[$i];
				}
				if (defined($fam{$idparts4})) {
					$famid4 = $idparts4;
					last;
				} elsif (defined($origfam{$idparts4})) {
					$famid4 = $idparts4;
				} elsif (!defined($fam{$idparts4})) {
					last;
				}
			}
			if ($id4 =~ m/^$famid4\_(.+)/) {
				$indiv4 = $1;
			} elsif ( (defined($origfam{$famid4})) && ($id4 =~ m/^$origfam{$famid4}\_(.+)/) ) {
				$indiv4 = $1;
			} elsif ($id4 =~ m/^(.+)_(.+)/) {
				$famid4 = $1;
				$indiv4 = $2;
				print "Family ID $famid4 is not in the pedigree file\n";
			}
			if (defined($subsid{$famid4}{$indiv4})) {
				$indiv4 = $subsid{$famid4}{$indiv4};
			} elsif ( (defined($origfam{$famid4})) && (defined($subsid{$origfam{$famid4}}{$indiv4})) ) {
				$indiv4 = $subsid{$origfam{$famid4}}{$indiv4};
			}
		}

		#print "A2 $famid4 $indiv4\n";
	} elsif ($genoindiv =~ m/\s+/) {
		# FamilyID and IndividualID are in separate columns
		($famid4, $indiv4) = "";
		$famid4 = $info4[$gfamcol];
		$id4    = $info4[$gindcol];
		$id4 =~ s/\.|\-/\_/g;
		if ($id4 =~ m/^$famid4\_(.+)/) {
			$indiv4 = $1;
		} else {
			$indiv4 = $id4;
		}
		
		if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
			# Use newfamid and newindiv hashes
			if (defined($newfamid{"$famid4\_$indiv4"})) {
				$famid4 = $newfamid{"$famid4\_$indiv4"};
				$indiv4 = $newindiv{"$famid4\_$indiv4"};
			} elsif (!defined($newfamid{"$famid4\_$indiv4"})) {
				goto REGULAR4;
			}
		} elsif ($idsubfile !~ m/none/) {
			goto REGULAR4;
		
		} else {
			REGULAR4:
			if (defined($substfam{$famid4})) { 
				$famid4 = $substfam{$famid4}; 
			}
			if (defined($subsid{$famid4}{$indiv4})) {
				$indiv4 = $subsid{$famid4}{$indiv4};
			} elsif ( (defined($origfam{$famid4})) && (defined($subsid{$origfam{$famid4}}{$indiv4})) ) {
				$indiv4 = $subsid{$origfam{$famid4}}{$indiv4};
			}
		}
	}
	if ( (defined($singlefam)) && ($famid4 ne $singlefam) && ($famid4 ne $substfam{$singlefam}) ) {
		next;
	}

	# genotype data starts are $genocol-1 up to end of @info4
	$geno = $info4[$genocol - 1];
	$geno =~ s/\t/ /g;
	my $id4b = "";
	$id4b = "$famid4\_$indiv4";
	
	foreach my $geno4 (@missing) {
		if ($geno =~ m/$geno4 $geno4/) {
			if ( ($geno !~ m/(\d+)|(1 1)|(1 2)|(2 2)/) && ($geno !~ m/A|C|G|T|I|D|N/) ) {
				$geno = "";
				last;
			}
		}
	}
	if ( ($geno =~ m/0|-|NA/) && ($geno !~ m/A|C|T|G|I|D|N|1|2/) ) {
		$geno = "";
	}
	
	$genotype{$id4b} = $geno;
	if (!defined($fidiid{$id4b})) {
		# Genotyped individual is not in the pedigree file
		if ( ! -e $gnip) {
			open (GNIP, ">$gnip") || die ("Could not create $gnip file!\n");
			print LOG "Individuals with genotypes but are not in the pedigree file                : $gnip1\n";
		}
		print GNIP "$id4b\n";
	}
}
close (IN1);
close (IN4);
close (GNIP);

# Get number of marker alleles based on $geno
my @nummrkr = split(/\t|\s+/, $geno);
my $nummrkr = scalar(@nummrkr);

if (-e $tind) {
	system ("rm $tind");
}

# Create normal fileset pedigree file and transposed fileset pedigree and subject files
open (TPEDO, ">$tpedo") || die ("Could not create $tpedo file!\n");
if ($phenofile !~ m/^none/) {
	open (TPHEN, ">$tphen") || die ("Could not create $tphen file!\n");
}
open (TSUB, ">$tind") || die ("Could not create $tind file!\n");

$count = 0;
open (IN1, "<$pedfile") || die ("Could not open $pedfile file!\n");			# pedigree file (original set of individuals)
@list1 = <IN1>;
close (IN1);
my ($famid1, $indiv1) = "";
if ($pedh =~ m/T/i) {
	shift @list1;
}
@listsort1 = sort @list1;
foreach $line1 (@listsort1) {
	chomp $line1;
	next if ($line1 eq "");
	$line1 =~ s/^\s+//g;
	$line1 =~ s/\s+$//g;
	next if ( ($line1 =~ m/^\#/) || (length($line1) == 0) );
	$count++;
	@info1 = split(/\t|\s+/, $line1);
	$size = scalar(@info1);
	if ($size == 4) {
		# get FamilyID from the Individual IDs
		my $id1a   = $info1[0];
		my $id1b   = $info1[1];
		my $id1d   = $info1[2];
		$id1a =~ s/\.|\-/\_/g;
		$id1b =~ s/\.|\-/\_/g;
		$id1d =~ s/\.|\-/\_/g;
		# Use IndividualID and FatherID
		if ( ($id1a =~ m/\_/) && ($id1b =~ m/\_/) ) {
			my @idparts1 = split (/\_/, $id1a);
			my @idparts2 = split (/\_/, $id1b);
			my $size1a = scalar(@idparts1);
			my $size1b = scalar(@idparts2);
			my $size1 = 0;
			if ($size1a <= $size1b) {
				$size1 = $size1a;
			} elsif ($size1b < $size1a) {
				$size1 = $size1b;
			}
			my $i = 0;
			$famid = "";
			for ($i = 0; $i < $size1; $i++) {
				if ($idparts1[$i] eq $idparts2[$i]) {
					$famid .= $idparts1[$i];
				} elsif ($idparts1[$i] ne $idparts2[$i]) {
					last;
				}
			}
			if ($id1a =~ m/^$famid\_(.+)/) {
				$indiv = $1;
			}
		} elsif ( ($id1a =~ m/\_/) && ($id1b !~ m/\_/) ) {
			# use $id1a
			($famid, $indiv) =  split(/\_([^\_]+)$/, $id1a);
		} elsif ( ($id1a !~ m/\_/) && ($id1b !~ m/\_/) ) {
			# can't determine family ID
			print "Check your pedigree file. PBAP cannot determine family ID of $id1a and $id1b\n";
			exit;
		}
		
		if ($id1b =~ m/^$famid\_(.+)/) { 
			$pat = $1;
		} else {
			$pat = $id1b;
		}
		if ($id1d =~ m/^$famid\_(.+)/) { 
			$mat = $1;
		} else {
			$mat = $id1d;
		}
		$sex   = $info1[3];
	} elsif ($size >= 5) {
		$famid = $info1[0];
		$id1   = $info1[1];
		my $id1b = $info1[2];
		my $id1d = $info1[3];
		$id1 =~ s/\.|\-/\_/g;
		if ($id1 =~ m/^$famid\_(.+)/) {
			$indiv = $1;
		} else {
			$indiv = $id1;
		}
		if ($id1b =~ m/^$famid\_(.+)/) { 
			$pat = $1;
		} else {
			$pat = $id1b;
		}
		if ($id1d =~ m/^$famid\_(.+)/) { 
			$mat = $1;
		} else {
			$mat = $id1d;
		}
		$sex   = $info1[4];
	}
	if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
		# Use newfamid and newindiv hashes
		if (defined($newfamid{"$famid\_$indiv"})) {
			$famid1 = $newfamid{"$famid\_$indiv"};
			$indiv1 = $newindiv{"$famid\_$indiv"};
			if ($pat !~ m/^0$/) {
				$pat = $newid{"$famid\_$pat"};
			}
			if ($mat !~ m/^0$/) {
				$mat = $newid{"$famid\_$mat"};
			}
		} elsif (!defined($newfamid{"$famid\_$indiv"})) {
			goto REGULAR5;
		}
	} elsif ($idsubfile !~ m/none/) {
		goto REGULAR5;
	
	} else {
		REGULAR5:
		if (defined($substfam{$famid})) { 
			$famid1 = $substfam{$famid}; 
			$indiv1 = $indiv;
		} elsif (!defined($substfam{$famid})) { 
			$famid1 = $famid;
			$indiv1 = $indiv;
		}
		if (defined($subsid{$famid1}{$indiv1})) {
			$indiv1 = $subsid{$famid1}{$indiv1};
		} elsif ( (defined($origfam{$famid1})) && (defined($subsid{$origfam{$famid1}}{$indiv1})) ) {
			$indiv1 = $subsid{$origfam{$famid1}}{$indiv1};
		}
	}
	if ( (defined($singlefam)) && (defined($substfam{$singlefam})) && ($famid ne $singlefam) && ($famid ne $substfam{$singlefam}) ) {
		next;
	}
	my $id1c = "$famid1\_$indiv1";
	$selpheno = $phenotype{$id1c};
	$fullpheno = $allpheno{$id1c};
	if ( (!defined($fullpheno)) && (defined($numpheno)) && ($numpheno > 1) ) {
		#put several NAs
		my $p = 0;
		my @p = ();
		for ($p = 1; $p <= $numpheno; $p++) {
			push (@p, "NA")
		}
		$fullpheno = join (" ", @p);
		if (!defined($allpheno{$id1c})) {
			# since it is not defined, let us replace it with NAs
			$allpheno{$id1c} = $fullpheno;
		}
	}
	
	foreach my $missing2 (@missing) {
		if ($pat =~ m/^$missing2$/i) {
			$pat = "0";
		}
		if ($mat =~ m/^$missing2$/i) {
			$mat = "0";
		}
		if ( ($pat eq "0") && ($mat eq "0") ) {
			last;
		}
	}
	if ( (defined($pat)) && (defined($substfam{$famid})) && (defined($subsid{$famid}{$pat})) ) {
			$pat = $subsid{$famid}{$pat};
			$famid1 = $substfam{$famid};
	}
	if ( (defined($mat)) && (defined($substfam{$famid})) && (defined($subsid{$famid}{$mat})) ) {
			$mat = $subsid{$famid}{$mat};
			$famid1 = $substfam{$famid};
	}
	
	
	if ( ($pat !~ m/^0$/) && ($pat !~ m/^$famid1\[\-|\_|\.]/) ) { $pat = $famid1."_".$pat; }
	if ( ($mat !~ m/^0$/) && ($mat !~ m/^$famid1\[\-|\_|\.]/) ) { $mat = $famid1."_".$mat; }


	if ($sex =~ m/M/i) { $sex = 1; }
	elsif ($sex =~ m/F/i) { $sex = 2; }
	
	if (!defined($famid1)) { $famid = ""; }
	if (!defined($indiv)) { $indiv = ""; }
	if (!defined($pat)) { $pat = ""; }
	if (!defined($mat)) { $mat = ""; }
	if (!defined($selpheno)) { $selpheno = ""; }
	if (!defined($fullpheno)) { $fullpheno = "NA"; }
	if (!defined($genotype{$id1c})) {
		$genotype{$id1c} = "";
	}
	my $genotype2 = $genotype{$id1c};
	
			
	print TPEDO "$famid1$,$id1c$,$pat$,$mat$,$sex\n";

	if ($phenofile !~ m/^none/) {
		print TPHEN "$id1c$,$fullpheno\n";
	}
	if (length($genotype2) == 0) {
		if (! -e $tnogen) {
			open (TNOGEN, ">$tnogen") || die ("Could not create $tnogen file!\n");
			print LOG "Individuals without genotypes                                              : $tnogen1\n";
		}
		if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
			print TNOGEN "$famid\_$indiv$,$id1c\n";
		} elsif ($idsubfile !~ m/none/) {
			if (defined($origfam{$famid1})) {
				if (defined($oldid{$famid1}{$indiv1})) {
					print TNOGEN "$origfam{$famid1}\_$oldid{$famid1}{$indiv1}$,$id1c\n";
				} elsif (!defined($oldid{$famid1}{$indiv1})) {
					print "A Check your ID translation file: $id1c is missing\n\n";
					exit;
				}
			} elsif (!defined($origfam{$famid1})) {
				print TNOGEN "$famid1\_$indiv1\n";
			}
			next;
		} else {
			if (defined($origfam{$famid1})) {
				if (defined($oldid{$famid1}{$indiv1})) {
					print TNOGEN "$origfam{$famid1}\_$oldid{$famid1}{$indiv1}$,$id1c\n";
				} elsif (!defined($oldid{$famid1}{$indiv1})) {
					print "B Check your ID translation file: $id1c is missing\n\n";
					exit;
				}
			} elsif (!defined($origfam{$famid1})) {
				print TNOGEN "$famid1\_$indiv1\n";
			}
			next;
		}
	}

	# Print only the individuals that have been genotyped
	if ( (defined($genotype2)) && ($genotype2 ne "") ) {
		if ( ($genotype2 =~ m/0|-|(NA)/) && ($genotype2 !~ m/1|2|A|C|G|T|I|D|N/i) ) {
			# do not print
			$genotype{$id1c} = "";
		} else {
			if ( ($substfile !~ m/none/) && ($renumber =~ m/Y/i) ) {
				print TSUB "$id1c\n";
				print OUT1 "$famid1$,$id1c$,$pat$,$mat$,$sex$,$selpheno$,$genotype2\n";
			} elsif ($idsubfile !~ m/none/) {
				print TSUB "$famid1\_$indiv1\n";
				print OUT1 "$famid1$,$id1c$,$pat$,$mat$,$sex$,$selpheno$,$genotype2\n";
			} else {
				print TSUB "$famid1\_$indiv1\n";
				print OUT1 "$famid1$,$id1c$,$pat$,$mat$,$sex$,$selpheno$,$genotype2\n";
			}
		}
	}
	($famid1, $id1c, $pat, $mat, $sex) = "";
}
close (IN1);
close (OUT1);
close (TNOGEN);
close (TSUB);
close (TPEDO);
close (TPHEN);

### Use of phenotype conversion file
my ($vartype, $values, $id6, $phenotypes) = "";
my ($colnum, $affstatus) = 0;
my (%vartype, %values, %vtype, %pheno) = ();
if ( -e $mped ) {
	`rm -f $mped`;
}
if ( ($phenoconv !~ m/none/i) && ($phenofile !~ m/none/) ) {
	open (MPED, ">$mped") || die ("Could not create $mped file!\n");
	open (IN7, "<$phenoconv") || die ("Could not open $phenoconv file!\n");
	while (defined ($line7 = <IN7>)) {
		chomp $line7;
		$line7 =~ s/^\s+//g;
		$line7 =~ s/\s+$//g;
		next if ( ($line7 =~ m/^\#/) || (length($line7) == 0) );
		($colnum, $vartype, $affstatus, $values) = split (/\s+/, $line7);
		$vartype{$colnum} = $vartype;
		$values{$colnum}{$affstatus} = $values;
		if ($values =~ m/\,/) {
			$vtype{$colnum}{$affstatus} = "series";
		} elsif ($values =~ m/\-/) {
			$vtype{$colnum}{$affstatus} = "range";
		} else {
			$vtype{$colnum}{$affstatus} = "single";
		}
	}
	close (IN7);
	
	if ( ! -e $tphen ) {
		print "TPHEN file not created. Please check your input files and parameter file\n";
		exit;
	} elsif ( -e $tphen ) {
		print "Opening TPHEN file ($tphen)\n";
		open (IN8, "<$tphen") || die ("Could not open $tphen file!\n");
		while (defined ($line8 = <IN8>)) {
			chomp $line8;
			$line8 =~ s/^\s+//g;
			$line8 =~ s/\s+$//g;
			next if ( ($line8 =~ m/^\#/) || (length($line8) == 0) );
			($id6, $phenotypes) = split (/\s+/, $line8, 2);
			my (@phenotypes, @values2) = ();
			my $colnum2 = 2;
			my $aff = 0;
			my $values2 = "";
			@phenotypes = split(/\s+/, $phenotypes);
			foreach my $pheno2 (@phenotypes) {
				for ($aff = 0; $aff <=2; $aff++) {
					if ( (defined($vtype{$colnum2}{$aff})) && ($vtype{$colnum2}{$aff} eq "series") ) {
						@values2 = split(/\,/, $values{$colnum2}{$aff});
						foreach my $values3 (@values2) {
							if ($pheno2 eq $values3) {
								$pheno{$id6}{$colnum2} = $aff;
								goto NEXTPHENO;
							}
						}
					} elsif ( (defined($vtype{$colnum2}{$aff})) && ($vtype{$colnum2}{$aff} eq "range") ) {
						my ($min, $max) = split(/\-/, $values{$colnum2}{$aff});
						if ($vartype{$colnum2} =~ m/(continuous)|(integer)/) {
							if ( ($pheno2 >= $min) && ($pheno2 <= $max) ) {
								$pheno{$id6}{$colnum2} = $aff;
								goto NEXTPHENO;
							}
						} elsif ($vartype{$colnum2} =~ m/string/) {
							# Useful for single alpha characters only (A-Z)
							my $minmax = "[" . $min . "-" . $max . "]";
							if ($pheno2 =~ m/$minmax/) {
								$pheno{$id6}{$colnum2} = $aff;
								goto NEXTPHENO;
							}
						}
					} elsif ( (defined($vtype{$colnum2}{$aff})) && ($vtype{$colnum2}{$aff} eq "single") ) {
						if ($pheno2 eq $values{$colnum2}{$aff}) {
							$pheno{$id6}{$colnum2} = $aff;
							goto NEXTPHENO;
						}
					} elsif (!defined($vtype{$colnum2}{$aff})) {
						# Keep as is
						$pheno{$id6}{$colnum2} = $pheno2;
						goto NEXTPHENO;
					}
				}
				NEXTPHENO:
				$colnum2++;
			}
		}
	}
	my ($famsize, $reals, $x, $y) = 0;
	($famsize, $reals) = 0;
	my $integs = 1;	# for affectation status
	my $temp9 = "";
	my @y = ();
	my %skip_y = ();
	print "Number of phenotypes: $numpheno pcolumn1\=$pcolumn1 pcolumn2\=$pcolumn2\n";
	# Count the integers and reals
	for ($y = $pcolumn1; $y <= $pcolumn2; $y++) {
		print "column\=$y vartype\=$vartype{$y}\n";
		if ($vartype{$y} =~ m/continuous/) {
			$reals++;
			push (@y, $y);
			$skip_y{$y}++;
		} else {
			$integs++;
		}
	}
	if ($reals >= 1) {
		print "\nRearranged columns in the output phenotype file to follow MORGAN-format (names, integers, reals)!!!\n";
		print "New order is as follows: ";
		print "Individual_ID";
		for ($y = $pcolumn1; $y <= $pcolumn2; $y++) {
			if (defined($skip_y{$y})) {
				next;
			} elsif (!defined($skip_y{$y})) {
				print "$,$phenoh{$y}";
			}
		}
		foreach my $y1 (@y) {
			print "$,$phenoh{$y1}";
		}
		print "\n";
	}
	# Now let us create the MORGAN-format pedigree file that would be ready for gl_auto and gl_lods
	my @morganped = ();
	if ( ! -e $tpedo ) {
		print "TPEDO file not created. Please check your input files and parameter file\n";
		exit;
	} elsif ( -e $tpedo ) {
		print "\nOpening TPEDO file ($tpedo)\n";
		open (IN9, "<$tpedo") || die ("Could not open $tpedo file!\n");
		while (defined ($line9 = <IN9>)) {
			chomp $line9;
			$line9 =~ s/^\s+//g;
			$line9 =~ s/\s+$//g;
			next if ( ($line9 =~ m/^\#/) || (length($line9) == 0) );
			my ($famid9, $id9, $dadid9, $momid9, $sex9) = split (/\s+/, $line9);
			$temp9 = "$id9$,$dadid9$,$momid9$,$sex9";
			for ($x = $pcolumn1; $x <= $pcolumn2; $x++) {
				#print "$,$pheno{$id9}{$x}";
				if (defined($skip_y{$x})) {
					next;
				} elsif (!defined($skip_y{$x})) {
					$temp9 .= "$,$pheno{$id9}{$x}";
				}
			}
			foreach my $y1 (@y) {
				$temp9 .= "$,$pheno{$id9}{$y1}";
			}
			#print "\n";
			push (@morganped, $temp9);
			$temp9 = "";
			$famsize++;
		}
	}
	print MPED "input pedigree size $famsize\n";
	if ($reals == 0) {
		print MPED "input pedigree record names 3 integers $integs\n";
	} elsif ($reals >= 1) {
		print MPED "input pedigree record names 3 integers $integs reals $reals\n";
	}
	print MPED "input pedigree record father mother\n";
	print MPED "******\n";
	print MPED join ("\n", @morganped);
	print MPED "\n";
	close (MPED);
} elsif ( ($phenoconv =~ m/none/i) && ($phenofile !~ m/none/) ) {
	open (MPED, ">$mped") || die ("Could not create $mped file!\n");
	# Let us open TPHEN file
	my %tphen = ();
	my ($famsize, $reals, $x, $y, $integs) = 0;
	my ($pcf, $temp9) = "";
	# Parse phenoconv line
	($famsize, $integs, $reals) = 0;
	my @phenoconv = ();
	@phenoconv = split(/\s+/, $phenoconv);
	if ($#phenoconv < 2) {
		print "Edit line 12 of your parameter file and change it to the format\n";
		print "\"none number_of_integer_phenotypes number_of_real_phenotypes\"\n";
		exit;
	} elsif ($#phenoconv == 2) {
		($pcf, $integs, $reals) = split(/\s+/, $phenoconv);
		$integs++; # for affectation status
	}
	if ( ! -e $tphen ) {
		print "TPHEN file not created. Please check your input files and parameter file\n";
		exit;
	} elsif ( -e $tphen ) {
		print "Opening TPHEN file ($tphen)\n";
		open (IN8, "<$tphen") || die ("Could not open $tphen file!\n");
		while (defined ($line8 = <IN8>)) {
			chomp $line8;
			$line8 =~ s/^\s+//g;
			$line8 =~ s/\s+$//g;
			next if ( ($line8 =~ m/^\#/) || (length($line8) == 0) );
			($id6, $phenotypes) = "";
			($id6, $phenotypes) = split (/\s+/, $line8, 2);
			$phenotypes =~ s/NA/0/g;
			$tphen{$id6} = $phenotypes;
		}
	}
	# Now let us create the MORGAN-format pedigree file that would be ready for gl_auto and gl_lods
	my @morganped = ();
	if ( ! -e $tpedo ) {
		print "TPEDO file not created. Please check your input files and parameter file\n";
		exit;
	} elsif ( -e $tpedo ) {
		print "\nOpening TPEDO file ($tpedo)\n";
		open (IN9, "<$tpedo") || die ("Could not open $tpedo file!\n");
		while (defined ($line9 = <IN9>)) {
			chomp $line9;
			$line9 =~ s/^\s+//g;
			$line9 =~ s/\s+$//g;
			next if ( ($line9 =~ m/^\#/) || (length($line9) == 0) );
			my ($famid9, $id9, $dadid9, $momid9, $sex9) = split (/\s+/, $line9);
			#print "$famid9$,$id9$,$dadid9$,$momid9$,$sex9\n";
			#print "$id9$,$dadid9$,$momid9$,$sex9";
			$temp9 = "$id9$,$dadid9$,$momid9$,$sex9$,$tphen{$id9}";
			push (@morganped, $temp9);
			$temp9 = "";
			$famsize++;
		}
	}
	print MPED "input pedigree size $famsize\n";
	if ($reals == 0) {
		print MPED "input pedigree record names 3 integers $integs\n";
	} elsif ($reals >= 1) {
		print MPED "input pedigree record names 3 integers $integs reals $reals\n";
	}
	print MPED "input pedigree record father mother\n";
	print MPED "******\n";
	print MPED join ("\n", @morganped);
	print MPED "\n";
	close (MPED);
}
###


# Create normal fileset map file
open (IN3, "<$mapfile") || die ("Could not open $mapfile!\n");				# map file
$chr -= 1;
$marker -= 1;
$genloc -= 1;
$phypos -= 1;
$count = 0;
my $j = 0;
while (defined ($line3 = <IN3>)) {
	chomp $line3;
	$line3 =~ s/^\s+//g;
	$line3 =~ s/\s+$//g;
	@info3 = split (/ +\t| +|\t\ +|\t/, $line3);	# handles spaces-tab, spaces, tab-spaces, and then tab delimiters (Hiep Nguyen)
	next if ( ($line3 =~ m/^\#/) || (length($line3) == 0) );
	$count++;
	next if ( ($maph =~ m/T/) && ($count == 1) );
	if ( ($info3[$chr] == $chrom) || ($info3[$chr] eq $chrom) ) {
		if (!defined($info3[$genloc])) { $info3[$genloc] = "NA"; }
		if (!defined($info3[$phypos])) { $info3[$phypos] = "NA"; }
		for ($j = 1; $j <= $#missing; $j++) {	# skipped "0" as missing
			if ($info3[$genloc] =~ m/^$missing[$j]$/i) {
				$info3[$genloc] = "NA";
			}
			if ($info3[$phypos] =~ m/^$missing[$j]$/i) {
				$info3[$phypos] = "NA";
			}
		}
		if ($info3[$genloc] ne "NA") {
			$info3[$genloc] = sprintf("%.6f", $info3[$genloc]);
		}
		print OUT2 "$info3[$chr]$,$info3[$marker]$,$info3[$genloc]$,$info3[$phypos]\n";
	}
}
close (IN3);
close (OUT2);

# Create transposed fileset
chdir($outdir);
print "Transposing the normal fileset now\n";
transposefile($pedout, $mapout, $includeg, $includep, $prevail);

if ($delnorm =~ m/Y|Yes/i) {
	system ("rm $pedout");
	system ("rm $mapout");
}
if ($delplinkt =~ m/Y|Yes/i) {
	system ("rm $tfamout");
	system ("rm $tpedout");
}

##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);

# Print general information regarding files (counts)
my ($indiv_ped, $mrkr_map, $indiv_geno, $mrkr_geno, $indiv_pheno) = 0;
my ($indiv_tpedo, $mrkr_tmap, $indiv_tgen, $mrkr_tgen, $indiv_tphen) = 0;
$indiv_ped  = `wc -l $pedfile | cut -d " " -f 1`;
$mrkr_map   = `wc -l $mapfile | cut -d " " -f 1`;
$indiv_geno = `wc -l $genofile | cut -d " " -f 1`;
$mrkr_geno = `awk '{FS=" "}{if (NR==1) print NF }' $genofile`;
$indiv_tpedo  = `wc -l $tpedo | cut -d " " -f 1`;
$mrkr_tmap   = `wc -l $tmap | cut -d " " -f 1`;
$indiv_tgen  = `awk '{FS=" "}{if (NR==1) print NF }' $tgen`;
$mrkr_tgen  = `wc -l $tgen | cut -d " " -f 1`;
if ( (defined($phenofile)) && ($phenofile !~ m/none/) && ( -e $phenofile) ) {
	$indiv_pheno  = `wc -l $phenofile | cut -d " " -f 1`;
	if ($phenoh =~ m/T/i) {
		$indiv_pheno -= 1;
	}
}
if ( (defined($tphen)) && ($tphen !~ m/none/) && ( -e $tphen) ) {
	$indiv_tphen  = `wc -l $tphen | cut -d " " -f 1`;
	chomp $indiv_tphen;
}

if ($pedh =~ m/T/i) {
	$indiv_ped -= 1;
}
if ($maph =~ m/T/i) {
	$mrkr_map -= 1;
}
if ($genoh =~ m/T/i) {
	$indiv_geno -= 1;
}
chomp $indiv_ped;
chomp $mrkr_map;
chomp $indiv_geno;
chomp $indiv_tpedo;
chomp $mrkr_tmap;
chomp $mrkr_tgen;
$mrkr_geno = ($mrkr_geno - $genocol + 1) / 2;
$indiv_tgen = ($indiv_tgen - 2) / 2;


print "\n";
print "Individuals in input pedigree file ($pedfile): $indiv_ped\n";
print "Markers in input map file ($mapfile): $mrkr_map\n";
if ( (defined($phenofile)) && ($phenofile !~ m/none/) && ( -e $phenofile) ) {
	print "Individuals in input phenotype file ($phenofile): $indiv_pheno\n";
}
print "Individuals in input genotype file ($genofile): $indiv_geno\n";
print "Markers in input genotype file ($genofile): $mrkr_geno\n\n";

print "Individuals in output pedigree file ($tpedo): $indiv_tpedo\n";
print "Markers in output map file ($tmap): $mrkr_tmap\n";
if ( (defined($tphen)) && ($tphen !~ m/none/) && ( -e $tphen) ) {
	print "Individuals in output phenotype file ($tphen): $indiv_tphen\n";
}
print "Individuals in output genotype file ($tgen): $indiv_tgen\n";
print "Markers in output genotype file ($tgen): $mrkr_tgen\n\n";

print LOG"\n";
print LOG "Individuals in input pedigree file ($pedfile): $indiv_ped\n";
print LOG "Markers in input map file ($mapfile): $mrkr_map\n";
if ( (defined($phenofile)) && ($phenofile !~ m/none/) && ( -e $phenofile) ) {
	print LOG "Individuals in input phenotype file ($phenofile): $indiv_pheno\n";
}
print LOG "Individuals in input genotype file ($genofile): $indiv_geno\n";
print LOG "Markers in input genotype file ($genofile): $mrkr_geno\n\n";

print LOG "Individuals in output pedigree file ($tpedo): $indiv_tpedo\n";
print LOG "Markers in output map file ($tmap): $mrkr_tmap\n";
if ( (defined($tphen)) && ($tphen !~ m/none/) && ( -e $tphen) ) {
	print LOG "Individuals in output phenotype file ($tphen): $indiv_tphen\n";
}
print LOG "Individuals in output genotype file ($tgen): $indiv_tgen\n";
print LOG "Markers in output genotype file ($tgen): $mrkr_tgen\n";

if ( (defined($singlefam)) && (defined($substfam{$singlefam})) && ($substfam{$singlefam} ne $singlefam) ) {
	my $outdir_oldID = $outdir_old . "/ped" . $singlefam;
	my $outdir_newID = $outdir_old . "/ped" . $substfam{$singlefam};
	print "Output directory above will be renamed as $outdir_newID\n";
}

print "\nTotal real time   : " . parsetime ($real);
print   "Total user time   : " . parsetime ($user);
print   "Total system time : " . parsetime ($system);
print LOG "\nTotal real time   : " . parsetime ($real);
print LOG   "Total user time   : " . parsetime ($user);
print LOG   "Total system time : " . parsetime ($system);
print "\nDone\n\n";
close (LOG);

if ( (defined($singlefam)) && (defined($substfam{$singlefam})) && ($substfam{$singlefam} ne $singlefam) ) {
	# Move all files to a new directory
	my $outdir_oldID = $outdir_old . "/ped" . $singlefam;
	my $outdir_newID = $outdir_old . "/ped" . $substfam{$singlefam};
	if ( -e $outdir_newID) {
		`rm -r $outdir_newID`;
	}
	`mv $outdir_oldID $outdir_newID`;
	chdir("$outdir_newID");
	chdir("$chrom");
	`sed -i \'s/ped$singlefam\/ped$substfam{$singlefam}\/g\' $outdir_newID\/chr$chrom\/transpose_fileset_chr$chrom\.log`;
}

##### SUBROUTINES #####

sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}

sub transposefile {
	$outdir = $outdir;
	chdir($outdir);
	$pedout     = $_[0];
	$mapout     = $_[1];
	$includeg   = $_[2];
	$includep   = $_[3];
	$prevail    = $_[4];
	my $count2 = 0;
	%substfam = %substfam;

	$tfamout = $outdir."/chr" . $chrom.".tfam";
	$tpedout = $outdir."/chr" . $chrom.".tped";
	$nofout  = $auxdir."/chr" . $chrom.".nof";
	
	if (-e $nofout) {
		system ("rm $nofout");
	}
	
	$tgen   = $outdir."/chr" . $chrom.".tgen";
	$tmap   = $outdir."/chr" . $chrom.".tmap";
	
	# Convert ped to tfam
	system ("cut -f -6 -d \" \" $pedout >$tfamout");
	
	# Create hash
	(@list5, @list6, @info5, @info6) = ();
	my ($famid5, $id5, $pat5, $mat5, $sex5, $pheno5, $geno5) = "";
	my ($idgen, %markgen) = ();
	my @geno5 = ();
	my ($chr6, $marker6, $genloc6, $phypos6) = "";
	open (IN5, "<$tfamout") || die ("Could not open $tfamout file!\n");
	while (defined ($line5 = <IN5>)) {
		chomp $line5;
		$line5 =~ s/^\s+//g;
		$line5 =~ s/\s+$//g;
		$count2 = 0;
		($famid5, $id5, $pat5, $mat5, $sex5, $pheno5) = split(" ", $line5);
		
		if (defined($substfam{$famid5})) { $famid5 = $substfam{$famid5}; }
		my ($famid5a, $indiv5a) = split(/\.|\-|\_/, $id5);
		if (defined($substfam{$famid5a})) { $famid5a = $substfam{$famid5a}; }
		$id5 = "$famid5a\_$indiv5a";
		$geno5 = $genotype{$id5};
		@geno5 = split (/\t|\s+/, $geno5);

		my ($a1, $a2) = 0;
		my ($geno5a, $geno5b, $markergeno) = "";
		open (IN6, "<$mapout") || die ("Could not open $mapout file!\n");
		while (defined ($line6 = <IN6>)) {
			chomp $line6;
			$line6 =~ s/^\s+//g;
			$line6 =~ s/\s+$//g;
			next if (length($line6) == 0);
			($chr6, $marker6, $genloc6, $phypos6) = split(" ", $line6);
			$a1 = ($count2*2);
			$a2 = ($count2*2) + 1;
			#print "a1\=$a1 a2\=$a2\n";
			$geno5a = $geno5[$a1];
			$geno5b = $geno5[$a2];
			$markergeno = $geno5a." ".$geno5b;
			$markgen{$id5}{$marker6} = $markergeno;
			$count2++;
		}
		close (IN6);
		($a1, $a2, $count2) = 0;
	}
	close (IN5);
	
	# Convert map-ped to tped, tgeno, and tind
	open (TPED, ">$tpedout") || die ("Could not create $tpedout file!\n");
	open (TGEN, ">$tgen") || die ("Could not create $tgen file!\n");
	open (TMAP, ">$tmap") || die ("Could not create $tmap file!\n");

	open (TFAM, "<$tfamout") || die ("Could not open $tfamout file!\n");
	my @tfam = <TFAM>;
	close (TFAM);
	my ($famid7, $id7, $pat7, $mat7, $sex7, $pheno7, $tfam) = "";
	open (IN6, "<$mapout") || die ("Could not open $mapout file!\n");
	while (defined ($line6 = <IN6>)) {
		chomp $line6;
		$line6 =~ s/^\s+//g;
		$line6 =~ s/\s+$//g;
		next if (length($line6) == 0);
		($chr6, $marker6, $genloc6, $phypos6) = split(" ", $line6);
		
		# Exclude markers based on options and priority selected by user
		if ( ($includeg =~ m/exclude/i) && ($includep =~ m/exclude/i) ) {
			if ( (!defined($genloc6)) || (!defined($phypos6)) || ($genloc6 =~ m/-|NA/i) || ($phypos6 =~ m/-|NA/i) ) {
				if (! -e $nofout) {
					open (NOF, ">$nofout") || die ("Could not create $nofout file!\n");
					print LOG "Markers excluded (Chromosome, Marker, Genetic Location, Physical Position) : $nofout1\n";
				}
				print NOF "$line6\n";
				next;
			}
		} elsif ( ($includeg =~ m/exclude/i) && ($includep =~ m/include/i) ) {
			if ( ($prevail eq "genetic") && ( (!defined($genloc6)) || ($genloc6 =~ m/\-|NA/i) ) ) {
				if (! -e $nofout) {
					open (NOF, ">$nofout") || die ("Could not create $nofout file!\n");
					print LOG "Markers excluded (Chromosome, Marker, Genetic Location, Physical Position) : $nofout1\n";
				} elsif (-e $nofout) {
					print NOF "$line6\n";
				}
				next;
			}
		} elsif ( ($includeg =~ m/include/i) && ($includep =~ m/exclude/i) ) {
			if ( ($prevail eq "physical") && ( (!defined($phypos6)) || ($phypos6 =~ m/\-|NA/i) ) ) {
				if (! -e $nofout) {
					open (NOF, ">$nofout") || die ("Could not create $nofout file!\n");
					print LOG "Markers excluded (Chromosome, Marker, Genetic Location, Physical Position) : $nofout1\n";
				} elsif (-e $nofout) {
					print NOF "$line6\n";
				}
				next;
			}
		} 
		print TPED "$line6";
		print TMAP "$line6\n";
		my ($chr7, $marker7, $rest7) = split (" ", $line6, 3);
		print TGEN "$chr7$,$marker7";
		foreach $tfam (@tfam) {
			chomp $tfam;
			($famid7, $id7, $pat7, $mat7, $sex7, $pheno7) = split(" ", $tfam);
			if (defined($substfam{$famid7})) { $famid7 = $substfam{$famid7}; }
			my ($famid7a, $indiv7a) = split(/\.|\-|\_/, $id7);
			if (defined($substfam{$famid7a})) { $famid7a = $substfam{$famid7a}; }
			$id7 = "$famid7a\_$indiv7a";
			
			print TPED "$,$markgen{$id7}{$marker6}";
			my $genotype7 = $genotype{$id7};
			if (length($genotype7) >=1) {
				print TGEN "$,$markgen{$id7}{$marker6}";
			}
		}
		$tfam = "";
		print TPED "\n";
		print TGEN "\n";
		#print "\n";
	}
	close (IN6);
	close (TPED);
	close (NOF);
	close (TGEN);
	close (TMAP);
	
	if ( ($substfile =~ m/none/) && ($idsubfile =~ m/none/) ) {
		# do nothing
	} else {
		print "Original family ID : $origfam{$famid5}\n";
		print "New family ID      : $famid5 \n";
	}
}

