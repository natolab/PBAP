#!/usr/bin/perl
# ./setup_gl_auto.pl
# By Alejandro Q. Nato Jr., Ph.D. 
# This script prepares files for gl_auto
# Run this script after running marker_subpanels.pl but before running run_gl_auto.pl
# because the directory structure will be based on the output of marker_subpanels.pl
# Some portions were based on scripts written by Dr. Nicola H. Chapman

# 04/30/2103, 12/20/2013-01/31/2014
# Modifications: 02/11/2014-07/31/2015


use strict;
use warnings;
use diagnostics;

use Time::HiRes qw( gettimeofday );

$, = " ";	# set output field separator

my ($line, $line1, $line2, $line3, $line4, $line5) = "";
my (@list, @list1, @list2, @list3, @list4, @list5) = ();
my (@info, @info1, @info2, @info3, @info4, @info5) = ();

my ($line6, $line7, $line8, $line9, $line10) = "";
my (@list6, @list7, @list8, @list9, @list10) = ();
my (@info6, @info7, @info8, @info9, @info10) = ();

my ($line11, $line12, $line13, $line14, $line15) = "";
my (@list11, @list12, @list13, @list14, @list15) = ();
my (@info11, @info12, @info13, @info14, @info15) = ();

my ($line16, $line17, $line18, $line19, $line20) = "";
my (@list16, @list17, @list18, @list19, @list20) = ();
my (@info16, @info17, @info18, @info19, @info20) = ();
my ($chr, $panel, $parfile, $singlefam) = "";

if ($#ARGV == 2) {
	$chr       = $ARGV[0];	# chromosome number
	$panel     = $ARGV[1];	# subpanel number
	$parfile   = $ARGV[2];	# absolute path of setup_gl_auto.pl parameter file
} elsif ($#ARGV == 3) {
	$chr       = $ARGV[0];	# chromosome number
	$panel     = $ARGV[1];	# subpanel number
	$parfile   = $ARGV[2];	# absolute path of setup_gl_auto.pl parameter file
	$singlefam = $ARGV[3];	# single family (useful for parallel runs)
}

my ($script, $script1) = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;

if ($#ARGV < 0) {
	$script  = $0;
	$script  =~ s/^(.+)\///g;
	$script  =~ s/^\.\///g;
	$script1 = $script;
	$script1 =~ s/\.pl//g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (Apr 2013, Dec 2013-Feb 2014)\n\n";
	print "This script prepares files for gl_auto\n";
	print "Run this script after running marker_subpanels.pl\n";
	print "   but before running run_gl_auto.pl because the directory structure\n";
	print "   will be based on the output of marker_subpanels.pl\n\n";

	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script chromosome subpanel_number $script1\_parameter_file* family_ID**\n";
	print "       *use absolute path\n";
	print "       **(optional): indicate family ID here if you want to run $script on one family\n\n";

	print "Parameter file should contain the following:\n\n";
	print "\tLine  1 - Chromosome(s) that have genotype data\n";
	print "\t             e.g., if there is genotype data for chromosomes 1-22, put \"1-22\"\n";
	print "\t             if you only have genotype data only for chromosome 3, put \"3\"\n";
	print "\t             or if you only have genotype data only for chromosomes 3 and 7, put \"3 7\"\n";
	print "\tLine  2 - Directory containing setup_gl_auto.pl\n";
	print "\tLine  3 - Directory for output files\n";
	print "\t             Directory will be created if it does not exist\n";
	print "\t             Under this directory, subpanel number, family and chromosome\n";
	print "\t             subdirectories will also be created\n";

	print "\tLine  4 - Split setup_gl_auto output files by pedigree: [Y|N]\n";

	print "\tLine  5 - Family ID exclusion file\n";
	print "\t             Use one file for the entire dataset. Put \"none\" if you don't have a family ID exclusion file.\n";
	print "\t             This file will be useful in excluding families with only 3 genotyped individuals\n";
	print "\t                or when they are trios\n";

	print "\tLine  6 - Genotype exclusion file\n";
	print "\t             Use one file for the entire dataset. Put \"none\" if you don't have a genotype exclusion file.\n";
	print "\t             Based on relcheck.pl results, use this file to exclude genotypes of certain individuals\n";
	print "\t             Format (PBAP tpedo file, space-delimited):\n";
	print "\t                family ID, individual ID, father ID, mother ID, sex\n";

	print "\tLine  7 - Maximum number of meioses for exact computation (see recommended values below)\n";
	print "\t             Recommended values: 10 through 14\n";
	print "\t                This value can be increased up to 20 depending on the processor, memory, and system bit\n";
	print "\tLine  8 - Total number of ibdgraphs per component for exact computation (see recommended value below)\n";
	print "\t             This will be number of ibdgraphs that will be saved for each component\n";
	print "\t             Usual value: 1000\n";
	print "\t                Depending on pedigree size and structure, you may need to increase this value\n";

	print "\tLine  9 - Total number of sequential imputation realizations for setup (see recommended values below)\n";
	print "\t             Relatively complete data: 20\n";
	print "\t             Sparse data (a lot of missing data): >=50\n";

	print "\tLine 10 - Total number of MC iterations (see recommended values below)\n";
	print "\t             Test runs: >=30,000\n";
	print "\t             Regular runs: >=100,000\n";
	
	print "\tLine 11 - Percentage (%) of MC iterations for burn-in (see recommended values below)\n";
	print "\t             Relatively complete data: 10\n";
	print "\t             Sparse data (a lot of missing data): >10\n";
	
	print "\tLine 12 - L-sampler probability (see recommended values below)\n";
	print "\t             Test runs: 0.5\n";
	print "\t             Regular runs: 0.2\n";
	print "\tLine 13 - Output score every nth scored MC iterations\n";
	print "\t             Quotient of line 10/line 13 should be an integer\n";
	print "\t             Recommended value: 50 (i.e., 50,000 total MC iterations/50 = 1,000 sampled IVs)\n";
	
	print "\tLine 14 - Population: [AFR|AMR|ASN|EUR]\n";

	print "\tLine 15 - Source of minor allele frequency (MAF) information: [dataset|1KG|MAF]\n";
	print "\t             dataset : Use genotypes of the dataset (minimum of 20 families AND 100 founders)\n";
	print "\t             1KG     : Use MAFs of unrelateds obtained from running marker_subpanels.pl\n";
	print "\t                          You should make sure that allele 1 (minor allele) of dataset matches allele 1 of 1KG\n";
	print "\t             MAF     : Use MAF file supplied by user\n";
	print "\t                          Format (space-delimited): chromosome, SNP, allele frequencies of alleles 1 through n\n";
	print "\t             If you chose \"dataset\" or \"1KG,\" put \"none\" for lines 16-19.\n";
	print "\tLine 16 - Directory containing MAF files\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 17 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where map files are located\n";
	print "\tLine 18 - [(prefix=)(suffix)] of chromosome number in input MAF filenames\n";
	print "\t             e.g., if if your files are named chr*-maf.txt, put \"prefix=chr suffix=-maf.txt\"\n";
	print "\tLine 19 - Input MAF file has a header or not: header=[T|F]\n";

	print "\tLine 20 - Directory containing map files for all subpanels\n";
	print "\t             Do not include the subdirectories for each subpanel (i.e., panel#) and population (line 14) here\n";
	print "\t             They will automatically be added based on the subpanel number and population that you indicated\n";
	print "\t             e.g., if your directory is \"subpaneldir\/panel*\/EUR,\" just place \"subpaneldir\" here\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 21 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where map files are located\n";
	print "\tLine 22 - [(prefix=)(suffix)] of chromosome number in input map filenames\n";
	print "\t             e.g., if if your files are named chr*-map.txt, put \"prefix=chr suffix=-map.txt\"\n";
	print "\tLine 23 - Input map file has a header or not: header=[T|F]\n";

	print "\tLine 24 - Directory containing pedigree files\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 25 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where pedigree files are located\n";
	print "\tLine 26 - [(prefix=)(suffix)] of chromosome number in input pedigree filenames\n";
	print "\t             e.g., if if your files are named chr*-ped.txt, put \"prefix=chr suffix=-ped.txt\"\n";
	print "\tLine 27 - Input pedigree file has a header or not: header=[T|F]\n";

	print "\tLine 28 - Number of types of markers with genotype data: [1|2]\n";
	print "\t             1: SNPs or STRs but not both\n";
	print "\t             2: Both SNPs and STRs\n";
	print "\t             If you chose 1, leave lines 39-48 blank\n";

	print "\tLine 29 - Marker type for first set of genotype data: [SNP|STR]\n";
	print "\tLine 30 - Directory containing first set of genotype data\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 31 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where genotype files are located\n";
	print "\tLine 32 - [(prefix=)(suffix)] of chromosome number in input genotype filenames\n";
	print "\t             e.g., if if your files are named chr*-geno.txt, put \"prefix=chr suffix=-geno.txt\"\n";
	print "\tLine 33 - Input genotype file has a header or not: header=[T|F]\n";
	print "\tLine 34 - Option: [1|2] for input file(s) containing IDs of genotyped individuals\n";
	print "\t             1: Use output files of transpose_fileset.pl\n";
	print "\t             2: Use a file containing the list of genotyped individuals (supplied by user)\n";
	print "\t             If you chose option 2, line 34 should contain the absolute path of input file\n";
	print "\t             and put \"none\" for lines 36-38.\n";
	print "\tLine 35 - If option 1 was chosen in line 34,\n";
	print "\t             indicate directory containing files with IDs of genotyped individuals\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\t          If option 2 was chosen in line 34,\n";
	print "\t             indicate input file containing list of IDs of genotyped individuals (absolute path)\n";
	print "\tLine 36 - [(prefix=)(suffix)] of chromosome number in names of subdirectories where files containing\n";
	print "\t             IDs of genotyped individuals are located\n";
	print "\tLine 37 - [(prefix=)(suffix)] of chromosome number in files containing IDs of genotyped individuals\n";
	print "\t             e.g., if if your files are named chr*-ind.txt, put \"prefix=chr suffix=-ind.txt\"\n";
	print "\tLine 38 - Input file containing IDs of genotyped individuals has a header or not: header=[T|F]\n";

	print "\tLine 39 - Marker type for second set of genotype data: [SNP|STR]\n";
	print "\tLine 40 - Directory containing second set of genotype data\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine 41 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where genotype files are located\n";
	print "\tLine 42 - [(prefix=)(suffix)] of chromosome number in input genotype filenames\n";
	print "\t             e.g., if if your files are named chr*-geno.txt, put \"prefix=chr suffix=-geno.txt\"\n";
	print "\tLine 43 - Input genotype file has a header or not: header=[T|F]\n";
	print "\tLine 44 - Option: [1|2] for input file(s) containing IDs of genotyped individuals\n";
	print "\t             1: Use output files of transpose_fileset.pl\n";
	print "\t             2: Use a file containing the list of genotyped individuals (supplied by user)\n";
	print "\t             If you chose option 2, line 45 should contain the absolute path of input file\n";
	print "\t             and put \"none\" for lines 46-48.\n";
	print "\tLine 45 - If option 1 was chosen in line 44,\n";
	print "\t             indicate directory containing files with IDs of genotyped individuals\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\t          If option 2 was chosen in line 44,\n";
	print "\t             indicate input file containing list of IDs of genotyped individuals (absolute path)\n";
	print "\tLine 46 - [(prefix=)(suffix)] of chromosome number in names of subdirectories where files containing\n";
	print "\t             IDs of genotyped individuals are located\n";
	print "\tLine 47 - [(prefix=)(suffix)] of chromosome number in files containing IDs of genotyped individuals\n";
	print "\t             e.g., if if your files are named chr*-ind.txt, put \"prefix=chr suffix=-ind.txt\"\n";
	print "\tLine 48 - Input file containing IDs of genotyped individuals has a header or not: header=[T|F]\n";

	print "\tNotes: 1) Blank lines and lines that start with a pound sign (#) will be ignored\n";
	print "\t       2) Use absolute paths for all directories and filenames unless specified otherwise\n";
	print "\t       3) To avoid mismatching, all individual IDs should be concatenated with family IDs,\n";
	print "\t             e.g., \"FamilyID.IndividualID\" or \"FamilyID_IndividualID\"\n";
	print "\t       4) For subdirectories in lines 17, 21, 25, 31, 36, 41, and 47, if files in lines 18, 22, 26, 32, 37, 42, and 48 are directly\n";
	print "\t             under the directories in lines 16, 20, 24, 31, 35, 40, and 46, respectively, put \"no dir\"\n";
	print "\t             Examples (if subdirectories are present):\n";
	print "\t             If subdirectories are named chr*, put \"prefix=chr suffix=none\"\n";
	print "\t             If subdirectories are named chr*geno, put \"prefix=chr suffix=geno\"\n";
	print "\t             If subdirectories just contain the chromosome number without any prefix or suffix, you can put \"none\"\n";
	print "\t       5) Phenotype information is not needed for this script\n";
	print "\t       6) Lines 15-19, 20-23, 24-27, 29-38, and 39-48 are for the MAF, subpanel (map), pedigree,\n";
	print "\t             first set of genotype files, and second set of genotype files, respectively\n";
	print "\t       7) Families with <3 genotyped individuals will be excluded\n\n";
	exit;
}
##############
my ($count, $count1, $count2, $count3, $count4, $numtype) = 0;
my ($seqimp, $burnperc, $ibdgnum, $maxped) = 0;
my ($splitped, $famexc, $exclu, $popn, $mafopt, $mrkrtype, $mrkrtype2) = "";
my ($mafname, $mafpre, $mafsuf, $mafin) = "";
my ($mapname, $mappre, $mapsuf, $mapin) = "";
my ($pedname, $pedpre, $pedsuf, $pedin) = "";
my ($option, $genoname, $genopre, $genosuf, $genoin) = "";
my ($option2, $genoname2, $genopre2, $genosuf2, $genoin2) = "";
my ($idname, $idpre, $idsuf, $idin) = "";
my ($idname2, $idpre2, $idsuf2, $idin2) = "";
my ($mainfdir, $mafdir, $mafdirpre, $mafdirsuf, $mafdirin) = "";
my ($mainmdir, $mapdir, $mapdirpre, $mapdirsuf, $mapdirin) = "";
my ($mainpdir, $peddir, $peddirpre, $peddirsuf, $peddirin) = "";
my ($maingdir, $genodir, $genodirpre, $genodirsuf, $genodirin) = "";
my ($maingdir2, $genodir2, $genodirpre2, $genodirsuf2, $genodirin2) = "";
my ($mainidir, $iddir, $iddirpre, $iddirsuf, $iddirin, $outdir, $scriptdir) = "";
my ($mainidir2, $iddir2, $iddirpre2, $iddirsuf2, $iddirin2) = "";
my ($maffdir, $maffile, $mafh, $mapfdir, $mapfile, $maph, $pedfdir, $pedfile, $pedh) = "";
my ($genofdir, $genofile, $genoh, $idfdir, $idfile, $idh) = "";
my ($genofdir2, $genofile2, $genoh2, $idfdir2, $idfile2, $idh2) = "";
my ($mctot, $lsample, $mcsample) = 0;
my ($chrA, $chrs, $chre, $i) = 0;
my (@idin, @idin2) = ();
my (%freq, %freq2, %imgeno) = ();

open (IN1, "<$parfile") || die ("Could not open $parfile!\n");
@list1 = <IN1>;
close (IN1);
print "\nThese are the parameters that you specified:\n";
foreach $line1 (@list1) {
	chomp $line1;
	next if ($line1 =~ m/^\#/);
	next if ( ($line1 =~ m/\t|\#/) && ( ($line1 =~ m/line|:|\"|\=/i) || ($line1 !~ m/\d/)) );
	next if (length($line1) == 0);
	$line1 =~ s/^\s+//g;
	$line1 =~ s/\s+$//g;
	$count++;
	print "line $count: $line1\n";
	if    ($count == 1) { $chrA      = $line1; }
	elsif ($count == 2) { $scriptdir = $line1; }
	elsif ($count == 3) { $outdir    = $line1; }
	elsif ($count == 4) { $splitped  = $line1; }
	elsif ($count == 5) { $famexc    = $line1; }
	elsif ($count == 6) { $exclu     = $line1; }

	elsif ($count == 7) { $maxped    = $line1; }
	elsif ($count == 8) { $ibdgnum  = $line1; }
	elsif ($count == 9) { $seqimp    = $line1; }
	elsif ($count == 10) { $mctot     = $line1; }
	elsif ($count == 11) { $burnperc = $line1; }
	elsif ($count == 12) { $lsample  = $line1; }
	elsif ($count == 13) { $mcsample = $line1; }

	elsif ($count == 14) { $popn    = $line1; }

	elsif ($count == 15) { $mafopt   = $line1; }

	elsif ($count == 16) { $mainfdir = $line1; }
	elsif ($count == 17) { $mafdir  = $line1; }
	elsif ($count == 18) { $mafname = $line1; }
	elsif ($count == 19) { $mafh    = $line1; }

	elsif ($count == 20) { $mainmdir = $line1; }
	elsif ($count == 21) { $mapdir  = $line1; }
	elsif ($count == 22) { $mapname = $line1; }
	elsif ($count == 23) { $maph    = $line1; }

	elsif ($count == 24) { $mainpdir = $line1; }
	elsif ($count == 25) { $peddir  = $line1; }
	elsif ($count == 26) { $pedname = $line1; }
	elsif ($count == 27) { $pedh    = $line1; }

	elsif ($count == 28) { $numtype = $line1; }
	elsif ( (defined($numtype)) && ($numtype == 1) ) {
		if ($count == 29) { $mrkrtype = $line1; }
		elsif ($count == 30) { $maingdir = $line1; }
		elsif ($count == 31) { $genodir  = $line1; }
		elsif ($count == 32) { $genoname = $line1; }
		elsif ($count == 33) { $genoh    = $line1; }
		elsif ($count == 34) { $option   = $line1; }
		elsif ( (defined($option)) && ($option == 1) ) {
			if ($count == 35) { $mainidir = $line1; }
			elsif ($count == 36) { $iddir    = $line1; }
			elsif ($count == 37) { $idname   = $line1; }
			elsif ($count == 38) { $idh      = $line1; }
		} elsif ( (defined($option)) && ($option == 2) ) {
			if    ($count == 35) { $idin     = $line1; }
		}
	} elsif ( (defined($numtype)) && ($numtype == 2) ) {
		if ($count == 29) { $mrkrtype = $line1; }
		elsif ($count == 30) { $maingdir = $line1; }
		elsif ($count == 31) { $genodir  = $line1; }
		elsif ($count == 32) { $genoname = $line1; }
		elsif ($count == 33) { $genoh    = $line1; }
		elsif ($count == 34) { $option   = $line1; }

		elsif ( ($count >= 35) && ($count <= 38) && (defined($option)) && ($option == 1) ) {
			if ($count == 35) { $mainidir = $line1; }
			elsif ($count == 36) { $iddir    = $line1; }
			elsif ($count == 37) { $idname   = $line1; }
			elsif ($count == 38) { $idh      = $line1; }
		} elsif ( ($count >= 35) && ($count <= 38) && (defined($option)) && ($option == 2) ) {
			if    ($count == 35) { $idin     = $line1; }
		}

		elsif ($count == 39) { $mrkrtype2 = $line1; }
		elsif ($count == 40) { $maingdir2 = $line1; }
		elsif ($count == 41) { $genodir2  = $line1; }
		elsif ($count == 42) { $genoname2 = $line1; }
		elsif ($count == 43) { $genoh2    = $line1; }
		elsif ($count == 44) { $option2   = $line1; }

		elsif ( ($count >= 45) && ($count <= 48) && (defined($option2)) && ($option2 == 1) ) {
			if ($count == 45) { $mainidir2 = $line1; }
			elsif ($count == 46) { $iddir2    = $line1; }
			elsif ($count == 47) { $idname2   = $line1; }
			elsif ($count == 48) { $idh2      = $line1; }
		} elsif ( ($count >= 45) && ($count <= 48) && (defined($option)) && ($option2 == 2) ) {
			if    ($count == 45) { $idin2     = $line1; }
		}
	}
}
print "\n";
if ( (defined($mainfdir)) && ($mainfdir =~ m/\/$/) ) { chop $mainfdir; }
if ( (defined($mainmdir)) && ($mainmdir =~ m/\/$/) ) { chop $mainmdir; }
if ( (defined($mainpdir)) && ($mainpdir =~ m/\/$/) ) { chop $mainpdir; }
if ( (defined($maingdir)) && ($maingdir =~ m/\/$/) ) { chop $maingdir; }
if ( (defined($maingdir2)) && ($maingdir2 =~ m/\/$/) ) { chop $maingdir2; }
if ( (defined($mainidir)) && ($mainidir =~ m/\/$/) ) { chop $mainidir; }
if ( (defined($mainidir2)) && ($mainidir2 =~ m/\/$/) ) { chop $mainidir2; }
if ( (defined($outdir)) && ($outdir =~ m/\/$/) ) { chop $outdir; }


$outdir = $outdir . "/panel" . $panel;
if (! -e $outdir) {
	`mkdir -p $outdir`;
}
my $popchrdir = $outdir . "/" . $popn . "/chr" . $chr;
if ($splitped =~ m/N/i) {
	if (! -e $popchrdir) {
		`mkdir -p $popchrdir`;
	}
}

my $popinfodir = $outdir . "/" . $popn . "/info_tind";
if (! -e $popinfodir) {
	`mkdir -p $popinfodir`;
}

# Create log file
my $logdir = $outdir . "/log";
if (! -e $logdir) {
	`mkdir -p $logdir`;
}
my $log = "";
if (!defined($singlefam)) {
	$log = "$logdir\/setup_gl_auto_panel$panel\_$popn\_chr$chr\.log";
} elsif (defined($singlefam)) {
	$log = "$logdir\/setup_gl_auto_panel$panel\_$popn\_chr$chr\_$singlefam\.log";
}
open(LOG, ">$log") || die ("Could not create $log file!\n");
open (LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "################################################################################\n";
print LOG "#                            PBAP setup_gl_auto.pl                             #\n";
print LOG "#                            Alejandro Q. Nato, Jr.                            #\n";
print LOG "#                           Statistical Genetics Lab                           #\n";
print LOG "#                    University of Washington, Seattle, WA                     #\n";
print LOG "################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

my @chrA = ();
if ($chrA =~ m/\-/) {
	($chrs, $chre) = split (/\-/, $chrA);
} elsif ($chrA =~ m/\s+/) {
	@chrA = split (/\s+/, $chrA);
} else {
	$chrs = $chre = $chrA;
}


print LOG "PARAMETERS SPECIFIED:\n";
$mafopt =~ s/^\s+//g;
$mafopt =~ s/\s$//g;
print "Source of MAF information : $mafopt\n";
print LOG "Source of MAF information    : $mafopt\n";

# Map file (added panel number and population to mainmdir below)
$mainmdir = $mainmdir . "/panel" . $panel . "/" . $popn;
if ($mapdir eq "no dir") {
	# map files are directly under mainmdir
	$mapfdir = $mainmdir;
} elsif ($mapdir ne "no dir") {
	if ($mapdir eq "none") {
		$mapdirpre = "";
		$mapdirsuf = "";
	} elsif ($mapdir =~ m/prefix\=(.+) suffix\=(.+)/) {
		$mapdirpre = $1;
		$mapdirsuf = $2;
		if ($mapdirpre eq "none") { $mapdirpre = ""; }
		if ($mapdirsuf eq "none") { $mapdirsuf = ""; }
	} elsif ( ($mapdir =~ m/prefix\=(.+)/) && ($mapdir !~ m/suffix\=(.+)/) ) {
		$mapdirpre = $1;
		$mapdirsuf = "";
		if ($mapdirpre eq "none") { $mapdirpre = ""; }
	} elsif ( ($mapdir !~ m/prefix\=(.+)/) && ($mapdir =~ m/suffix\=(.+)/) ) {
		$mapdirpre = "";
		$mapdirsuf = $1;
		if ($mapdirsuf eq "none") { $mapdirsuf = ""; }
	}
	$mapfdir = $mainmdir . "/" . $mapdirpre . $chr . $mapdirsuf;
}
if ($mapname =~ m/prefix\=(.+) suffix\=(.+)/) {
	$mappre = $1;
	$mapsuf = $2;
	if ($mappre eq "none") { $mappre = ""; }
	if ($mapsuf eq "none") { $mapsuf = ""; }
} elsif ( ($mapname =~ m/prefix\=(.+)/) && ($mapname !~ m/suffix\=(.+)/) ) {
	$mappre = $1;
	$mapsuf = "";
	if ($mappre eq "none") { $mappre = ""; }
} elsif ( ($mapname !~ m/prefix\=(.+)/) && ($mapname =~ m/suffix\=(.+)/) ) {
	$mappre = "";
	$mapsuf = $1;
	if ($mapsuf eq "none") { $mapsuf = ""; }
}
$mapfile = $mapfdir . "/" . $mappre . $chr . $mapsuf;
print "Map file : $mapfile\n";
print LOG "Map file                     : $mapfile\n";

# MAF file
#my $matchKGpos = "";
if ($mafopt =~ m/dataset/i) {
	# no maffile needed
} elsif ($mafopt =~ m/1KG/i) {
	# use Plink-generated MAF file (marker_subpanels.pl output file)
	$maffdir = $mainmdir . "/aux/chr" . $chr;
	#$matchKGpos = $maffdir . "/chr" . $chr . "_KGpos.match";
	$maffile = $mapfile;
	print "MAF file : $maffile\n";
	print LOG "MAF file for SNPs            : $maffile\n";
} elsif ($mafopt =~ m/MAF/i) {
	if ($mafdir eq "no dir") {
		# MAF files are directly under mainfdir
		$maffdir = $mainfdir;
	} elsif ($mafdir ne "no dir") {
		if ($mafdir eq "none") {
			$mafdirpre = "";
			$mafdirsuf = "";
		} elsif ($mafdir =~ m/prefix\=(.+) suffix\=(.+)/) {
			$mafdirpre = $1;
			$mafdirsuf = $2;
			if ($mafdirpre eq "none") { $mafdirpre = ""; }
			if ($mafdirsuf eq "none") { $mafdirsuf = ""; }
		} elsif ( ($mafdir =~ m/prefix\=(.+)/) && ($mafdir !~ m/suffix\=(.+)/) ) {
			$mafdirpre = $1;
			$mafdirsuf = "";
			if ($mafdirpre eq "none") { $mafdirpre = ""; }
		} elsif ( ($mafdir !~ m/prefix\=(.+)/) && ($mafdir =~ m/suffix\=(.+)/) ) {
			$mafdirpre = "";
			$mafdirsuf = $1;
			if ($mafdirsuf eq "none") { $mafdirsuf = ""; }
		}
	   	$maffdir = $mainfdir . "/" . $mafdirpre . $chr . $mafdirsuf;
	}
	if ($mafname =~ m/prefix\=(.+) suffix\=(.+)/) {
		$mafpre = $1;
		$mafsuf = $2;
		if ($mafpre eq "none") { $mafpre = ""; }
		if ($mafsuf eq "none") { $mafsuf = ""; }
	} elsif ( ($mafname =~ m/prefix\=(.+)/) && ($mafname !~ m/suffix\=(.+)/) ) {
		$mafpre = $1;
		$mafsuf = "";
		if ($mafpre eq "none") { $mafpre = ""; }
	} elsif ( ($mafname !~ m/prefix\=(.+)/) && ($mafname =~ m/suffix\=(.+)/) ) {
		$mafpre = "";
		$mafsuf = $1;
		if ($mafsuf eq "none") { $mafsuf = ""; }
	}
	$maffile = $maffdir . "/" . $mafpre . $chr . $mafsuf;
	print "MAF file : $maffile\n";
	print LOG "MAF file                     : $maffile\n";
}


# Pedigree file
if ($peddir eq "no dir") {
	# pedigree files are directly under mainfdir
	$pedfdir = $mainpdir;
} elsif ($peddir ne "no dir") {
	if ($peddir eq "none") {
		$peddirpre = "";
		$peddirsuf = "";
	} elsif ($peddir =~ m/prefix\=(.+) suffix\=(.+)/) {
		$peddirpre = $1;
		$peddirsuf = $2;
		if ($peddirpre eq "none") { $peddirpre = ""; }
		if ($peddirsuf eq "none") { $peddirsuf = ""; }
	} elsif ( ($peddir =~ m/prefix\=(.+)/) && ($peddir !~ m/suffix\=(.+)/) ) {
		$peddirpre = $1;
		$peddirsuf = "";
		if ($peddirpre eq "none") { $peddirpre = ""; }
	} elsif ( ($peddir !~ m/prefix\=(.+)/) && ($peddir =~ m/suffix\=(.+)/) ) {
		$peddirpre = "";
		$peddirsuf = $1;
		if ($peddirsuf eq "none") { $peddirsuf = ""; }
	}
	$pedfdir = $mainpdir . "/" . $peddirpre . $chr . $peddirsuf;
}
if ($pedname =~ m/prefix\=(.+) suffix\=(.+)/) {
	$pedpre = $1;
	$pedsuf = $2;
	if ($pedpre eq "none") { $pedpre = ""; }
	if ($pedsuf eq "none") { $pedsuf = ""; }
} elsif ( ($pedname =~ m/prefix\=(.+)/) && ($pedname !~ m/suffix\=(.+)/) ) {
	$pedpre = $1;
	$pedsuf = "";
	if ($pedpre eq "none") { $pedpre = ""; }
} elsif ( ($pedname !~ m/prefix\=(.+)/) && ($pedname =~ m/suffix\=(.+)/) ) {
	$pedpre = "";
	$pedsuf = $1;
	if ($pedsuf eq "none") { $pedsuf = ""; }
}
$pedfile = $pedfdir . "/" . $pedpre . $chr . $pedsuf;
print "Pedigree file : $pedfile\n";
print LOG "Pedigree file                : $pedfile\n";


if ( (defined($numtype)) && ($numtype == 1) ) {	# only need lines 28-38 of parfile
	print     "Number of types of markers : $numtype\n";
	print LOG "Number of types of markers   : $numtype\n";
	print     "Marker type : $mrkrtype\n";
	print LOG "Marker type                  : $mrkrtype\n";
	if ($genodir eq "no dir") {
		# genotype files are directly under maingdir
		$genofdir = $maingdir;
	} elsif ($genodir ne "no dir") {
		if ($genodir eq "none") {
			$genodirpre = "";
			$genodirsuf = "";
		} elsif ($genodir =~ m/prefix\=(.+) suffix\=(.+)/) {
			$genodirpre = $1;
			$genodirsuf = $2;
			if ($genodirpre eq "none") { $genodirpre = ""; }
			if ($genodirsuf eq "none") { $genodirsuf = ""; }
		} elsif ( ($genodir =~ m/prefix\=(.+)/) && ($genodir !~ m/suffix\=(.+)/) ) {
			$genodirpre = $1;
			$genodirsuf = "";
			if ($genodirpre eq "none") { $genodirpre = ""; }
		} elsif ( ($genodir !~ m/prefix\=(.+)/) && ($genodir =~ m/suffix\=(.+)/) ) {
			$genodirpre = "";
			$genodirsuf = $1;
			if ($genodirsuf eq "none") { $genodirsuf = ""; }
		}
		$genofdir = $maingdir . "/" . $genodirpre . $chr . $genodirsuf;
	}
	if ($genoname =~ m/prefix\=(.+) suffix\=(.+)/) {
		$genopre = $1;
		$genosuf = $2;
		if ($genopre eq "none") { $genopre = ""; }
		if ($genosuf eq "none") { $genosuf = ""; }
	} elsif ( ($genoname =~ m/prefix\=(.+)/) && ($genoname !~ m/suffix\=(.+)/) ) {
		$genopre = $1;
		$genosuf = "";
		if ($genopre eq "none") { $genopre = ""; }
	} elsif ( ($genoname !~ m/prefix\=(.+)/) && ($genoname =~ m/suffix\=(.+)/) ) {
		$genopre = "";
		$genosuf = $1;
		if ($genosuf eq "none") { $genosuf = ""; }
	}
	$genofile = $genofdir . "/" . $genopre . $chr . $genosuf;
	print "Genotype file : $genofile\n";
	print LOG "Genotype file                : $genofile\n";

	if ($option == 1) {
		# Compare all individual ID files per chromosome and use the IDs that are
		# present across all chromosomes
		if ($iddir eq "no dir") {
			# ID files are directly under mainidir
			$idfdir = $mainidir;
		} elsif ($iddir ne "no dir") {
			if ($iddir eq "none") {
				$iddirpre = "";
				$iddirsuf = "";
			} elsif ($iddir =~ m/prefix\=(.+) suffix\=(.+)/) {
				$iddirpre = $1;
				$iddirsuf = $2;
				if ($iddirpre eq "none") { $iddirpre = ""; }
				if ($iddirsuf eq "none") { $iddirsuf = ""; }
			} elsif ( ($iddir =~ m/prefix\=(.+)/) && ($iddir !~ m/suffix\=(.+)/) ) {
				$iddirpre = $1;
				$iddirsuf = "";
				if ($iddirpre eq "none") { $iddirpre = ""; }
			} elsif ( ($iddir !~ m/prefix\=(.+)/) && ($iddir =~ m/suffix\=(.+)/) ) {
				$iddirpre = "";
				$iddirsuf = $1;
				if ($iddirsuf eq "none") { $iddirsuf = ""; }
			}
			$idfdir = $mainidir . "/" . $iddirpre . $chr . $iddirsuf;
		}
		if ($idname =~ m/prefix\=(.+) suffix\=(.+)/) {
			$idpre = $1;
			$idsuf = $2;
			if ($idpre eq "none") { $idpre = ""; }
			if ($idsuf eq "none") { $idsuf = ""; }
		} elsif ( ($idname =~ m/prefix\=(.+)/) && ($idname !~ m/suffix\=(.+)/) ) {
			$idpre = $1;
			$idsuf = "";
			if ($idpre eq "none") { $idpre = ""; }
		} elsif ( ($idname !~ m/prefix\=(.+)/) && ($idname =~ m/suffix\=(.+)/) ) {
			$idpre = "";
			$idsuf = $1;
			if ($idsuf eq "none") { $idsuf = ""; }
		}
		$idfile = $idfdir . "/" . $idpre . $chr . $idsuf;
		print "IDs of genotyped individuals : $idfile\n";
		print LOG "IDs of genotyped individuals : $idfile\n";

		# check individual ID files now
		(@list2, @idin) = ();
		%freq = ();
		my $numchr = 0;
		if ($chrA !~ m/\s+/) {
			$numchr = $chre - $chrs + 1;
			if ($numchr > 1) {
				print "Checking if individual IDs specified in $idpre" . $chr . "$idsuf are present in ID files for chromosomes $chrs\-$chre\...\n";
			} elsif ($numchr == 1) {
				# do nothing
			}
			for ($i=$chrs; $i<=$chre; $i++) {
				my $idftemp = "";
				if ($iddir eq "no dir") {
					$idftemp = $idfdir . "/" . $idpre . $i . $idsuf;
				} else {
					$idftemp = $mainidir . "/" . $iddirpre . $i . $iddirsuf . "/" . $idpre . $i . $idsuf;
				}
				open (IN2, "<$idftemp") || die ("Could not open $idftemp file!\n");
				@list2 = <IN2>;
				close (IN2);
				foreach $line2 (@list2) {
					chomp $line2;
					$line2 =~ s/^\s+//g;
					$line2 =~ s/\s+$//g;
					next if (length ($line2) == 0);
					$freq{$line2}++;
				}
			}
		} elsif ($chrA =~ m/\s+/) {
			$numchr = scalar(@chrA);
			if ($numchr > 1) {
				print "Checking if individual IDs specified in $idpre" . $chr . "$idsuf are present in ID files for chromosomes " . join (" ", @chrA) . "...\n";
			} elsif ($numchr == 1) {
				# do nothing
			}
			foreach $i (@chrA) {
				my $idftemp = "";
				if ($iddir eq "no dir") {
					$idftemp = $idfdir . "/" . $idpre . $i . $idsuf;
				} else {
					$idftemp = $mainidir . "/" . $iddirpre . $i . $iddirsuf . "/" . $idpre . $i . $idsuf;
				}
				open (IN2, "<$idftemp") || die ("Could not open $idftemp file!\n");
				@list2 = <IN2>;
				close (IN2);
				foreach $line2 (@list2) {
					chomp $line2;
					$line2 =~ s/^\s+//g;
					$line2 =~ s/\s+$//g;
					next if (length ($line2) == 0);
					$freq{$line2}++;
				}
			}
		}
		# use the last list2 to check the individual IDs that are present in all ID files
		my $iderr = 0;
		foreach $line2 (@list2) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if (length ($line2) == 0);
			if ($freq{$line2} == $numchr) {
				push (@idin, $line2);
			} elsif ($freq{$line2} < $numchr) {
				print "Check ID of individual $line2 in one of the ID files\n";
				$iderr++;
			}
		}

		if ($iderr == 0) {
			print "  Individual IDs are present in all ID files\n";
		}

	} elsif ($option == 2) {
		# use the file supplied by the user as the $idin
		print "IDs of genotyped individuals : $idin\n";
		print LOG "IDs of genotyped individuals     : $idin\n";
		# $idin is also $idfile
		$idfile = $idin;
		(@list2, @idin) = ();
		open (IN2, "<$idfile") || die ("Could not open $idfile file!\n");
		@list2 = <IN2>;
		close (IN2);
		foreach $line2 (@list2) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if (length ($line2) == 0);
			push (@idin, $line2);
		}
	}
} elsif ( (defined($numtype)) && ($numtype == 2) ) {	# we need lines 16-25 and 26-35 of parfile
	print     "Number of types of markers : $numtype\n";
	print LOG "Number of types of markers   : $numtype\n";
	print     "Marker type of first set : $mrkrtype\n";
	print LOG "Marker type of first set     : $mrkrtype\n";
	if ($genodir eq "no dir") {
		# genotype files are directly under maingdir
		$genofdir = $maingdir;
	} elsif ($genodir ne "no dir") {
		if ($genodir eq "none") {
			$genodirpre = "";
			$genodirsuf = "";
		} elsif ($genodir =~ m/prefix\=(.+) suffix\=(.+)/) {
			$genodirpre = $1;
			$genodirsuf = $2;
			if ($genodirpre eq "none") { $genodirpre = ""; }
			if ($genodirsuf eq "none") { $genodirsuf = ""; }
		} elsif ( ($genodir =~ m/prefix\=(.+)/) && ($genodir !~ m/suffix\=(.+)/) ) {
			$genodirpre = $1;
			$genodirsuf = "";
			if ($genodirpre eq "none") { $genodirpre = ""; }
		} elsif ( ($genodir !~ m/prefix\=(.+)/) && ($genodir =~ m/suffix\=(.+)/) ) {
			$genodirpre = "";
			$genodirsuf = $1;
			if ($genodirsuf eq "none") { $genodirsuf = ""; }
		}
		$genofdir = $maingdir . "/" . $genodirpre . $chr . $genodirsuf;
	}
	if ($genoname =~ m/prefix\=(.+) suffix\=(.+)/) {
		$genopre = $1;
		$genosuf = $2;
		if ($genopre eq "none") { $genopre = ""; }
		if ($genosuf eq "none") { $genosuf = ""; }
	} elsif ( ($genoname =~ m/prefix\=(.+)/) && ($genoname !~ m/suffix\=(.+)/) ) {
		$genopre = $1;
		$genosuf = "";
		if ($genopre eq "none") { $genopre = ""; }
	} elsif ( ($genoname !~ m/prefix\=(.+)/) && ($genoname =~ m/suffix\=(.+)/) ) {
		$genopre = "";
		$genosuf = $1;
		if ($genosuf eq "none") { $genosuf = ""; }
	}
	$genofile = $genofdir . "/" . $genopre . $chr . $genosuf;
	print "Genotype file : $genofile\n";
	print LOG "Genotype file                : $genofile\n";

	if ($option == 1) {
		# Compare all individual ID files per chromosome and use the IDs that are
		# present across all chromosomes
		if ($iddir eq "no dir") {
			# ID files are directly under mainidir
			$idfdir = $mainidir;
		} elsif ($iddir ne "no dir") {
			if ($iddir eq "none") {
				$iddirpre = "";
				$iddirsuf = "";
			} elsif ($iddir =~ m/prefix\=(.+) suffix\=(.+)/) {
				$iddirpre = $1;
				$iddirsuf = $2;
				if ($iddirpre eq "none") { $iddirpre = ""; }
				if ($iddirsuf eq "none") { $iddirsuf = ""; }
			} elsif ( ($iddir =~ m/prefix\=(.+)/) && ($iddir !~ m/suffix\=(.+)/) ) {
				$iddirpre = $1;
				$iddirsuf = "";
				if ($iddirpre eq "none") { $iddirpre = ""; }
			} elsif ( ($iddir !~ m/prefix\=(.+)/) && ($iddir =~ m/suffix\=(.+)/) ) {
				$iddirpre = "";
				$iddirsuf = $1;
				if ($iddirsuf eq "none") { $iddirsuf = ""; }
			}
			$idfdir = $mainidir . "/" . $iddirpre . $chr . $iddirsuf;
		}
		if ($idname =~ m/prefix\=(.+) suffix\=(.+)/) {
			$idpre = $1;
			$idsuf = $2;
			if ($idpre eq "none") { $idpre = ""; }
			if ($idsuf eq "none") { $idsuf = ""; }
		} elsif ( ($idname =~ m/prefix\=(.+)/) && ($idname !~ m/suffix\=(.+)/) ) {
			$idpre = $1;
			$idsuf = "";
			if ($idpre eq "none") { $idpre = ""; }
		} elsif ( ($idname !~ m/prefix\=(.+)/) && ($idname =~ m/suffix\=(.+)/) ) {
			$idpre = "";
			$idsuf = $1;
			if ($idsuf eq "none") { $idsuf = ""; }
		}
		$idfile = $idfdir . "/" . $idpre . $chr . $idsuf;
		print "IDs of genotyped individuals : $idfile\n";
		print LOG "IDs of genotyped individuals : $idfile\n";

		# check individual ID files now
		(@list2, @idin) = ();
		%freq = ();
		my $numchr = 0;
		if ($chrA !~ m/\s+/) {
			$numchr = $chre - $chrs + 1;
			if ($numchr > 1) {
				print "Checking if individual IDs specified in $idpre" . $chr . "$idsuf are present in ID files for chromosomes $chrs\-$chre\...\n";
			} elsif ($numchr == 1) {
				# do nothing
			}
			for ($i=$chrs; $i<=$chre; $i++) {
				my $idftemp = "";
				if ($iddir eq "no dir") {
					$idftemp = $idfdir . "/" . $idpre . $i . $idsuf;
				} else {
					$idftemp = $mainidir . "/" . $iddirpre . $i . $iddirsuf . "/" . $idpre . $i . $idsuf;
				}
				open (IN2, "<$idftemp") || die ("Could not open $idftemp file!\n");
				@list2 = <IN2>;
				close (IN2);
				foreach $line2 (@list2) {
					chomp $line2;
					$line2 =~ s/^\s+//g;
					$line2 =~ s/\s+$//g;
					next if (length ($line2) == 0);
					$freq{$line2}++;
				}
			}
		} elsif ($chrA =~ m/\s+/) {
			$numchr = scalar(@chrA);
			if ($numchr > 1) {
				print "Checking if individual IDs specified in $idpre" . $chr . "$idsuf are present in ID files for chromosomes " . join (" ", @chrA) . "...\n";
			} elsif ($numchr == 1) {
				# do nothing
			}
			foreach $i (@chrA) {
				my $idftemp = "";
				if ($iddir eq "no dir") {
					$idftemp = $idfdir . "/" . $idpre . $i . $idsuf;
				} else {
					$idftemp = $mainidir . "/" . $iddirpre . $i . $iddirsuf . "/" . $idpre . $i . $idsuf;
				}
				open (IN2, "<$idftemp") || die ("Could not open $idftemp file!\n");
				@list2 = <IN2>;
				close (IN2);
				foreach $line2 (@list2) {
					chomp $line2;
					$line2 =~ s/^\s+//g;
					$line2 =~ s/\s+$//g;
					next if (length ($line2) == 0);
					$freq{$line2}++;
				}
			}
		}
		# use the last list2 to check the individual IDs that are present in all ID files
		my $iderr = 0;
		foreach $line2 (@list2) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if (length ($line2) == 0);
			if ($freq{$line2} == $numchr) {
				push (@idin, $line2);
			} elsif ($freq{$line2} < $numchr) {
				print "Check ID of individual $line2 in one of the ID files\n";
				$iderr++;
			}
		}


		if ($iderr == 0) {
			print "  Individual IDs are present in all ID files\n";
		}

	} elsif ($option == 2) {
		# use the file supplied by the user as the $idin
		print "IDs of genotyped individuals : $idin\n";
		print LOG "IDs of genotyped individuals     : $idin\n";
		# $idin is also $idfile
		$idfile = $idin;
		(@list2, @idin) = ();
		open (IN2, "<$idfile") || die ("Could not open $idfile file!\n");
		@list2 = <IN2>;
		close (IN2);
		foreach $line2 (@list2) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if (length ($line2) == 0);
			push (@idin, $line2);
		}
	}

	print     "Marker type of second set : $mrkrtype2\n";
	print LOG "Marker type of second set    : $mrkrtype2\n";
	if ($genodir2 eq "no dir") {
		# genotype files are directly under maingdir
		$genofdir2 = $maingdir2;
	} elsif ($genodir2 ne "no dir") {
		if ($genodir2 eq "none") {
			$genodirpre2 = "";
			$genodirsuf2 = "";
		} elsif ($genodir2 =~ m/prefix\=(.+) suffix\=(.+)/) {
			$genodirpre2 = $1;
			$genodirsuf2 = $2;
			if ($genodirpre2 eq "none") { $genodirpre2 = ""; }
			if ($genodirsuf2 eq "none") { $genodirsuf2 = ""; }
		} elsif ( ($genodir2 =~ m/prefix\=(.+)/) && ($genodir2 !~ m/suffix\=(.+)/) ) {
			$genodirpre2 = $1;
			$genodirsuf2 = "";
			if ($genodirpre2 eq "none") { $genodirpre2 = ""; }
		} elsif ( ($genodir2 !~ m/prefix\=(.+)/) && ($genodir2 =~ m/suffix\=(.+)/) ) {
			$genodirpre2 = "";
			$genodirsuf2 = $1;
			if ($genodirsuf2 eq "none") { $genodirsuf2 = ""; }
		}
		$genofdir2 = $maingdir2 . "/" . $genodirpre2 . $chr . $genodirsuf2;
	}
	if ($genoname2 =~ m/prefix\=(.+) suffix\=(.+)/) {
		$genopre2 = $1;
		$genosuf2 = $2;
		if ($genopre2 eq "none") { $genopre2 = ""; }
		if ($genosuf2 eq "none") { $genosuf2 = ""; }
	} elsif ( ($genoname2 =~ m/prefix\=(.+)/) && ($genoname2 !~ m/suffix\=(.+)/) ) {
		$genopre2 = $1;
		$genosuf2 = "";
		if ($genopre2 eq "none") { $genopre2 = ""; }
	} elsif ( ($genoname2 !~ m/prefix\=(.+)/) && ($genoname2 =~ m/suffix\=(.+)/) ) {
		$genopre2 = "";
		$genosuf2 = $1;
		if ($genosuf2 eq "none") { $genosuf2 = ""; }
	}
	$genofile2 = $genofdir2 . "/" . $genopre2 . $chr . $genosuf2;
	print "Genotype file : $genofile2\n";
	print LOG "Genotype file                : $genofile2\n";

	if ($option2 == 1) {
		# Compare all individual ID files per chromosome and use the IDs that are
		# present across all chromosomes
		if ($iddir2 eq "no dir") {
			# ID files are directly under mainidir
			$idfdir2 = $mainidir2;
		} elsif ($iddir2 ne "no dir") {
			if ($iddir2 eq "none") {
				$iddirpre2 = "";
				$iddirsuf2 = "";
			} elsif ($iddir2 =~ m/prefix\=(.+) suffix\=(.+)/) {
				$iddirpre2 = $1;
				$iddirsuf2 = $2;
				if ($iddirpre2 eq "none") { $iddirpre2 = ""; }
				if ($iddirsuf2 eq "none") { $iddirsuf2 = ""; }
			} elsif ( ($iddir2 =~ m/prefix\=(.+)/) && ($iddir2 !~ m/suffix\=(.+)/) ) {
				$iddirpre2 = $1;
				$iddirsuf2 = "";
				if ($iddirpre2 eq "none") { $iddirpre2 = ""; }
			} elsif ( ($iddir2 !~ m/prefix\=(.+)/) && ($iddir2 =~ m/suffix\=(.+)/) ) {
				$iddirpre2 = "";
				$iddirsuf2 = $1;
				if ($iddirsuf2 eq "none") { $iddirsuf2 = ""; }
			}
			$idfdir2 = $mainidir2 . "/" . $iddirpre2 . $chr . $iddirsuf2;
		}
		if ($idname2 =~ m/prefix\=(.+) suffix\=(.+)/) {
			$idpre2 = $1;
			$idsuf2 = $2;
			if ($idpre2 eq "none") { $idpre2 = ""; }
			if ($idsuf2 eq "none") { $idsuf2 = ""; }
		} elsif ( ($idname2 =~ m/prefix\=(.+)/) && ($idname2 !~ m/suffix\=(.+)/) ) {
			$idpre2 = $1;
			$idsuf2 = "";
			if ($idpre2 eq "none") { $idpre2 = ""; }
		} elsif ( ($idname2 !~ m/prefix\=(.+)/) && ($idname2 =~ m/suffix\=(.+)/) ) {
			$idpre2 = "";
			$idsuf2 = $1;
			if ($idsuf2 eq "none") { $idsuf2 = ""; }
		}
		$idfile2 = $idfdir2 . "/" . $idpre2 . $chr . $idsuf2;
		print "IDs of genotyped individuals : $idfile2\n";
		print LOG "IDs of genotyped individuals : $idfile2\n";

		# check individual ID files now
		(@list2, @idin2) = ();
		%freq2 = ();
		my $numchr2 = 0;
		if ($chrA !~ m/\s+/) {
			$numchr2 = $chre - $chrs + 1;
			if ($numchr2 > 1) {
				print "Checking if individual IDs specified in $idpre2" . $chr . "$idsuf2 are present in ID files for chromosomes $chrs\-$chre\...\n";
			} elsif ($numchr2 == 1) {
				# do nothing
			}
			for ($i=$chrs; $i<=$chre; $i++) {
				my $idftemp2 = "";
				if ($iddir2 eq "no dir") {
					$idftemp2 = $idfdir2 . "/" . $idpre2 . $i . $idsuf2;
				} else {
					$idftemp2 = $mainidir2 . "/" . $iddirpre2 . $i . $iddirsuf2 . "/" . $idpre2 . $i . $idsuf2;
				}
				open (IN2, "<$idftemp2") || die ("Could not open $idftemp2 file!\n");
				@list2 = <IN2>;
				close (IN2);
				foreach $line2 (@list2) {
					chomp $line2;
					$line2 =~ s/^\s+//g;
					$line2 =~ s/\s+$//g;
					next if (length ($line2) == 0);
					$freq2{$line2}++;
				}
			}
		} elsif ($chrA =~ m/\s+/) {
			$numchr2 = scalar(@chrA);
			if ($numchr2 > 1) {
				print "Checking if individual IDs specified in $idpre2" . $chr . "$idsuf2 are present in ID files for chromosomes " . join (" ", @chrA) . "...\n";
			} elsif ($numchr2 == 1) {
				# do nothing
			}
			foreach $i (@chrA) {
				my $idftemp2 = "";
				if ($iddir2 eq "no dir") {
					$idftemp2 = $idfdir2 . "/" . $idpre2 . $i . $idsuf2;
				} else {
					$idftemp2 = $mainidir2 . "/" . $iddirpre2 . $i . $iddirsuf2 . "/" . $idpre2 . $i . $idsuf2;
				}
				open (IN2, "<$idftemp2") || die ("Could not open $idftemp2 file!\n");
				@list2 = <IN2>;
				close (IN2);
				foreach $line2 (@list2) {
					chomp $line2;
					$line2 =~ s/^\s+//g;
					$line2 =~ s/\s+$//g;
					next if (length ($line2) == 0);
					$freq2{$line2}++;
				}
			}
		}


		# use the last list2 to check the individual IDs that are present in all ID files
		my $iderr2 = 0;
		foreach $line2 (@list2) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if (length ($line2) == 0);
			if ($freq2{$line2} == $numchr2) {
				push (@idin2, $line2);
			} elsif ($freq2{$line2} < $numchr2) {
				print "Check ID of individual $line2 in one of the ID files\n";
				$iderr2++;
			}
		}


		if ($iderr2 == 0) {
			print "  Individual IDs are present in all ID files\n";
		}

	} elsif ($option2 == 2) {
		# use the file supplied by the user as the $idin
		print "IDs of genotyped individuals : $idin2\n";
		print LOG "IDs of genotyped individuals     : $idin2\n";
		# $idin2 should also be $idfile2
		$idfile2 = $idin2;
		(@list2, @idin2) = ();
		open (IN2, "<$idfile2") || die ("Could not open $idfile2 file!\n");
		@list2 = <IN2>;
		close (IN2);
		foreach $line2 (@list2) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if (length ($line2) == 0);
			push (@idin2, $line2);
		}
	}
}

print "Option for MAF file : $mafopt\n";
print LOG "Option for MAF file          : $mafopt\n";
print "Output directory : $outdir\n\n";
print LOG "Output directory             : $outdir\n\n";

print LOG "LOG:\n\n";
##########

# Create exclusion hash
my %exclude = ();
my ($excfamid, $excid, $excdad, $excmom, $excsex) = "";
@list2 = ();
if ($exclu !~ m/none/i) {
	open (IN3, "<$exclu") || die ("Could not open $exclu file!\n");
	@list3 = <IN3>;
	close (IN3);
	print "Genotypes of the following individual(s) will be excluded:\n";
	print LOG "Genotypes of the following individual(s) were excluded:\n";
	foreach $line3 (@list3) {
		chomp $line3;
		$line3 =~ s/^\s+//g;
		$line3 =~ s/\s+$//g;
		next if (length($line3) == 0);
		($excfamid, $excid, $excdad, $excmom, $excsex) = split (" ", $line3);
		if ($excid =~ m/(\w+)[\.|\-|\_](\w+)/) {
			$excid = $2;
		}
		if ($excdad =~ m/(\w+)[\.|\-|\_](\w+)/) {
			$excdad = $2;
		}
		if ($excmom =~ m/(\w+)[\.|\-|\_](\w+)/) {
			$excmom = $2;
		}
		$exclude{$excfamid}{$excid}++;
		print "   $excfamid$,$excid$,$excdad$,$excmom$,$excsex\n";
		print LOG "   $excfamid$,$excid$,$excdad$,$excmom$,$excsex\n";
	}
	print LOG "\n";
}

# Setup gl_auto-format pedigree files

my @families = ();
my ($id1, $lastparent1, $style) = "";
my ($fam, $fam2, $rest, $family, $id) = "";
my ($parent1, $parent2, $sex, $famsize, $tfamsize) = 0;
my (@fam, @idlist, @parent1) = ();
my (%fam, %sex, %parent1, %parent2, %in_idlist) = ();

open (IN4, "<$pedfile") || die ("Could not open $pedfile file!\n");
@fam = ();
while (defined ($line4 = <IN4>)) {
		chomp $line4;
		$line4 =~ s/^\s+//g;
		$line4 =~ s/\s+$//g;
		next if ( ($line4 =~ m/^\#/) || (length($line4) == 0) );
		($fam, $rest) = split(" ", $line4, 2);
		$fam{$fam}++;
		next if ($fam{$fam} > 1);
		push (@fam, $fam);
}
close (IN4);

print "\nHere are the family IDs in your pedigree file:\n";
print join (" ", @fam);
print "\n";

print "\nSetting up MORGAN-format files needed to run gl_auto...\n";

my ($outfile, $mnumout, $arecout, $siout, $logfile, $errfile, $pedoutdir) = "";
my ($setuplog, $setuperr, $genoout, $infofile, $parout, $fglout, $miout, $seedfile, $ftind) = "";
my ($marker2, $type2, $rest2) = "";
my ($chr2, $genloc2, $phypos2, $mc2, $maf2, $maf3, $mafdiff) = 0;
my (@glautoped, @map, @markername, @marker, @mrkrgloc, @markersort, @mark_all, @mark_count, @marknum) = ();
my (%gloc2, %ppos2, %mrkrg, %mrkrp, %type2, %panel, %maf2, %maf3) = ();

# Create hash using panel (chromosome, marker, genetic location, physical position, type [SNP|STR])
my ($snptgen, $snptind, $ststgen, $ststind, $id5, $id7) = "";
my ($chr6, $marker6, $geno6) = "";
my ($count5, $count6, $count7, $count8) = 0;
my (@idwgeno, @geno6, @geno7) = ();
my (@idwgeno2, @geno8, @geno9) = ();
my (%idindex, %family, %idindex2, %family2, %markgen, %recodegen, %markfreq, %markfreq1, %marknum) = ();
my ($num_ind, $num_ind2, $num_ind3, $num_ind4) = 0;
my ($total, $nogen, $freq, $tfreq) = 0;
my (%markallele, %markrecAF, %marktotalAF, %markwithgen, %marknogen, %marktoterr, %marktype) = ();

$ftind    = $popinfodir . "/chr" . $chr . ".tind";	# *tind file for gl_auto-format genotype file
$infofile = $popinfodir . "/chr" . $chr . ".info";	# INFO (alleles and AFs)

##########
my @exclufam = ();
my %exclufam = ();
if ($famexc !~ m/none/i) {
	open (IN14, "<$famexc") || die ("Could not open $famexc file!\n");
	while (defined ($line14 = <IN14>)) {
		chomp $line14;
		$line14 =~ s/^\s+//g;
		$line14 =~ s/\s+$//g;
		next if ( ($line14 =~ m/^\#/) || (length($line14) == 0) );
		$exclufam{$line14}++;
		push (@exclufam, $line14 . " exclusion_file");
	}
}
# Create hash for families that will be excluded (<3 genotyped individuals)
my ($checkfam, $famid10, $id10) = "";
my $countgen = 0;
foreach $checkfam (@fam) {
	open (IN10, "<$idfile") || die ("Could not open $idfile file!\n");
	while (defined ($line10 = <IN10>)) {
		chomp $line10;
		$line10 =~ s/^\s+//g;
		$line10 =~ s/\s+$//g;
		next if ( ($line10 =~ m/^\#/) || (length($line10) == 0) );
		($famid10, $id10) = split(/_/, $line10);
		if ($famid10 !~ m/^$checkfam$/) {
			next;
		} elsif ($famid10 =~ m/^$checkfam$/) {
			# Start counting the number of genotyped individuals
			$countgen++;
		}
	}
	if ($countgen >= 3) {
		# do nothing
	} else {
		$exclufam{$checkfam}++;
		push (@exclufam, $checkfam . " " . $countgen);
	}
	$countgen = 0;
}
close (IN10);

if (scalar(@exclufam) >= 1) {
	@exclufam = sort @exclufam;
	print "The following families will be excluded (<3 genotyped individuals and/or from exclusion file):\n";
	print "FamilyID$,Number_of_Genotyped_Individuals_or_Exclusion_File\n";
	print join ("\n", @exclufam);
	print "\n\n";
	print LOG "The following families were excluded (<3 genotyped individuals and/or from exclusion file):\n";
	print LOG "FamilyID$,Number_of_Genotyped_Individuals_or_Exclusion_File\n";
	print LOG join ("\n", @exclufam);
	print LOG "\n\n";
}
##########

### 03/19/2014 ##############
# New location of opening map file
print "\nPanel: $mapfile\n\n";
open (IN9, "<$mapfile") || die ("Could not open $mapfile file!\n");
@map = ();
my ($mcount, $glcount) = 0;
my $remarks = "";
my ($a1_1KG, $a2_1KG, $a1_data, $a2_data, $afdiff) = "";
my (%a1_1KG, %a2_1KG, %a1_data, %a2_data, %afdiff) = ();
my (@data, @strand, @si) = ();
while (defined ($line9 = <IN9>)) {
	chomp $line9;
	$line9 =~ s/^\s+//g;
	$line9 =~ s/\s+$//g;
	next if ( ($line9 =~ m/^\#/) || (length($line9) == 0) );
	($chr2, $marker2, $genloc2, $phypos2, $type2, $mc2, $maf2, $rest2) = "";
	($chr2, $marker2, $genloc2, $phypos2, $type2, $mc2, $maf2, $rest2) = split(/\s+/, $line9, 8);
	my @maf3 = split(/\s+/, $rest2);
	$maf3    = $maf3[2]; # MAF of marker in dataset
	$a1_1KG  = $maf3[5];
	$a2_1KG  = $maf3[6];
	$a1_data = $maf3[7];
	$a2_data = $maf3[8];
	$genloc2 = sprintf("%.6f", $genloc2);
	$gloc2{$chr2}{$marker2} = $genloc2;
	$ppos2{$chr2}{$marker2} = $phypos2;
	$type2{$chr2}{$marker2} = $type2;
	$mrkrg{$chr2}{$genloc2} = $marker2;# allows us to sort by genloc then find the corresponding marker name
	$mrkrp{$chr2}{$phypos2} = $marker2;
	$maf2{$chr2}{$genloc2}  = $maf2;
	$maf2{$chr2}{$marker2}  = $maf2;
	$maf3{$chr2}{$genloc2}  = $maf3;
	$maf3{$chr2}{$marker2}  = $maf3;
	
	$a1_1KG{$chr2}{$genloc2}  = $a1_1KG;
	$a1_1KG{$chr2}{$marker2}  = $a1_1KG;

	$a2_1KG{$chr2}{$genloc2}  = $a2_1KG;
	$a2_1KG{$chr2}{$marker2}  = $a2_1KG;

	$a1_data{$chr2}{$genloc2}  = $a1_data;
	$a1_data{$chr2}{$marker2}  = $a1_data;

	$a2_data{$chr2}{$genloc2}  = $a2_data;
	$a2_data{$chr2}{$marker2}  = $a2_data;

	# Exclude markers with strand inconsistency
	# Check if both alleles exist in 1000G
	my $KGalleles1 = "$a1_1KG$,$a2_1KG"; # minor allele is 1 (OK)
	my $KGalleles2 = "$a2_1KG$,$a1_1KG"; # minor allele is 2 (swapped)
	(@data, @si) = ();
	if ($a1_data ne "none") {
		push (@data, $a1_data);
	}
	if ($a2_data ne "none") {
		push (@data, $a2_data);
	}
	my $datauniq = join (" " , @data);
	if ( (scalar(@data) == 2) && ($datauniq ne $KGalleles1) && ($datauniq ne $KGalleles2) ) {
		#print join (" " , @unique);
		#print "\n";
		
		
		my $strand = "$chr2$,$marker2$,$genloc2$,$phypos2$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data";
		push (@strand, $strand);
		push (@si, $marker2);
	} elsif ( (scalar(@data) == 1) && ($datauniq !~ m/$KGalleles1/) ) {
		my $strand = "$chr2$,$marker2$,$genloc2$,$phypos2$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data";
		push (@strand, $strand);
		push (@si, $marker2);
	}
	$mcount++;
	$glcount++;
	# Create hash for MORGAN genotype file allele frequencies (markfreq1 hash is for 1KG and external MAF)
	my ($majf, $bothf) = "";
	if ($maf2 !~ m/NA/) {
		$maf2 = sprintf("%.6f", $maf2);
		$majf = sprintf("%.6f", 1-$maf2);
		$bothf = "$maf2$,$majf";
		#print "$marker2$,$bothf\n";
		$markfreq1{$marker2} = $bothf;
		$markfreq1{$genloc2} = $bothf;
		if ($mafopt =~ m/1KG/) {
			if (scalar(@si) == 0) {
				push (@marknum, $marker2);
				$remarks = "OK";
				push (@markername, $marker2);
				push (@mrkrgloc, $genloc2);	# @mrkrgloc can be used for gl_auto-format genotype file
				$panel{$marker2}++;
				my $mtemp = "$chr2$,$marker2$,$genloc2$,$phypos2$,$maf2$,$maf3$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data$,$mcount$,$glcount$,$remarks";
				$marknum{$marker2} = $mtemp;
			} elsif (scalar(@si) == 1) {
				push (@marknum, $marker2);
				$remarks = "Excluded_due_to_strand_inconsistency";
				$glcount--;
				my $mtemp = "$chr2$,$marker2$,$genloc2$,$phypos2$,$maf2$,$maf3$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data$,$mcount$,NA$,$remarks";
				$marknum{$marker2} = $mtemp;
				@si = ();
			}
		} elsif ($mafopt =~ m/dataset/) {
			if ($maf3 !~ m/NA/) {
				push (@marknum, $marker2);
				$remarks = "OK";
				push (@markername, $marker2);
				push (@mrkrgloc, $genloc2);	# @mrkrgloc can be used for gl_auto-format genotype file
				$panel{$marker2}++;
				my $mtemp = "$chr2$,$marker2$,$genloc2$,$phypos2$,$maf2$,$maf3$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data$,$mcount$,$glcount$,$remarks";
				$marknum{$marker2} = $mtemp;
			} elsif ($maf3 =~ m/NA/) {
				push (@marknum, $marker2);
				$remarks = "Excluded_due_to_absence_of_dataset_MAF";
				$glcount--;
				my $mtemp = "$chr2$,$marker2$,$genloc2$,$phypos2$,$maf2$,$maf3$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data$,$mcount$,NA$,$remarks";
				$marknum{$marker2} = $mtemp;
			}
		}
	} elsif ($maf2 =~ m/NA/) {
		$maf2 = "NA";
		$majf = "NA";
		$bothf = "$maf2$,$majf";
		$markfreq1{$marker2} = $bothf;
		$markfreq1{$genloc2} = $bothf;
		if ($mafopt =~ m/1KG/) {
			if (scalar(@si) == 0) {
				push (@marknum, $marker2);
				$remarks = "Excluded_due_to_absence_of_1KG_MAF";
				$glcount--;
				my $mtemp = "$chr2$,$marker2$,$genloc2$,$phypos2$,$maf2$,$maf3$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data$,$mcount$,NA$,$remarks";
				$marknum{$marker2} = $mtemp;
			} elsif (scalar(@si) == 1) {
				push (@marknum, $marker2);
				$remarks = "Excluded_due_to_strand_inconsistency_and_absence_of_1KG_MAF";
				$glcount--;
				my $mtemp = "$chr2$,$marker2$,$genloc2$,$phypos2$,$maf2$,$maf3$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data$,$mcount$,NA$,$remarks";
				$marknum{$marker2} = $mtemp;
				@si = ();
			}
		} elsif ($mafopt =~ m/dataset/) {
			if ($maf3 !~ m/NA/) {
				push (@marknum, $marker2);
				$remarks = "OK";
				push (@markername, $marker2);
				push (@mrkrgloc, $genloc2);	# @mrkrgloc can be used for gl_auto-format genotype file
				$panel{$marker2}++;
				my $mtemp = "$chr2$,$marker2$,$genloc2$,$phypos2$,$maf2$,$maf3$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data$,$mcount$,$glcount$,$remarks";
				$marknum{$marker2} = $mtemp;
			} elsif ($maf3 =~ m/NA/) {
				push (@marknum, $marker2);
				$remarks = "Excluded_due_to_absence_of_dataset_MAF";
				$glcount--;
				my $mtemp = "$chr2$,$marker2$,$genloc2$,$phypos2$,$maf2$,$maf3$,$a1_1KG$,$a2_1KG$,$a1_data$,$a2_data$,$mcount$,NA$,$remarks";
				$marknum{$marker2} = $mtemp;
			}
		}
	}
}
close (IN9);
###############
my (@unique, @arep, @arec) = ();
my %seen2 = ();
my ($allelerep, $arep) = 0;
if ( (defined($numtype)) && ($numtype == 1) && (defined($mrkrtype)) ) {
	($count5, $count6, $count7) = 0;
	if ($mrkrtype =~ m/SNP/i) {
		$snptgen = $genofile;
		$snptind = $idfile;
	} elsif ($mrkrtype =~ m/STR/i) {
		$ststgen = $genofile;
		$ststind = $idfile;
	}
	system ("cat $idfile > $ftind");
	# Create a hash of marker type, genotypes, and individuals
	if ( (defined($snptgen)) && (defined($snptind)) ) {
		open (IN5, "<$snptind") || die ("Could not open $snptind file!\n");
		open (IN6, "<$snptgen") || die ("Could not open $snptgen file!\n");
	} elsif ( (defined($ststgen)) && (defined($ststind)) ) {
		open (IN5, "<$ststind") || die ("Could not open $ststind file!\n");
		open (IN6, "<$ststgen") || die ("Could not open $ststgen file!\n");
	}
	$count5 = 0;
	while (defined ($line5 = <IN5>)) {
		chomp $line5;
		$line5 =~ s/^\s+//g;
		$line5 =~ s/\s+$//g;
		next if ( ($line5 =~ m/^\#/) || (length($line5) == 0) );
		my ($famid5, $indiv5) = split(/\.|\-|\_/, $line5);
		$id5 = "$famid5\_$indiv5";
		push (@idwgeno, $id5);
		$idindex{$count5} = $id5;
		$family{$id5} = $famid5;
		$count5++;
		#if ($count5 == 5) {
		#	exit;
		#}
	}
	$num_ind = $#idwgeno;
	# Initialize structure to hold allele names and counts for markers of all individuals
	my ($a1, $a2, $a1a, $a2a, $cline6) = 0;
	my ($geno6a, $geno6b, $markergeno, $allele) = "";
	my ($geno7a, $geno7b, $recodegeno) = "";
	my (@uniq, @recAF, @freq) = ();
	my (%uniq_al, %recode, %seen, %orig) = ();
	print "Calculating allele frequencies...";
	while (defined ($line6 = <IN6>)) {
		chomp $line6;
		$line6 =~ s/^\s+//g;
		$line6 =~ s/\s+$//g;
		next if ( ($line6 =~ m/^\#/) || (length($line6) == 0) );
		($chr6, $marker6, $geno6) = split(/\s+/, $line6, 3);
#if ($line6 =~ m/rs1024217/) {
#print "\nline6\=$line6\n";
#	if (!defined($panel{$marker6})) {
#	print "$marker6 is not in the panel\n";
#	} elsif (defined($panel{$marker6})) {
#	print "$marker6 is in the panel\n";
#	}
#}
		if (!defined($panel{$marker6})) {
			next;
		}
		
		
		($a1, $a2, $count6) = 0;
		@geno6 = ();
		@geno6 = split (/\s+/, $geno6);
		for ($count6=0; $count6<=$num_ind; $count6++) {
			$a1 = ($count6*2);
			$a2 = ($count6*2) + 1;
			$geno6a = $geno6[$a1];
			$geno6b = $geno6[$a2];
			$markergeno = $geno6a." ".$geno6b;
			$markgen{$idindex{$count6}}{$marker6} = $markergeno;
		}
		($a1a, $a2a, $count7) = 0;
		if ( (defined($mrkrtype)) && ($mrkrtype =~ m/SNP/i) ) {
			$marktype{$marker6} = "SNP";
			(@uniq, @geno7) = ();
			(%seen, %orig, %uniq_al) = ();
			
			### IF ELSEIF loop for the different ways alleles are coded
			if ( (scalar(grep(/[0|1|2|\-]/, @geno6)) >= 1) && (scalar(grep(/[A|C|G|T]/i, @geno6)) == 0) ) {
				# Don't recode alleles
				@unique = ();
				%seen2 = ();
				foreach my $value (@geno6) {
					next if $value eq "0";
					if (!exists($seen2{$value})) {
						push (@unique, $value);
						$seen2{$value}++;
					}
				}
				(@uniq, @geno7, @arep) = ();
				(%seen, %orig, %recode, %uniq_al) = ();
				if (scalar(@unique) > 2) {
					print "unique=" . join (" ", @unique) . "\n";
					print "There are more than 2 alleles (" . join (" ", @unique) . ") for $marker6\. Please check your data\n";
					exit;
				} elsif (scalar(@unique) == 0) {
					# No data for this marker
					#print "Missing data for $marker6\n";
					my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$,0$,0";
					push (@arec, $temprec);
				}
				foreach $allele (@geno6) {
					if (!exists($seen{$allele})) {
						$seen{$allele}++;
						$uniq_al{$allele}++;
						push (@uniq, $allele);
					} elsif (exists($seen{$allele})) {
						$uniq_al{$allele}++;
					}
					push (@geno7, $allele);
					if (scalar(@geno7) == 2) {
						$geno7a = $geno7[0];
						$geno7b = $geno7[1];
						$recodegeno = $geno7a." ".$geno7b;
						$a1a = ($count7-1)/2;
						$recodegen{$idindex{$a1a}}{$marker6} = $recodegeno;
						@geno7 = ();
					}
					$count7++;
				}
			} elsif ( (scalar(grep(/[A|C|G|T|\-|0]/i, @geno6)) >= 1) && (scalar(grep(/[1|2]/, @geno6)) == 0) ) {
				# Recode alleles from 1 onwards
				# Make sure that the allele recoded to allele 1 is the minor allele
				@unique = ();
				%seen2 = ();
				foreach my $value (@geno6) {
					next if $value eq "0";
					if (!exists($seen2{$value})) {
						push (@unique, $value);
						$seen2{$value}++;
					}
				}
				(@uniq, @geno7, @arep) = ();
				(%seen, %orig, %recode, %uniq_al) = ();
				($allelerep, $arep) = 0;
				if (scalar(@unique) > 2) {
					#print "unique=" . join (" ", @unique) . "\n";
					print "There are more than 2 alleles (" . join (" ", @unique) .") for $marker6\. Please check your data\n";
					exit;
				} elsif (scalar(@unique) == 0) {
					# No data for this marker
					print "Missing data for $marker6\n";
					my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$,0$,0";
					push (@arec, $temprec);
				}
				foreach $allele (@geno6) {
					if ( (!exists($seen{$allele})) && (!exists($recode{$allele})) ) {
						$seen{$allele}++;
						if ( ($allele =~ m/^[0|\-)]/) || ($allele eq "NA") ){
							$recode{$allele} = "0";
						} elsif ( ($allele !~ m/^[0|\-)]/) && ($allele ne "NA") ){
							if ($allele eq $a1_1KG{$chr6}{$marker6}) {
								$recode{$allele} = "1";
							} elsif ($allele eq $a2_1KG{$chr6}{$marker6}) {
								$recode{$allele} = "2";
							} else {
								
								print "Cannot match any allele $allele of $marker6 with 1KG alleles $a1_1KG{$chr6}{$marker6} $a2_1KG{$chr6}{$marker6}\n";
								exit;
							}
							if (scalar(@unique) == 1) {
								if ($allelerep < 1) {
									push (@arep, "$allele $recode{$allele}");
									$allelerep++;
								}
								if ($allelerep == 1) {
									my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$," .join (" ", @arep);
									push (@arec, $temprec);
									@arep = ();
									$arep++;
								}
							} elsif (scalar(@unique) == 2) {
								if ($allelerep < 2) {
									push (@arep, "$allele $recode{$allele}");
									$allelerep++;
								}
								if ($allelerep == 2) {
									my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$," .join (" ", @arep);
									push (@arec, $temprec);
									@arep = ();
									$arep++;
								}
							}
						}
						$uniq_al{$recode{$allele}}++;
						$orig{$recode{$allele}} = $allele;
						push (@uniq, $allele);
					} elsif ( (exists($seen{$allele})) && (exists($recode{$allele})) ) {
						$uniq_al{$recode{$allele}}++;
						$orig{$recode{$allele}} = $allele;
					}
					push (@geno7, $recode{$allele});
					if (scalar(@geno7) == 2) {
						$geno7a = $geno7[0];
						$geno7b = $geno7[1];
						$recodegeno = $geno7a." ".$geno7b;
						$a1a = ($count7-1)/2;
						$recodegen{$idindex{$a1a}}{$marker6} = $recodegeno;
						@geno7 = ();
					}
					$count7++;
				}
			}
		} elsif ( (defined($mrkrtype)) && ($mrkrtype =~ m/STR/i) ) {
			$marktype{$marker6} = "STR";
			# Recode alleles from 1 onwards
			my $stsrecode = 0;
			(@uniq, @geno7) = ();
			(%seen, %orig, %recode, %uniq_al) = ();
			foreach $allele (@geno6) {
				if ( (!exists($seen{$allele})) && (!exists($recode{$allele})) ) {
					$seen{$allele}++;
					if ( ($allele =~ m/^[0|\-)]/) || ($allele eq "NA") ){
						$recode{$allele} = "0";
					} elsif ( ($allele !~ m/^[0|\-)]/) && ($allele ne "NA") ){
						$stsrecode++;
						$recode{$allele} = $stsrecode;
					}
					$uniq_al{$recode{$allele}}++;
					$orig{$recode{$allele}} = $allele;
					push (@uniq, $allele);
				} elsif ( (exists($seen{$allele})) && (exists($recode{$allele})) ) {
					$uniq_al{$recode{$allele}}++;
					$orig{$recode{$allele}} = $allele;
				}
				push (@geno7, $recode{$allele});
				if (scalar(@geno7) == 2) {
					$geno7a = $geno7[0];
					$geno7b = $geno7[1];
					$recodegeno = $geno7a." ".$geno7b;
					$a1a = ($count7-1)/2;
					$recodegen{$idindex{$a1a}}{$marker6} = $recodegeno;
					@geno7 = ();
				}
				$count7++;
			}
		}
		$cline6++;
		($total, $nogen, $tfreq) = 0;

		
		$markallele{$marker6} = join (" ", @uniq);
		foreach my $key (sort keys %uniq_al) {
			if ($key =~ m/^[0|\-|NA]/) {
				$nogen = $uniq_al{$key}/2;
			} elsif ($key !~ m/^[0|\-|NA]/) {
				$total += $uniq_al{$key};
			}
		}
		foreach my $key (sort keys %uniq_al) {
			if ($key =~ m/^[0|\-|NA]/) {
				if ( (defined($mrkrtype)) && ($mrkrtype =~ m/SNP/i) ) {
					if (defined($orig{$key})) {
						push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
					} elsif (!defined($orig{$key})) {
						push (@recAF, "$key$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
					}
				} elsif ( (defined($mrkrtype)) && ($mrkrtype =~ m/STR/i) ) {
					push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
				}
			} elsif ($key !~ m/^[0|\-|NA]/) {
				$freq = sprintf ("%.6f", ($uniq_al{$key}/$total) );
				push (@freq, $freq);
				$tfreq += $freq;
				if ( (defined($mrkrtype)) && ($mrkrtype =~ m/SNP/i) ) {
					if (defined($orig{$key})) {
						push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,$total$,$freq");
					} elsif (!defined($orig{$key})) {
						push (@recAF, "$key$,$key$,$uniq_al{$key}$,$total$,$freq");
					}
				} elsif ( (defined($mrkrtype)) && ($mrkrtype =~ m/STR/i) ) {
					push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,$total$,$freq");
				}
			}
		}
		$markrecAF{$marker6} = join ("\n", @recAF);
		if (defined($tfreq)) {
			$tfreq = sprintf ("%.6f", $tfreq);
		}
		$markfreq{$marker6} = join (" ", @freq);
		my $num_ind2 = $total/2;
		if (!defined($nogen)) { $nogen = 0; }
		my $num_indf = $num_ind + 1;
		if ($num_ind == ($num_ind2 + $nogen - 1) ) {
			# do nothing
		} elsif ($num_ind != ($num_ind2 + $nogen - 1) ) {
			print "Note: Total number of individuals is not equal to $num_indf\n";
			$marktoterr{$marker6} = "Note: Total number of individuals is not equal to $num_indf";
		}
		$marktotalAF{$marker6} = $tfreq;
		$markwithgen{$marker6} = $num_ind2;
		$marknogen{$marker6}   = $nogen;
		($total, $nogen, $tfreq) = 0;
		(@uniq, @recAF, @freq) = ();
		%uniq_al = ();
	}
	print "done\n";

} elsif ( (defined($numtype)) && ($numtype == 2) ) {
	# Combine genotype files of SNPs and STRs using the *.tgen and *.tind files
	print LOG "AFs and combined *.tind      : $popinfodir\n\n";
	if ( (defined($mrkrtype)) && (defined($mrkrtype2)) ) {
		if ($mrkrtype =~ m/SNP/i) {
			$snptgen = $genofile;
			$snptind = $idfile;
		} elsif ($mrkrtype =~ m/STR/i) {
			$ststgen = $genofile;
			$ststind = $idfile;
		}
		if ($mrkrtype2 =~ m/SNP/i) {
			$snptgen = $genofile2;
			$snptind = $idfile2;
		} elsif ($mrkrtype2 =~ m/STR/i) {
			$ststgen = $genofile2;
			$ststind = $idfile2;
		}
	}
	system ("cat $snptind $ststind > $ftind");
	# Create a hash of marker type, genotypes, and individuals
	if ( (defined($snptgen)) && (defined($snptind)) ) {
		open (IN5, "<$snptind") || die ("Could not open $snptind file!\n");
		open (IN6, "<$snptgen") || die ("Could not open $snptgen file!\n");
	}
	if ( (defined($ststgen)) && (defined($ststind)) ) {
		open (IN7, "<$ststind") || die ("Could not open $ststind file!\n");
		open (IN8, "<$ststgen") || die ("Could not open $ststgen file!\n");
	}
	$count5 = 0;
	while (defined ($line5 = <IN5>)) {
		chomp $line5;
		$line5 =~ s/^\s+//g;
		$line5 =~ s/\s+$//g;
		next if ( ($line5 =~ m/^\#/) || (length($line5) == 0) );
		my ($famid5, $indiv5) = split(/\.|\-|\_/, $line5);
		$id5 = "$famid5\_$indiv5";
		push (@idwgeno, $id5);
		$idindex{$count5} = $id5;
		$family{$id5} = $famid5;
		$count5++;
	}
	$num_ind3 = $#idwgeno;
	$count8 = 0;
	while (defined ($line7 = <IN7>)) {
		chomp $line7;
		$line7 =~ s/^\s+//g;
		$line7 =~ s/\s+$//g;
		next if ( ($line7 =~ m/^\#/) || (length($line7) == 0) );
		my ($famid7, $indiv7) = split(/\.|\-|\_/, $line7);
		$id7 = "$famid7\_$indiv7";
		push (@idwgeno2, $id7);
		$idindex2{$count8} = $id7;
		$family2{$id7} = $famid7;
		$count8++;
	}
	$num_ind4 = $#idwgeno2;

	my ($a1, $a2, $a1a, $a2a, $cline6) = 0;
	my ($geno6a, $geno6b, $markergeno, $allele) = "";
	my ($geno7a, $geno7b, $recodegeno) = "";
	my (@uniq, @recAF, @freq) = ();
	my (%uniq_al, %recode, %seen, %orig) = ();
	print "Calculating allele frequencies...";
	while (defined ($line6 = <IN6>)) {
		chomp $line6;
		$line6 =~ s/^\s+//g;
		$line6 =~ s/\s+$//g;
		next if ( ($line6 =~ m/^\#/) || (length($line6) == 0) );
		($chr6, $marker6, $geno6) = split(" ", $line6, 3);
		if (!defined($panel{$marker6})) { next; }
		($a1, $a2, $count6) = 0;
		@geno6 = ();
		@geno6 = split (/\t|\s+/, $geno6);
		for ($count6=0; $count6<=$num_ind3; $count6++) {
			$a1 = ($count6*2);
			$a2 = ($count6*2) + 1;
			$geno6a = $geno6[$a1];
			$geno6b = $geno6[$a2];
			$markergeno = $geno6a." ".$geno6b;
			$markgen{$idindex{$count6}}{$marker6} = $markergeno;
		}
		($a1a, $a2a, $count7) = 0;
		if ( (defined($mrkrtype)) && ($mrkrtype =~ m/SNP/i) ) {
			$marktype{$marker6} = "SNP";
			(@uniq, @geno7) = ();
			(%seen, %orig, %uniq_al) = ();
			### IF ELSEIF loop for the different ways alleles are coded
			if ( (scalar(grep(/[0|1|2|\-]/, @geno6)) >= 1) && (scalar(grep(/[A|C|G|T]/i, @geno6)) == 0) ) {
				# Don't recode alleles
				@unique = ();
				%seen2 = ();
				foreach my $value (@geno6) {
					next if $value eq "0";
					if (!exists($seen2{$value})) {
						push (@unique, $value);
						$seen2{$value}++;
					}
				}
				(@uniq, @geno7, @arep) = ();
				(%seen, %orig, %recode, %uniq_al) = ();
				if (scalar(@unique) > 2) {
					print "unique=" . join (" ", @unique) . "\n";
					print "There are more than 2 alleles (" . join (" ", @unique) . ") for $marker6\. Please check your data\n";
					exit;
				} elsif (scalar(@unique) == 0) {
					# No data for this marker
					#print "Missing data for $marker6\n";
					my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$,0$,0";
					push (@arec, $temprec);
				}
				foreach $allele (@geno6) {
					if (!exists($seen{$allele})) {
						$seen{$allele}++;
						$uniq_al{$allele}++;
						push (@uniq, $allele);
					} elsif (exists($seen{$allele})) {
						$uniq_al{$allele}++;
					}
					push (@geno7, $allele);
					if (scalar(@geno7) == 2) {
						$geno7a = $geno7[0];
						$geno7b = $geno7[1];
						$recodegeno = $geno7a." ".$geno7b;
						$a1a = ($count7-1)/2;
						$recodegen{$idindex{$a1a}}{$marker6} = $recodegeno;
						@geno7 = ();
					}
					$count7++;
				}
			} elsif ( (scalar(grep(/[A|C|G|T|\-|0]/i, @geno6)) >= 1) && (scalar(grep(/[1|2]/, @geno6)) == 0) ) {
				# Recode alleles from 1 onwards
				# Make sure that the allele recoded to allele 1 is the minor allele
				@unique = ();
				%seen2 = ();
				foreach my $value (@geno6) {
					next if $value eq "0";
					if (!exists($seen2{$value})) {
						push (@unique, $value);
						$seen2{$value}++;
					}
				}
				(@uniq, @geno7, @arep) = ();
				(%seen, %orig, %recode, %uniq_al) = ();
				($allelerep, $arep) = 0;
				if (scalar(@unique) > 2) {
					#print "unique=" . join (" ", @unique) . "\n";
					print "There are more than 2 alleles (" . join (" ", @unique) .") for $marker6\. Please check your data\n";
					exit;
				} elsif (scalar(@unique) == 0) {
					# No data for this marker
					print "Missing data for $marker6\n";
					my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$,0$,0";
					push (@arec, $temprec);
				}
				foreach $allele (@geno6) {
					if ( (!exists($seen{$allele})) && (!exists($recode{$allele})) ) {
						$seen{$allele}++;
						if ( ($allele =~ m/^[0|\-)]/) || ($allele eq "NA") ){
							$recode{$allele} = "0";
						} elsif ( ($allele !~ m/^[0|\-)]/) && ($allele ne "NA") ){
							if ($allele eq $a1_1KG{$chr6}{$marker6}) {
								$recode{$allele} = "1";
							} elsif ($allele eq $a2_1KG{$chr6}{$marker6}) {
								$recode{$allele} = "2";
							} else {
								
								print "Cannot match any allele $allele of $marker6 with 1KG alleles $a1_1KG{$chr6}{$marker6} $a2_1KG{$chr6}{$marker6}\n";
								exit;
							}
							if (scalar(@unique) == 1) {
								if ($allelerep < 1) {
									push (@arep, "$allele $recode{$allele}");
									$allelerep++;
								}
								if ($allelerep == 1) {
									my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$," .join (" ", @arep);
									push (@arec, $temprec);
									@arep = ();
									$arep++;
								}
							} elsif (scalar(@unique) == 2) {
								if ($allelerep < 2) {
									push (@arep, "$allele $recode{$allele}");
									$allelerep++;
								}
								if ($allelerep == 2) {
									my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$," .join (" ", @arep);
									push (@arec, $temprec);
									@arep = ();
									$arep++;
								}
							}
						}
						$uniq_al{$recode{$allele}}++;
						$orig{$recode{$allele}} = $allele;
						push (@uniq, $allele);
					} elsif ( (exists($seen{$allele})) && (exists($recode{$allele})) ) {
						$uniq_al{$recode{$allele}}++;
						$orig{$recode{$allele}} = $allele;
					}
					push (@geno7, $recode{$allele});
					if (scalar(@geno7) == 2) {
						$geno7a = $geno7[0];
						$geno7b = $geno7[1];
						$recodegeno = $geno7a." ".$geno7b;
						$a1a = ($count7-1)/2;
						$recodegen{$idindex{$a1a}}{$marker6} = $recodegeno;
						@geno7 = ();
					}
					$count7++;
				}
			}
		} elsif ( (defined($mrkrtype)) && ($mrkrtype =~ m/STR/i) ) {
			$marktype{$marker6} = "STR";
			# Recode alleles from 1 onwards
			my $stsrecode = 0;
			(@uniq, @geno7) = ();
			(%seen, %orig, %recode, %uniq_al) = ();
			foreach $allele (@geno6) {
				if ( (!exists($seen{$allele})) && (!exists($recode{$allele})) ) {
					$seen{$allele}++;
					if ( ($allele =~ m/^[0|\-)]/) || ($allele eq "NA") ){
						$recode{$allele} = "0";
					} elsif ( ($allele !~ m/^[0|\-)]/) && ($allele ne "NA") ){
						$stsrecode++;
						$recode{$allele} = $stsrecode;
					}
					$uniq_al{$recode{$allele}}++;
					$orig{$recode{$allele}} = $allele;
					push (@uniq, $allele);
				} elsif ( (exists($seen{$allele})) && (exists($recode{$allele})) ) {
					$uniq_al{$recode{$allele}}++;
					$orig{$recode{$allele}} = $allele;
				}
				push (@geno7, $recode{$allele});
				if (scalar(@geno7) == 2) {
					$geno7a = $geno7[0];
					$geno7b = $geno7[1];
					$recodegeno = $geno7a." ".$geno7b;
					$a1a = ($count7-1)/2;
					$recodegen{$idindex{$a1a}}{$marker6} = $recodegeno;
					@geno7 = ();
				}
				$count7++;
			}
		}
		$cline6++;
		($total, $nogen, $tfreq) = 0;

		$markallele{$marker6} = join (" ", @uniq);
		foreach my $key (sort keys %uniq_al) {
			if ($key =~ m/^[0|\-|NA]/) {
				$nogen = $uniq_al{$key}/2;
			} elsif ($key !~ m/^[0|\-|NA]/) {
				$total += $uniq_al{$key};
			}
		}
		foreach my $key (sort keys %uniq_al) {
			if ($key =~ m/^[0|\-|NA]/) {
				if ( (defined($mrkrtype)) && ($mrkrtype =~ m/SNP/i) ) {
					if (defined($orig{$key})) {
						push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
					} elsif (!defined($orig{$key})) {
						push (@recAF, "$key$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
					}
				} elsif ( (defined($mrkrtype)) && ($mrkrtype =~ m/STR/i) ) {
					push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
				}
			} elsif ($key !~ m/^[0|\-|NA]/) {
				$freq = sprintf ("%.6f", ($uniq_al{$key}/$total) );
				push (@freq, $freq);
				$tfreq += $freq;
				if ( (defined($mrkrtype)) && ($mrkrtype =~ m/SNP/i) ) {
					if (defined($orig{$key})) {
						push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,$total$,$freq");
					} elsif (!defined($orig{$key})) {
						push (@recAF, "$key$,$key$,$uniq_al{$key}$,$total$,$freq");
					}
				} elsif ( (defined($mrkrtype)) && ($mrkrtype =~ m/STR/i) ) {
					push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,$total$,$freq");
				}
			}
		}
		$markrecAF{$marker6} = join ("\n", @recAF);
		$tfreq = sprintf ("%.6f", $tfreq);
		$markfreq{$marker6} = join (" ", @freq);
		my $num_ind5 = $total/2;
		if (!defined($nogen)) { $nogen = 0; }
		if ($num_ind3 == ($num_ind5 + $nogen - 1) ) {
			# do nothing
		} elsif ($num_ind3 != ($num_ind5 + $nogen - 1) ) {
			$marktoterr{$marker6} = "Note: Total number of individuals is not equal to " . $num_ind3+1 . "";
		}
		$marktotalAF{$marker6} = $tfreq;
		$markwithgen{$marker6} = $num_ind5;
		$marknogen{$marker6}   = $nogen;
		($total, $nogen, $tfreq) = 0;
		(@uniq, @recAF, @freq) = ();
		%uniq_al = ();
	}
	print "done\n";
	(%uniq_al, %recode, %seen, %orig) = ();
	(@uniq, @freq) = ();
	while (defined ($line8 = <IN8>)) {
		chomp $line8;
		$line8 =~ s/^\s+//g;
		$line8 =~ s/\s+$//g;
		next if ( ($line8 =~ m/^\#/) || (length($line8) == 0) );
		($chr6, $marker6, $geno6) = split(" ", $line8, 3);
		if (!defined($panel{$marker6})) { next; }
		($a1, $a2, $count6) = 0;
		@geno6 = ();
		@geno6 = split (/\t|\s+/, $geno6);
		for ($count6=0; $count6<=$num_ind; $count6++) {
			$a1 = ($count6*2);
			$a2 = ($count6*2) + 1;
			$geno6a = $geno6[$a1];
			$geno6b = $geno6[$a2];
			$markergeno = $geno6a." ".$geno6b;
			$markgen{$idindex2{$count6}}{$marker6} = $markergeno;
		}
		($a1a, $a2a, $count7) = 0;
		if ( (defined($mrkrtype2)) && ($mrkrtype2 =~ m/SNP/i) ) {
			$marktype{$marker6} = "SNP";
			(@uniq, @geno7) = ();
			(%seen, %orig, %uniq_al) = ();
			### IF ELSEIF loop for the different ways alleles are coded
			if ( (scalar(grep(/[0|1|2|\-]/, @geno6)) >= 1) && (scalar(grep(/[A|C|G|T]/i, @geno6)) == 0) ) {
				# Don't recode alleles
				@unique = ();
				%seen2 = ();
				foreach my $value (@geno6) {
					next if $value eq "0";
					if (!exists($seen2{$value})) {
						push (@unique, $value);
						$seen2{$value}++;
					}
				}
				(@uniq, @geno7, @arep) = ();
				(%seen, %orig, %recode, %uniq_al) = ();
				if (scalar(@unique) > 2) {
					print "unique=" . join (" ", @unique) . "\n";
					print "There are more than 2 alleles (" . join (" ", @unique) . ") for $marker6\. Please check your data\n";
					exit;
				} elsif (scalar(@unique) == 0) {
					# No data for this marker
					#print "Missing data for $marker6\n";
					my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$,0$,0";
					push (@arec, $temprec);
				}
				foreach $allele (@geno6) {
					if (!exists($seen{$allele})) {
						$seen{$allele}++;
						$uniq_al{$allele}++;
						push (@uniq, $allele);
					} elsif (exists($seen{$allele})) {
						$uniq_al{$allele}++;
					}
					push (@geno7, $allele);
					if (scalar(@geno7) == 2) {
						$geno7a = $geno7[0];
						$geno7b = $geno7[1];
						$recodegeno = $geno7a." ".$geno7b;
						$a1a = ($count7-1)/2;
						$recodegen{$idindex{$a1a}}{$marker6} = $recodegeno;
						@geno7 = ();
					}
					$count7++;
				}
			} elsif ( (scalar(grep(/[A|C|G|T|\-|0]/i, @geno6)) >= 1) && (scalar(grep(/[1|2]/, @geno6)) == 0) ) {
				# Recode alleles from 1 onwards
				# Make sure that the allele recoded to allele 1 is the minor allele
				@unique = ();
				%seen2 = ();
				foreach my $value (@geno6) {
					next if $value eq "0";
					if (!exists($seen2{$value})) {
						push (@unique, $value);
						$seen2{$value}++;
					}
				}
				(@uniq, @geno7, @arep) = ();
				(%seen, %orig, %recode, %uniq_al) = ();
				($allelerep, $arep) = 0;
				if (scalar(@unique) > 2) {
					#print "unique=" . join (" ", @unique) . "\n";
					print "There are more than 2 alleles (" . join (" ", @unique) .") for $marker6\. Please check your data\n";
					exit;
				} elsif (scalar(@unique) == 0) {
					# No data for this marker
					print "Missing data for $marker6\n";
					my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$,0$,0";
					push (@arec, $temprec);
				}
				foreach $allele (@geno6) {
					if ( (!exists($seen{$allele})) && (!exists($recode{$allele})) ) {
						$seen{$allele}++;
						if ( ($allele =~ m/^[0|\-)]/) || ($allele eq "NA") ){
							$recode{$allele} = "0";
						} elsif ( ($allele !~ m/^[0|\-)]/) && ($allele ne "NA") ){
							if ($allele eq $a1_1KG{$chr6}{$marker6}) {
								$recode{$allele} = "1";
							} elsif ($allele eq $a2_1KG{$chr6}{$marker6}) {
								$recode{$allele} = "2";
							} else {
								
								print "Cannot match any allele $allele of $marker6 with 1KG alleles $a1_1KG{$chr6}{$marker6} $a2_1KG{$chr6}{$marker6}\n";
								exit;
							}
							if (scalar(@unique) == 1) {
								if ($allelerep < 1) {
									push (@arep, "$allele $recode{$allele}");
									$allelerep++;
								}
								if ($allelerep == 1) {
									my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$," .join (" ", @arep);
									push (@arec, $temprec);
									@arep = ();
									$arep++;
								}
							} elsif (scalar(@unique) == 2) {
								if ($allelerep < 2) {
									push (@arep, "$allele $recode{$allele}");
									$allelerep++;
								}
								if ($allelerep == 2) {
									my $temprec = "$chr6$,$marker6$,$gloc2{$chr6}{$marker6}$,$ppos2{$chr6}{$marker6}$,$a1_1KG{$chr6}{$marker6}$,$a2_1KG{$chr6}{$marker6}$," .join (" ", @arep);
									push (@arec, $temprec);
									@arep = ();
									$arep++;
								}
							}
						}
						$uniq_al{$recode{$allele}}++;
						$orig{$recode{$allele}} = $allele;
						push (@uniq, $allele);
					} elsif ( (exists($seen{$allele})) && (exists($recode{$allele})) ) {
						$uniq_al{$recode{$allele}}++;
						$orig{$recode{$allele}} = $allele;
					}
					push (@geno7, $recode{$allele});
					if (scalar(@geno7) == 2) {
						$geno7a = $geno7[0];
						$geno7b = $geno7[1];
						$recodegeno = $geno7a." ".$geno7b;
						$a1a = ($count7-1)/2;
						$recodegen{$idindex{$a1a}}{$marker6} = $recodegeno;
						@geno7 = ();
					}
					$count7++;
				}
			}
		} elsif ( (defined($mrkrtype2)) && ($mrkrtype2 =~ m/STR/i) ) {
			$marktype{$marker6} = "STR";
			# Recode alleles from 1 onwards
			my $stsrecode = 0;
			(@uniq, @geno7) = ();
			(%seen, %orig, %recode, %uniq_al) = ();
			foreach $allele (@geno6) {
				if ( (!exists($seen{$allele})) && (!exists($recode{$allele})) ) {
					$seen{$allele}++;
					if ( ($allele =~ m/^[0|\-)]/) || ($allele eq "NA") ){
						$recode{$allele} = "0";
					} elsif ( ($allele !~ m/^[0|\-)]/) && ($allele ne "NA") ){
						$stsrecode++;
						$recode{$allele} = $stsrecode;
					}
					$uniq_al{$recode{$allele}}++;
					$orig{$recode{$allele}} = $allele;
					push (@uniq, $allele);
				} elsif ( (exists($seen{$allele})) && (exists($recode{$allele})) ) {
					$uniq_al{$recode{$allele}}++;
					$orig{$recode{$allele}} = $allele;
				}
				push (@geno7, $recode{$allele});
				if (scalar(@geno7) == 2) {
					$geno7a = $geno7[0];
					$geno7b = $geno7[1];
					$recodegeno = $geno7a." ".$geno7b;
					$a1a = ($count7-1)/2;
					$recodegen{$idindex2{$a1a}}{$marker6} = $recodegeno;
					@geno7 = ();
				}
				$count7++;
			}
		}
		$cline6++;
		($total, $nogen, $tfreq) = 0;

		$markallele{$marker6} = join (" ", @uniq);
		foreach my $key (sort keys %uniq_al) {
			if ($key =~ m/^[0|\-|NA]/) {
				$nogen = $uniq_al{$key}/2;
			} elsif ($key !~ m/^[0|\-|NA]/) {
				$total += $uniq_al{$key};
			}
		}
		foreach my $key (sort keys %uniq_al) {
			if ($key =~ m/^[0|\-|NA]/) {
				if ( (defined($mrkrtype2)) && ($mrkrtype2 =~ m/SNP/i) ) {
					if (defined($orig{$key})) {
						push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
					} elsif (!defined($orig{$key})) {
						push (@recAF, "$key$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
					}
				} elsif ( (defined($mrkrtype2)) && ($mrkrtype2 =~ m/STR/i) ) {
					push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,not_included_in_AF_calculation");
				}
			} elsif ($key !~ m/^[0|\-|NA]/) {
				$freq = sprintf ("%.6f", ($uniq_al{$key}/$total) );
				push (@freq, $freq);
				$tfreq += $freq;
				if ( (defined($mrkrtype2)) && ($mrkrtype2 =~ m/SNP/i) ) {
					if (defined($orig{$key})) {
						push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,$total$,$freq");
					} elsif (!defined($orig{$key})) {
						push (@recAF, "$key$,$key$,$uniq_al{$key}$,$total$,$freq");
					}
				} elsif ( (defined($mrkrtype2)) && ($mrkrtype2 =~ m/STR/i) ) {
					push (@recAF, "$orig{$key}$,$key$,$uniq_al{$key}$,$total$,$freq");
				}
			}
		}
		$markrecAF{$marker6} = join ("\n", @recAF);
		$tfreq = sprintf ("%.6f", $tfreq);
		$markfreq{$marker6} = join (" ", @freq);
		my $num_ind6 = $total/2;
		if (!defined($nogen)) { $nogen = 0; }
		if ($num_ind4 == ($num_ind6 + $nogen - 1) ) {
			# do nothing
		} elsif ($num_ind6 != ($num_ind6 + $nogen - 1) ) {
			$marktoterr{$marker6} = "Note: Total number of individuals is not equal to " . $num_ind4+1 . "";
		}
		$marktotalAF{$marker6} = $tfreq;
		$markwithgen{$marker6} = $num_ind6;
		$marknogen{$marker6}   = $nogen;
		($total, $nogen, $tfreq) = 0;
		(@uniq, @recAF, @freq) = ();
		%uniq_al = ();
	}
}



# MAF ($mafopt): [dataset|1KG|absolute_path_of_MAF_file]
#   Option 1 - dataset (minimum 20 families AND 100 individuals)
#   Option 2 - 1000 Genomes Project data (chromosome, SNP, A1, A2, MAF (A1) -- $maffile
#   Option 3 - user's frequency file (chromosome, SNP, MAF) -- $maffile
$mafopt =~ s/^\s+//g;
$mafopt =~ s/\s$//g;
my $countm = 0;
my ($rsid12, $phypos12, $KGrsid12) = "";
my ($chr13, $marker13, $a1_13, $a2_13, $af13, $af13a, $af13b, $obs13) = "";
#my %KG2rsid = ();
if ($mafopt =~ m/dataset/i) {
	# use the frequencies previously computed within this script
	open (INFO, ">$infofile") || die ("Could not create $infofile file!\n");
	foreach my $panelmarker (@markername) {
		$countm++;
		print INFO "$panelmarker: $markallele{$panelmarker}\n";
		print INFO "$markrecAF{$panelmarker}\n";
		print INFO "Total AF\=$marktotalAF{$panelmarker}\n";
		print INFO "Individuals with Genotypes\=$markwithgen{$panelmarker}\n";
		print INFO "Individuals without Genotypes\=$marknogen{$panelmarker}\n";
		if (defined($marktoterr{$panelmarker})) {
			print INFO "$marktoterr{$panelmarker}\n";
		}
		print INFO "\n";
	}
} elsif ($mafopt =~ m/1KG/i) {
	# Use 1000 Genomes Project data (output file of marker_subpanels.pl)
	# This may only be used for the SNPs in the panel map file
	# If the panel map file has STRs, frequencies of these STRs will be based on the dataset
	print "Note: You preferred to use allele frequencies from 1KG instead\n\n";
#	%KG2rsid = ();
#	if ( -e $matchKGpos ) {
#		# create a hash of the entries here
#		open (IN12, "<$matchKGpos") || die ("Could not open $matchKGpos file!\n");
#		while (defined ($line12 = <IN12>)) {
#			chomp $line12;
#			$line12 =~ s/^\s+//g;
#			$line12 =~ s/\s+$//g;
#			next if ( ($line12 =~ m/^\#/) || (length($line12) == 0) );
#			next if ($line12 =~ m/Dataset_rsID/);
#			($rsid12, $phypos12, $KGrsid12) = "";
#			($rsid12, $phypos12, $KGrsid12) = split(" ", $line12);
#			#print "$rsid12$,$phypos12$,$KGrsid12\n";
#			$KG2rsid{$KGrsid12} = $rsid12;
#		}
#	}

} elsif ($mafopt =~ m/MAF/i) {
	# use file given by user
	# delete the frequencies previously computed within this script
	%markfreq1 = ();
	open (IN13, "<$maffile") || die ("Could not open $maffile file!\n");
	while (defined ($line13 = <IN13>)) {
		chomp $line13;
		$line13 =~ s/^\s+//g;
		$line13 =~ s/\s+$//g;
		next if ( ($line13 =~ m/^\#/) || (length($line13) == 0) );
		($chr13, $af13) = 0;
		$marker13 = "";
		($chr13, $marker13, $af13) = split(" ", $line13, 3);
		if ($chr13 =~ m/^$chr$/) {
			$markfreq1{$marker13} = $af13;
			print "$marker13$,$markfreq1{$marker13}\n";
		} elsif ($chr13 !~ m/^$chr$/) {
			next;
		}
	}
	close (IN13);
} else {
	print "You have not specified the source of MAF information correctly\n\n";
	exit;
}

close (INFO);



##### SPLIT PEDIGREES OR NOT #####
my $k = 0;
my (@usertime, @systemtime, @excluded) = ();
if ($splitped =~ m/N/i) {
	$splitped = "N";
	if (defined($singlefam)) {
		print "Put \"Y\" in line 2 of your parameter file if you want to run setup_gl_auto on a single family\n";
		exit;
	} elsif (!defined($singlefam)) {
		print "We will not split the pedigree file by family\n";
		$outfile = $popchrdir . "/ped.txt";						# OUT (pedigree file for gl_auto)
		$logfile = $popchrdir . "/ped.log";						# LOG2 (log file for all families)
		$errfile = $popchrdir . "/ped.err";						# ERR (error file for all families)
		$genoout = $popchrdir . "/chr" . $chr  . ".geno";		# GENO (genotype file for gl_auto)
		$parout  = $popchrdir . "/chr" . $chr  . ".glauto.par";	# PAR (parameter file for gl_auto)
		$mnumout = $popchrdir . "/chr" . $chr  . ".mnum";		# MNUM (marker number file)
		$arecout = $popchrdir . "/chr" . $chr  . ".arec";		# AREC (allele recoding file)
		$siout   = $popchrdir . "/chr" . $chr  . ".si";			# SI (strand inconsistency file)
		
		# Filenames that will be printed to the gl_auto par file ($parout)
		#$genoout = $pedoutdir . "/chr." . $chr . ".geno";
		$fglout   = $popchrdir . "/chr" . $chr  . ".fgl";
		$miout    = $popchrdir . "/chr" . $chr  . ".mi";
		$seedfile = $popchrdir . "/chr" . $chr  . ".sampler.seed";

		open (OUT, ">$outfile") || die ("Could not create $outfile file!\n");
		
		# Create marker number file
		open (MNUM, ">$mnumout") || die ("Could not create $mnumout file!\n");
		print MNUM "Chromosome$,rsID$,GenLoc$,PhyPos$,MAF_1KG$,MAF_Dataset$,A1_1KG$,A2_1KG$,A1_Dataset$,A2_Dataset$,MarkerNum_Subpanel$,MarkerNum_gl_auto$,Remarks\n";
		my $markers = "";
		foreach $markers (@marknum) {
			print MNUM "$marknum{$markers}\n";
			if ($marknum{$markers} !~ m/OK/) {
				push (@excluded, "AllFam$,$marknum{$markers}");
			}
		}
		close (MNUM);
		
		# Create allele recoding file
		if (scalar(@arec) >= 1) {
			open (AREC, ">$arecout") || die ("Could not create $arecout file!\n");
			print AREC "Chromosome$,rsID$,GenLoc$,PhyPos$,A1_1KG$,A2_1KG$,First_Allele_Seen$,Recode_Value1$,Second_Allele_Seen$,Recode_Value2\n";
			print AREC join ("\n", @arec);
			print AREC "\n";
			close (AREC);
		}
		
		# Create strand inconsistency file
		if (scalar(@strand) >= 1) {
			open (SIOUT, ">$siout") || die ("Could not create $siout file!\n");
			print SIOUT "Chromosome$,rsID$,GenLoc$,PhyPos$,A1_1KG$,A2_1KG$,A1_Dataset$,A2_Dataset\n";
			print SIOUT join ("\n", @strand);
			print SIOUT "\n";
			close (SIOUT);
		}
		
		open (LOG2, ">$logfile") || die ("Could not create $logfile file!\n");
		print LOG2 "Preparing gl_auto-format pedigree file\...\n";

		@glautoped = ();
		my $glautoped = "";

		print "FamilyID$,Size_of_Family$,Total_Individuals_in_Pedigree_File$,TestID$,Parent_of_TestID$,Style$,Remarks\n";
		print LOG "FamilyID$,Size_of_Family$,Total_Individuals_in_Pedigree_File$,TestID$,Parent_of_TestID$,Style$,Remarks\n";
		print LOG2 "FamilyID$,Size_of_Family$,Total_Individuals_in_Pedigree_File$,TestID$,Parent_of_TestID$,Style$,Remarks\n";
		foreach $fam2 (@fam) {
			($famsize, $i) = 0;
			(@idlist, @parent1) = ();
			(%sex, %parent1, %parent2, %in_idlist) = ();
			if (defined($exclufam{$fam2})) {
				next;
			}
			open (IN2, "<$pedfile") || die ("Could not open $pedfile file!\n");
			while (defined ($line2 = <IN2>)) {
				chomp $line2;
				$line2 =~ s/^\s+//g;
				$line2 =~ s/\s+$//g;
				next if ( ($line2 =~ m/^\#/) || (length($line2) == 0) );
				($family, $id1, $parent1, $parent2, $sex) = split(" ", $line2);
				$family =~ s/^\s+//g;
				$family =~ s/\s+$//g;
				$family =~ s/\.|\-/\_/g;
				if ($family =~ m/^$fam2$/) {
					if ($id1 =~ m/^$fam2\_(.+)/) {
						$id = $1;
					}
					if ($parent1 =~ m/^$fam2\_(.+)/) {
						$parent1 = $1;
					}
					if ($parent2 =~ m/^$fam2\_(.+)/) {
						$parent2 = $1;
					}
					$famsize++;
					$id = "$family\_$id";
					if ($parent1 ne "0") { $parent1 = "$family\_$parent1"; }
					if ($parent2 ne "0") { $parent2 = "$family\_$parent2"; }
					push (@idlist, $id);
					$sex{$id}     = $sex;
					$parent1{$id} = $parent1;
					$parent2{$id} = $parent2;
					push (@parent1, $parent1);
				} elsif ($family !~ m/^$fam2$/) {
					next;
				}
			}
			close (IN2);
			$tfamsize += $famsize;
			print "$fam2$,$famsize$,$tfamsize$,";


			foreach my $testid (@idlist) {
				if ( (defined($parent1{$testid})) && ($parent1{$testid} !~ m/^0$/) && (defined($sex{$parent1{$testid}})) && ($sex{$parent1{$testid}} == 1) ) {
					$style="dadfirst";
					print "$testid$,$parent1{$testid}$,$style$,ok\n";
					print LOG "$testid$,$parent1{$testid}$,$style$,ok\n";
					print LOG2 "$testid$,$parent1{$testid}$,$style$,ok\n";
					last;
				} elsif ( (defined($parent1{$testid})) && ($parent1{$testid} !~ m/^0$/) && (defined($sex{$parent1{$testid}})) && ($sex{$parent1{$testid}} == 2) ) {
					$style="momfirst";
					print "$testid$,$parent1{$testid}$,$style$,swap_parent_columns\n";
					print LOG "$testid$,$parent1{$testid}$,$style$,swap_parent_columns\n";
					print LOG2 "$testid$,$parent1{$testid}$,$style$,swap_parent_columns\n";
					last;
				}
			}

			# Print out the triplet info
			# to be sure that we get parents before kids, we have to do this recursively
			# just printing out founders and those whose parents are already done
			# until the list is empty
			# Let us convert everything to "dadfirst" style
			foreach $id (@idlist){
				$in_idlist{$id} = 1; #indicator of whether this person still needs to be printed out
			}
			my $cycle = 0;
			while ($#idlist >= 0){
				$cycle++;
				for ($i = 0; $i <= $#idlist; $i++) {
					$id = $idlist[$i];
					# if individual is a founder, print it out
					if ( (defined($parent1{$id})) && ($parent1{$id} =~ m/^0$/) ) {
						if ($style eq "dadfirst") {
							$glautoped = "$id$,$parent1{$id}$,$parent2{$id}$,";
						} elsif ($style eq "momfirst") {
							$glautoped = "$id$,$parent2{$id}$,$parent1{$id}$,";
						}
						if ( (defined($sex{$id})) && ( ($sex{$id} eq "M") || ($sex{$id} == 1) ) ) {
							$glautoped .= "1 0";
						} else {
							$glautoped .= "2 0";
						}
						splice (@idlist, $i, 1);	# remove id from idlist
						$in_idlist{$id} = 0;		# note that they are gone
						push (@glautoped, $glautoped);
						$glautoped = "";
					} elsif ( (defined($in_idlist{$parent1{$id}})) && (defined($in_idlist{$parent2{$id}})) && ($in_idlist{$parent1{$id}} == 0) && ($in_idlist{$parent2{$id}}== 0) ) { #parents are already out
						if ($style eq "dadfirst") {
							$glautoped = "$id$,$parent1{$id}$,$parent2{$id}$,";
						} elsif ($style eq "momfirst") {
							$glautoped = "$id$,$parent2{$id}$,$parent1{$id}$,";
						}
						if ( (defined($sex{$id})) && ( ($sex{$id} eq "M") || ($sex{$id} == 1) ) ) {
							$glautoped .= "1 0";
						} else {
							$glautoped .= "2 0";
						}
						splice (@idlist, $i, 1);	# remove id from idlist
						$in_idlist{$id} = 0;		# note that they are gone
						push (@glautoped, $glautoped);
						$glautoped = "";
					} elsif ($cycle >= 20) {
						if ( (defined($in_idlist{$parent1{$id}})) && (!defined($in_idlist{$parent2{$id}})) && ($in_idlist{$parent1{$id}} == 0) ) {
							print "A Check input pedigree file: entry for individual $parent2{$id} is missing -- id\=$id parent1_id\=$parent1{$id}\n\n";
							print LOG2 "Check input pedigree file: entry for individual $parent2{$id} is missing -- id\=$id parent1_id\=$parent1{$id}\n\n";
							close (LOG2);
							exit;
						} elsif ( (!defined($in_idlist{$parent1{$id}})) && (defined($in_idlist{$parent2{$id}})) && ($in_idlist{$parent2{$id}} == 0) ) {
							print "B Check input pedigree file: entry for individual $parent1{$id} is missing -- id\=$id parent2_id\=$parent2{$id}\n\n";
							print LOG2 "Check input pedigree file: entry for individual $parent1{$id} is missing -- id\=$id parent2_id\=$parent2{$id}\n\n";
						}
					}
				}
			}
			($famsize, $i) = 0;
			@idlist = ();
		}
		# Done pushing triplets into @glautoped

		# Print the pedigree file
		print OUT "input pedigree size $tfamsize\n";
		print OUT "input pedigree record names 3 integer 2\n";
		print OUT "input pedigree record father mother\n";
		print OUT "******\n";
		print OUT join ("\n", @glautoped);
		print OUT "\n";
		close (OUT);

		print LOG2 "\nSetting up other files needed to run gl_auto...";

		# Family at this point is $fam2 and chromosome is $chr
		# genotype exclusion file will be used to exclude the genotypes of
		# individuals that we do not want to include in the analysis
		# e.g., duplicates, sample swaps, and MZ twins coded as full sibs
		# mapfile = $mapfile
		# pedfile = $pedfile
		# genofile = $genofile
		# IDs of genotyped individuals = $idfile

		open (GENO, ">$genoout") || die ("Could not create $genoout file!\n");
		# Use frequency from dataset (Dr. Nicola H. Chapman's setup glauto mendcheck)
		print GENO "map marker positions ";
		print GENO join (" ", @mrkrgloc);
		print GENO "\n\n";
		my $countm = 0;
		my ($panelmarker, $panelmarker2) = "";
		foreach $panelmarker (@markername) {
			$countm++;
			if ($mafopt !~ m/1KG/i) {
				if (defined($markfreq{$panelmarker})) {
					if ($markfreq{$panelmarker} =~ m/1.000000/) {
						print "There is something wrong with the allele frequency of $panelmarker\n";
						exit;
					}
					print GENO "set markers $countm allele freq $markfreq{$panelmarker}\n";
				} elsif (!defined($markfreq{$panelmarker})) {
					print "Cannot find allele frequencies of $panelmarker\n";
					exit;
				}
			} elsif ($mafopt =~ m/(1KG)|(MAF)/i) {
				if (defined($markfreq1{$panelmarker})) {
					if ($markfreq1{$panelmarker} =~ m/1.000000/) {
						print "There is something wrong with the allele frequency of $panelmarker\n";
						exit;
					}
					print GENO "set markers $countm allele freq $markfreq1{$panelmarker}\n";
				} elsif (!defined($markfreq1{$panelmarker})) {
					print "Cannot find allele frequencies of $panelmarker\n";
					exit;
				}
			}
		}
		print GENO "\nset markers $countm data\n\n";

		# Print the genotypes
		my %genoprint = ();
		open (IN11, "<$ftind") || die ("Could not open $ftind file!\n");
		while (defined ($line11 = <IN11>)) {
			chomp $line11;
			$line11 =~ s/^\s+//g;
			$line11 =~ s/\s+$//g;
			next if ( ($line11 =~ m/^\#/) || (length($line11) == 0) );
			my ($famid11, $id11) = split(/_/, $line11);
			if (defined($exclude{$famid11}{$id11})) {
				next;	# Exclude genotype of this individual
			} elsif ( (!defined($exclude{$famid11}{$id11})) && (!defined($genoprint{$famid11}{$id11})) ) {
				print GENO "$famid11\_$id11";
				foreach $panelmarker2 (@markername) {
					if (!defined($recodegen{$line11}{$panelmarker2})) {
						$recodegen{$line11}{$panelmarker2} = "0 0";
					}
					print GENO "$,$recodegen{$line11}{$panelmarker2}";
				}
				print GENO "\n";
				$genoprint{$famid11}{$id11}++;
			}
		}
		close (IN11);
		close (GENO);

		# Set up parameter file for gl_auto
		my $burn_in = sprintf ("%.0f", $mctot*$burnperc/100);
		open (PAR, ">$parout") || die ("Could not create $parout file!\n");

		print PAR "set printlevel 0\n\n";
	
		print PAR "input pedigree file \'$outfile\' \n";
		print PAR "input marker data file \'$genoout\' \n";
		print PAR "output pedigree chronological\n";
		print PAR "output overwrite pedigree file \'$outfile\'\n\n";

		print PAR "select all markers\n";
		print PAR "set normalized allele frequencies\n";
		print PAR "select trait 1\n";
		print PAR "set trait 1 tloc 11\n";
		print PAR "map tloc 11 unlinked\n";
		print PAR "set tloc 11 allele freqs 0.5 0.5\n\n";

		print PAR "use multiple meiosis sampler\n";
		print PAR "set limit for exact computation $maxped\n";
		print PAR "use sequential imputation for setup\n";
		print PAR "use $seqimp sequential imputation realizations for setup\n\n";

		print PAR "set MC iterations $mctot\n";
		print PAR "set burn-in iterations $burn_in\n";
		print PAR "sample by scan\n";
		print PAR "set L-sampler probability $lsample\n";
		print PAR "set maximum $ibdgnum ibdgraphs per component\n\n";
		
		print PAR "output founder genome labels\n";
		print PAR "output meiosis indicators\n";
		print PAR "output scores every $mcsample scored MC iterations\n";
		print PAR "output scores file \'$fglout\' \n";
		print PAR "output extra file \'$miout\' \n";
		print PAR "output seed file \'$seedfile\'\n";
		print PAR "check marker consistency\n";
		close (PAR);

		print LOG2 "done\n";
		close (LOG2);
	}
} elsif ($splitped =~ m/Y/i) {
	if (defined($singlefam)) {
		@fam = ();
		push (@fam, $singlefam);
		print "Family specified on command line (overrides parameter file):\n";
		print LOG "Family specified on command line (overrides parameter file):\n";
	} elsif (!defined($singlefam)) {
		print "We will split the pedigree file by family\n";
		print "Families specified:\n";
		print join ("\n", @fam);
		print "\n\n";
		print "We will split the pedigree file by family\n";
		print LOG "We will split the pedigree file by family\n";
		print LOG "Families specified           : " . join (" ", @fam) . "\n";
	}
	foreach $fam2 (@fam) {
		if (defined($exclufam{$fam2})) {
			next;
		}
		$k++;
		$time2 = 0;
		$time2  = [Time::HiRes::gettimeofday()];
		$pedoutdir = $outdir . "/" . $popn . "/ped" . $fam2 . "/chr" . $chr;
		if ( ! -e $pedoutdir ) {
			`mkdir -p $pedoutdir`;
		}

		$outfile = $pedoutdir . "/ped" . $fam2 . ".txt";		# OUT (pedigree file for gl_auto)
		$logfile = $pedoutdir . "/ped" . $fam2 . ".log";		# LOG2 (log file for each family)
		$errfile = $pedoutdir . "/ped" . $fam2 . ".err";		# ERR (error file for each family)
		$genoout = $pedoutdir . "/chr" . $chr  . ".geno";		# GENO (genotype file for gl_auto)
		$parout  = $pedoutdir . "/chr" . $chr  . ".glauto.par";	# PAR (parameter file for gl_auto)
		$mnumout = $pedoutdir . "/chr" . $chr  . ".mnum";		# MNUM (marker number file)
		$arecout = $pedoutdir . "/chr" . $chr  . ".arec";		# AREC (allele recoding file)
		$siout   = $pedoutdir . "/chr" . $chr  . ".si";			# SI (strand inconsistency file)

		# Filenames that will be printed to the gl_auto par file ($parout)
		$fglout   = $pedoutdir . "/chr" . $chr  . ".fgl";
		$miout    = $pedoutdir . "/chr" . $chr  . ".mi";
		$seedfile = $pedoutdir . "/chr" . $chr  . ".sampler.seed";

		# Create marker number file
		open (MNUM, ">$mnumout") || die ("Could not create $mnumout file!\n");
		print MNUM "Chromosome$,rsID$,GenLoc$,PhyPos$,MAF_1KG$,MAF_Dataset$,A1_1KG$,A2_1KG$,A1_Dataset$,A2_Dataset$,MarkerNum_Subpanel$,MarkerNum_gl_auto$,Remarks\n";
		my $markers = "";
		foreach $markers (@marknum) {
			print MNUM "$marknum{$markers}\n";
			if ($marknum{$markers} !~ m/OK/) {
				push (@excluded, "$fam2$,$marknum{$markers}");
			}
		}
		close (MNUM);
		
		# Create allele recoding file
		if (scalar(@arec) >= 1) {
			open (AREC, ">$arecout") || die ("Could not create $arecout file!\n");
			print AREC "Chromosome$,rsID$,GenLoc$,PhyPos$,A1_1KG$,A2_1KG$,First_Allele_Seen$,Recode_Value1$,Second_Allele_Seen$,Recode_Value2\n";
			print AREC join ("\n", @arec);
			print AREC "\n";
			close (AREC);
		}

		# Create strand inconsistency file
		if (scalar(@strand) >= 1) {
			open (SIOUT, ">$siout") || die ("Could not create $siout file!\n");
			print SIOUT "Chromosome$,rsID$,GenLoc$,PhyPos$,A1_1KG$,A2_1KG$,A1_Dataset$,A2_Dataset\n";
			print SIOUT join ("\n", @strand);
			print SIOUT "\n";
			close (SIOUT);
			# Update MNUM file
			
		}
		
		open (LOG2, ">$logfile") || die ("Could not create $logfile file!\n");
		print LOG2 "Preparing gl_auto-format pedigree file for family $fam2\...\n";

		open (IN2, "<$pedfile") || die ("Could not open $pedfile file!\n");
		($famsize, $i) = 0;
		(%sex, %parent1, %parent2, %in_idlist) = ();
		while (defined ($line2 = <IN2>)) {
			chomp $line2;
			$line2 =~ s/^\s+//g;
			$line2 =~ s/\s+$//g;
			next if ( ($line2 =~ m/^\#/) || (length($line2) == 0) );
			($family, $id1, $parent1, $parent2, $sex) = split(" ", $line2);
			$family =~ s/^\s+//g;
			$family =~ s/\s+$//g;
			$family =~ s/\.|\-/\_/g;
			if ($family =~ m/^$fam2$/) {
				if ($id1 =~ m/^$fam2\_(.+)/) {
					$id = $1;
				}
				if ($parent1 =~ m/^$fam2\_(.+)/) {
					$parent1 = $1;
				}
				if ($parent2 =~ m/^$fam2\_(.+)/) {
					$parent2 = $1;
				}
				$famsize++;
				$id = "$family\_$id";
				if ($parent1 ne "0") { $parent1 = "$family\_$parent1"; }
				if ($parent2 ne "0") { $parent2 = "$family\_$parent2"; }
				push (@idlist, $id);
				$sex{$id}     = $sex;
				$parent1{$id} = $parent1;
				$parent2{$id} = $parent2;
				push (@parent1, $parent1);
			} elsif ($family !~ m/^$fam2$/) {
				next;
			}
		}
		close (IN2);

		foreach my $key ( sort keys %sex ) {
			print LOG2 "id\=$key sex\=$sex{$key}\n";
		}

		print "\nFamilyID$,Size_of_Family$,TestID$,Parent_of_TestID$,Style$,Remarks\n";
		print LOG "\nFamilyID$,Size_of_Family$,TestID$,Parent_of_TestID$,Style$,Remarks\n";
		print LOG2 "\nFamilyID$,Size_of_Family$,TestID$,Parent_of_TestID$,Style$,Remarks\n";
		foreach my $testid (@idlist) {
			if ( (defined($parent1{$testid})) && ($parent1{$testid} !~ m/^0$/) && (defined($sex{$parent1{$testid}})) && ($sex{$parent1{$testid}} == 1) ) {
				$style="dadfirst";
				print "Family $fam2$,$famsize$,$testid$,$parent1{$testid}$,$style$,ok\n";
				print LOG "$fam2$,$famsize$,$testid$,$parent1{$testid}$,$style$,ok\n";
				print LOG2 "$fam2$,$famsize$,$testid$,$parent1{$testid}$,$style$,ok\n";
				last;
			} elsif ( (defined($parent1{$testid})) && ($parent1{$testid} !~ m/^0$/) && (defined($sex{$parent1{$testid}})) && ($sex{$parent1{$testid}} == 2) ) {
				$style="momfirst";
				print "Family $fam2$,$famsize$,$testid$,$parent1{$testid}$,$style$,swap_parent_columns\n";
				print LOG "$fam2$,$famsize$,$testid$,$parent1{$testid}$,$style$,swap_parent_columns\n";
				print LOG2 "$fam2$,$famsize$,$testid$,$parent1{$testid}$,$style$,swap_parent_columns\n";
				last;
			}
		}

		open (OUT, ">$outfile") || die ("Could not create $outfile file!\n");
		print OUT "input pedigree size $famsize\n";
		print OUT "input pedigree record names 3 integer 2\n";
		print OUT "input pedigree record father mother\n";
		print OUT "******\n";

		# Print out the triplet info
		# to be sure that we get parents before kids, we have to do this recursively
		# just printing out founders and those whose parents are already done
		# until the list is empty
		# Let us convert everything to "dadfirst" style
		foreach $id (@idlist){
			$in_idlist{$id} = 1; #indicator of whether this person still needs to be printed out
		}
		my $cycle = 0;
		while ($#idlist >= 0){
			$cycle++;
			for ($i = 0; $i <= $#idlist; $i++) {
				$id = $idlist[$i];
				# if individual is a founder, print it out
				if ( (defined($parent1{$id})) && ($parent1{$id} =~ m/^0$/) ) {
					if ($style eq "dadfirst") {
						print OUT "$id$,$parent1{$id}$,$parent2{$id}$,";
					} elsif ($style eq "momfirst") {
						print OUT "$id$,$parent2{$id}$,$parent1{$id}$,";
					}
					if ( (defined($sex{$id})) && ( ($sex{$id} eq "M") || ($sex{$id} == 1) ) ) {
						print OUT "1 0\n";
					} else {
						print OUT "2 0\n";
					}
					splice (@idlist, $i, 1);	# remove id from idlist
					$in_idlist{$id} = 0;		# note that they are gone
				} elsif ( (defined($in_idlist{$parent1{$id}})) && (defined($in_idlist{$parent2{$id}})) && ($in_idlist{$parent1{$id}} == 0) && ($in_idlist{$parent2{$id}}== 0) ) { #parents are already out
					if ($style eq "dadfirst") {
						print OUT "$id$,$parent1{$id}$,$parent2{$id}$,";
					} elsif ($style eq "momfirst") {
						print OUT "$id$,$parent2{$id}$,$parent1{$id}$,";
					}
					if ( (defined($sex{$id})) && ( ($sex{$id} eq "M") || ($sex{$id} == 1) ) ) {
						print OUT "1 0\n";
					} else {
						print OUT "2 0\n";
					}
					splice (@idlist, $i, 1);	# remove id from idlist
					$in_idlist{$id} = 0;		# note that they are gone
				} elsif ($cycle >= 20) {
					if ( (defined($in_idlist{$parent1{$id}})) && (!defined($in_idlist{$parent2{$id}})) && ($in_idlist{$parent1{$id}} == 0) ) {
						print "Check input pedigree file: entry for individual $parent2{$id} is missing -- id\=$id parent1_id\=$parent1{$id}\n\n";
						print LOG2 "Check input pedigree file: entry for individual $parent2{$id} is missing missing -- id\=$id parent1_id\=$parent1{$id}\n\n";
						close (LOG2);
						exit;
					} elsif ( (!defined($in_idlist{$parent1{$id}})) && (defined($in_idlist{$parent2{$id}})) && ($in_idlist{$parent2{$id}} == 0) ) {
						print "Check input pedigree file: entry for individual $parent1{$id} is missing -- id\=$id parent2_id\=$parent2{$id}\n\n";
						print LOG2 "Check input pedigree file: entry for individual $parent1{$id} is missing -- id\=$id parent2_id\=$parent2{$id}\n\n";
						close (LOG2);
						exit;
					}
				}
			}
		}
		($famsize, $i) = 0;
		@idlist = ();
		# Done printing triplets
		close (OUT);

		print LOG2 "\nSetting up other files needed to run gl_auto...";




		# Family at this point is $fam2 and chromosome is $chr
		# genotype exclusion file will be used to exclude the genotypes of
		# individuals that we do not want to include in the analysis
		# e.g., duplicates, sample swaps, and MZ twins coded as full sibs
		# mapfile = $mapfile
		# pedfile = $pedfile
		# genofile = $genofile
		# IDs of genotyped individuals = $idfile
		# MAF ($mafopt): [dataset|1KG|absolute_path_of_MAF_file]
		#   Option 1 - dataset (minimum 20 families AND 100 individuals)
		#   Option 2 - 1000 Genomes Project data (chromosome, SNP, A1, A2, MAF (A1) -- $maffile
		#   Option 3 - user's frequency file (chromosome, SNP, MAF) -- $maffile
		$mafopt =~ s/^\s+//g;
		$mafopt =~ s/\s$//g;

		open (GENO, ">$genoout") || die ("Could not create $genoout file!\n");
		print GENO "map marker positions ";
		print GENO join (" ", @mrkrgloc);
		print GENO "\n\n";
		my $countm = 0;
		my ($panelmarker, $panelmarker2) = "";
		foreach $panelmarker (@markername) {
			$countm++;
			if ($mafopt !~ m/1KG/i) {
				if (defined($markfreq{$panelmarker})) {
					if ($markfreq{$panelmarker} =~ m/1.000000/) {
						print "There is something wrong with the allele frequency of $panelmarker\n";
						exit;
					}
					print GENO "set markers $countm allele freq $markfreq{$panelmarker}\n";
				} elsif (!defined($markfreq{$panelmarker})) {
					print "Cannot find allele frequencies of $panelmarker\n";
					exit;
				}
			} elsif ($mafopt =~ m/(1KG)|(MAF)/i) {
				if (defined($markfreq1{$panelmarker})) {
					if ($markfreq1{$panelmarker} =~ m/1.000000/) {
						print "There is something wrong with the allele frequency of $panelmarker\n";
						exit;
					}
					print GENO "set markers $countm allele freq $markfreq1{$panelmarker}\n";
				} elsif (!defined($markfreq1{$panelmarker})) {
					print "Cannot find allele frequencies of $panelmarker\n";
					exit;
				}
			}
			# Use line below to print MAF
		}
		print GENO "\nset markers $countm data\n\n";

		# Print the genotypes
		my %genoprint = ();
		open (IN11, "<$ftind") || die ("Could not open $ftind file!\n");
		while (defined ($line11 = <IN11>)) {
			chomp $line11;
			$line11 =~ s/^\s+//g;
			$line11 =~ s/\s+$//g;
			next if ( ($line11 =~ m/^\#/) || (length($line11) == 0) );
			my ($famid11, $id11) = split(/_/, $line11);
			if ($famid11 =~ m/^$fam2$/) {
				if (defined($exclude{$famid11}{$id11})) {
					next;	# Exclude genotype of this individual
				} elsif ( (!defined($exclude{$famid11}{$id11})) && (!defined($genoprint{$famid11}{$id11})) ) {
					print GENO "$famid11\_$id11";
					foreach $panelmarker2 (@markername) {
						if (!defined($recodegen{$line11}{$panelmarker2})) {
							$recodegen{$line11}{$panelmarker2} = "0 0";
						}
						print GENO "$,$recodegen{$line11}{$panelmarker2}";
					}
					print GENO "\n";
					$genoprint{$famid11}{$id11}++;
				}
			}
		}
		close (IN11);
		close (GENO);

		# Set up parameter file for gl_auto
		my $burn_in = sprintf ("%.0f", $mctot*$burnperc/100);
		open (PAR, ">$parout") || die ("Could not create $parout file!\n");

		print PAR "set printlevel 0\n\n";

		print PAR "input pedigree file \'$outfile\'\n";
		print PAR "input marker data file \'$genoout\'\n";
		print PAR "output pedigree chronological\n";
		print PAR "output overwrite pedigree file \'$outfile\'\n\n";

		print PAR "select all markers\n";
		print PAR "set normalized allele frequencies\n";
		print PAR "select trait 1\n";
		print PAR "set trait 1 tloc 11\n";
		print PAR "map tloc 11 unlinked\n";
		print PAR "set tloc 11 allele freqs 0.5 0.5\n\n";

		print PAR "use multiple meiosis sampler\n";
		print PAR "set limit for exact computation $maxped\n";
		print PAR "use sequential imputation for setup\n";
		print PAR "use $seqimp sequential imputation realizations for setup\n\n";

		print PAR "set MC iterations $mctot\n";
		print PAR "set burn-in iterations $burn_in\n";
		print PAR "sample by scan\n";
		print PAR "set L-sampler probability $lsample\n";
		print PAR "set maximum $ibdgnum ibdgraphs per component\n\n";

		print PAR "output founder genome labels\n";
		print PAR "output meiosis indicators\n";
		print PAR "output scores every $mcsample scored MC iterations\n";
		print PAR "output scores file \'$fglout\'\n";
		print PAR "output extra file \'$miout\'\n";
		print PAR "output seed file \'$seedfile\'\n";
		print PAR "check marker consistency\n";
		close (PAR);

		print LOG2 "done\n";
		
		my ($user3, $system3) = 0;
		($user2, $system2, $child_user2, $child_system2) = 0;
		($user2, $system2, $child_user2, $child_system2) = times;
		$real2   = Time::HiRes::tv_interval($time2);
		$user2   = sprintf ("%.3f", $user2 + $child_user2);
		$system2 = sprintf ("%.3f", $system2 + $child_system2);
		unshift (@usertime, $user2);
		unshift (@systemtime, $system2);
		if ($k == 1) {
			$user3 = $usertime[0];
			$system3 = $systemtime[0];
		} elsif ($k > 1) {
			$user3 = $usertime[0] - $usertime[1];
			$system3 = $systemtime[0] - $systemtime[1];
		}
		if (!defined($singlefam)) {
			print "\nReal time (panel $panel popn $popn fam $fam chr $chr)   : " . parsetime ($real2);
			print   "User time (panel $panel popn $popn fam $fam chr $chr)   : " . parsetime ($user3);
			print   "System time (panel $panel popn $popn fam $fam chr $chr) : " . parsetime ($system3);
			print LOG "\nReal time (panel $panel popn $popn fam $fam chr $chr)   : " . parsetime ($real2);
			print LOG   "User time (panel $panel popn $popn fam $fam chr $chr)   : " . parsetime ($user3);
			print LOG   "System time (panel $panel popn $popn fam $fam chr $chr) : " . parsetime ($system3);
		} elsif (defined($singlefam)) {
			print "\nReal time (panel $panel popn $popn fam $singlefam chr $chr)   : " . parsetime ($real2);
			print   "User time (panel $panel popn $popn fam $singlefam chr $chr)   : " . parsetime ($user3);
			print   "System time (panel $panel popn $popn fam $singlefam chr $chr) : " . parsetime ($system3);
			print LOG "\nReal time (panel $panel popn $popn fam $singlefam chr $chr)   : " . parsetime ($real2);
			print LOG   "User time (panel $panel popn $popn fam $singlefam chr $chr)   : " . parsetime ($user3);
			print LOG   "System time (panel $panel popn $popn fam $singlefam chr $chr) : " . parsetime ($system3);
		}

	}
	close (LOG2);
}
if (scalar(@excluded) >= 1) {
	print "\nMarkers excluded in the MORGAN-format genotype file due to strand inconsistency or missing MAF:\n";
	print "FamilyID$,Chromosome$,rsID$,GenLoc$,PhyPos$,MAF_1KG$,MAF_Dataset$,A1_1KG$,A2_1KG$,A1_Dataset$,A2_Dataset$,MarkerNum_Subpanel$,MarkerNum_gl_auto$,Remarks\n";
	print join ("\n", @excluded);
	print "\n";
	print LOG "\nMarkers excluded in the MORGAN-format genotype file due to strand inconsistency or missing MAF:\n";
	print LOG "FamilyID$,Chromosome$,rsID$,GenLoc$,PhyPos$,MAF_1KG$,MAF_Dataset$,A1_1KG$,A2_1KG$,A1_Dataset$,A2_Dataset$,MarkerNum_Subpanel$,MarkerNum_gl_auto$,Remarks\n";
	print LOG join ("\n", @excluded);
	print LOG "\n";
}
### Additional check for MORGAN-format genotype file
my ($nummarkers, $g, $h, $freq1, $freq2, $totf, $error) = 0;
my ($geno_cM) = "";
my (%cM, %freq3) = ();
if ($mafopt =~ m/1KG/) {
	open (IN15, "<$genoout") || die ("Could not open $genoout file!\n");
	while (defined ($line15 = <IN15>)) {
		chomp $line15;
		$line15 =~ s/^\s+//g;
		$line15 =~ s/\s+$//g;
		next if ( ($line15 =~ m/^\#/) || (length($line15) == 0) );
		if ($line15 =~ m/map marker positions (.+)/) {
			$geno_cM = $1;
			my @geno_cM = split(/\s/, $geno_cM);
			for ($g = 0; $g <= $#geno_cM; $g++) {
				my $l = $g + 1;
				$geno_cM[$g] = sprintf("%.6f", $geno_cM[$g]);
				$cM{$l} = $geno_cM[$g];
			}
		} elsif ($line15 =~ m/set markers (.+) allele freq (.+) (.+)/) {
			$h = $1;
			$freq1 = $2;
			$freq2 = $3;
			$totf  = $freq1 + $freq2;
			# freq1 should be less than 0.5, and freq1+freq2 should be 1
			if ($freq1 > 0.5) {
				print "Marker $h has a MAF\=$freq1 (greater than 0.5)\n";
				$error++;
			}
			if ($totf < 0.99) {
				print "Total allele frequency of marker $h ($totf) is less than 1\n";
				$error++;
				exit;
			}
			if (abs( $maf2{$chr}{$cM{$h}} - $freq1 ) > 0.0000001) {
				print "Check allele frequency of marker $h because of difference between $freq1 and $maf2{$chr}{$cM{$h}}\n";
				$error++;
			}
		} elsif ($line15 =~ m/set markers (\d+) data/) {
			$nummarkers = $1;
		}
	}
	close (IN15);
} elsif ($mafopt =~ m/dataset/) {
	open (IN15, "<$genoout") || die ("Could not open $genoout file!\n");
	while (defined ($line15 = <IN15>)) {
		chomp $line15;
		$line15 =~ s/^\s+//g;
		$line15 =~ s/\s+$//g;
		next if ( ($line15 =~ m/^\#/) || (length($line15) == 0) );
		if ($line15 =~ m/map marker positions (.+)/) {
			$geno_cM = $1;
			my @geno_cM = split(/\s/, $geno_cM);
			for ($g = 0; $g <= $#geno_cM; $g++) {
				my $l = $g + 1;
				$geno_cM[$g] = sprintf("%.6f", $geno_cM[$g]);
				$cM{$l} = $geno_cM[$g];
			}
		} elsif ($line15 =~ m/set markers (.+) allele freq (.+) (.+)/) {
			$h = $1;
			$freq1 = $2;
			$freq2 = $3;
			$totf  = $freq1 + $freq2;
			if ($totf < 0.99) {
				print "Total allele frequency of marker $h ($totf) is less than 1\n";
				$error++;
				exit;
			}
			if (abs( $maf3{$chr}{$cM{$h}} - $freq1 ) > 0.0000001) {
				if (abs( $maf3{$chr}{$cM{$h}} - $freq2 ) > 0.0000001) {
					print "Check allele frequency of marker $h because of difference between $freq2 and $maf3{$chr}{$cM{$h}}\n";
					$error++;
				}
			}
		} elsif ($line15 =~ m/set markers (\d+) data/) {
			$nummarkers = $1;
		}
	}
	close (IN15);
}
if ( (defined($error)) && ($error >= 1) ) {
	print "Please check the allele frequencies in your MORGAN-format genotype file\n";
	exit;
}
###
# Print general information regarding files (counts)
my ($header, $genocheck, $wholegeno) = "";
my ($geno_err, $header_m, $gfreq_m, $data_m, $pregeno_m, $geno_m, $geno_ind) = 0;
my (@header, @genocheck) = ();
print "\nChecking the MORGAN-format genotype file (GENO)...\n";
print "Number of markers in the marker subpanel file (PMAP) : $mcount\n";
print "Number of markers for the GENO file                  : $glcount\n";
print "Checking marker genetic locations in the GENO file...";
print LOG "\nChecking the MORGAN-format genotype file (GENO)...\n";
print LOG "Number of markers in the marker subpanel file (PMAP) : $mcount\n";
print LOG "Number of markers for the GENO file                  : $glcount\n";
print LOG "Checking marker genetic locations in the GENO file...";
#print "genoout\=$genoout\n";
$header = `head -1 $genoout`;
#print "header\=$header\n";
@header = split (/\s+/, $header);
$header_m = scalar(@header) - 3;
#print "Markers in header\= $header_m\n";
if ($header_m == $glcount) {
	print "$header_m ok\n";
	print LOG "$header_m ok\n";
} elsif ($header_m != $glcount) {
	$geno_err++;
	$genocheck = "there are $header_m markers in the header";
	print "$genocheck\n";
	print LOG "$genocheck\n";
	push (@genocheck, $genocheck);
}

print "Checking number of markers with allele frequencies in the GENO file...";
print LOG "Checking number of markers with allele frequencies in the GENO file...";
$gfreq_m = `grep "allele freq" $genoout | tail -1 | awk '{FS=" "}{print \$3}'`;
chomp $gfreq_m;
#print "gfreq_m\=$gfreq_m\n";
if ($gfreq_m == $glcount) {
	print "$gfreq_m ok\n";
	print LOG "$gfreq_m ok\n";
} elsif ($gfreq_m != $glcount) {
	$geno_err++;
	$genocheck = "there are $gfreq_m markers with allele frequencies";
	print "$genocheck\n";
	print LOG "$genocheck\n";
	push (@genocheck, $genocheck);
}

print "Checking the dimensions of the genotype data in the GENO file:\n";
print LOG "Checking the dimensions of the genotype data in the GENO file:\n";
$data_m = `grep -v "map marker" $genoout | grep -v "allele freq" | grep -v -e \'^\$\' | head -1 | awk '{FS=" "}{print \$3}'`;
chomp $data_m;
#print "data_m\=$data_m\n";
if ($data_m == $glcount) {
	print "   GENO file contains \"set markers $data_m data\"...ok\n";
	print LOG "   GENO file contains \"set markers $data_m data\"...ok\n";
} elsif ($data_m != $glcount) {
	$geno_err++;
	$genocheck = "The line \"set markers $data_m data\" is incorrect\n";
	print "$genocheck\n";
	print LOG "$genocheck\n";
	push (@genocheck, $genocheck);
}
$pregeno_m = `grep -v "map marker" $genoout | grep -v "allele freq" | grep -v -e \'^\$\' | tail -n +2 | head -1 | wc -w`;
chomp $pregeno_m;
$geno_m = ($pregeno_m - 1)/2;
#print "geno_m\=$geno_m\n";
if ($geno_m == $glcount) {
	print "   Genotype data of first individual has $geno_m markers...ok\n";
	print LOG "   Genotype data of first individual has $geno_m markers...ok\n";
} elsif ($geno_m != $glcount) {
	if ($geno_m < 0) { $geno_m = 0; }
	$geno_err++;
	$genocheck = "   Genotype data of first individual has the incorrect number of markers: $geno_m\n";
	print "$genocheck\n";
	print LOG "$genocheck\n";
	push (@genocheck, $genocheck);
}
$geno_ind = `grep -v "map marker" $genoout | grep -v "allele freq" | grep -v -e \'^\$\' | tail -n +2 | wc -l`;
chomp $geno_ind;
#print "geno_ind\=$geno_ind\n";
if ($geno_ind >= 3) {
	print "   There are $geno_ind individuals who have genotype data (>=3)...ok\n";
	print LOG "   There are $geno_ind individuals who have genotype data (>=3)...ok\n";
} elsif ($geno_ind < 3) {
	if ($geno_ind == 0) {
		$geno_err++;
		$genocheck = "   There was no genotype data recoded\n";
		print "$genocheck\n";
		print LOG "$genocheck\n";
		push (@genocheck, $genocheck);
	} elsif ( ($geno_ind == 1) || ($geno_ind == 2) ) {
		$geno_err++;
		$genocheck = "   Only $geno_ind individual(s) have genotype data (<3)\n";
		print "$genocheck\n";
		print LOG "$genocheck\n";
		push (@genocheck, $genocheck);
	}
}
###
if (scalar(@genocheck) == 0) {
	print "\nFinished setting up MORGAN-format files needed to run gl_auto\n";
	print LOG "\nFinished setting up MORGAN-format files needed to run gl_auto\n";
} elsif (scalar(@genocheck) >= 1) {
	print "\nPlease check your MORGAN-format genotype file\n";
	print LOG "\nPlease check your MORGAN-format genotype file\n";
	exit;
}

##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);
if (!defined($singlefam)) {
	print "\nTotal real time (panel $panel popn $popn chr $chr)   : " . parsetime ($real);
	print   "Total user time (panel $panel popn $popn chr $chr)   : " . parsetime ($user);
	print   "Total system time (panel $panel popn $popn chr $chr) : " . parsetime ($system);
	print LOG "\nTotal real time (panel $panel popn $popn chr $chr)   : " . parsetime ($real);
	print LOG   "Total user time (panel $panel popn $popn chr $chr)   : " . parsetime ($user);
	print LOG   "Total system time (panel $panel popn $popn chr $chr) : " . parsetime ($system);
	print "\nDone\n\n";
} elsif (defined($singlefam)) {
	print "\nTotal real time (panel $panel popn $popn fam $singlefam chr $chr)   : " . parsetime ($real);
	print   "Total user time (panel $panel popn $popn fam $singlefam chr $chr)   : " . parsetime ($user);
	print   "Total system time (panel $panel popn $popn fam $singlefam chr $chr) : " . parsetime ($system);
	print LOG "\nTotal real time (panel $panel popn $popn fam $singlefam chr $chr)   : " . parsetime ($real);
	print LOG   "Total user time (panel $panel popn $popn fam $singlefam chr $chr)   : " . parsetime ($user);
	print LOG   "Total system time (panel $panel popn $popn fam $singlefam chr $chr) : " . parsetime ($system);
	print "\nDone\n\n";
}
close (LOG);

##### SUBROUTINES #####

sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}

