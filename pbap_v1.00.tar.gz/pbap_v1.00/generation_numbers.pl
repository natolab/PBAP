#!/usr/bin/perl
# ./generation_numbers.pl
# By Alejandro Q. Nato, Jr., Ph.D.
# This script determines generation numbers for the individuals in a pedigree
# The generation numbers will be used for kped.pl (modified version of Dr. Nicola H. Chapman's pedcheck.pl)
# Some parts of this script are also from the original pedcheck.pl

# 03/13/2013, 03/19/2013
# Modifications: 07/22/2013-09/23/2014



use warnings;
use strict;
use diagnostics;

use Time::HiRes qw( gettimeofday );
use List::Util qw ( max );

my ($line1, $line2, $line3, $line4, $line5) = "";
my (@list1, @list2, @list3, @list4, @list5) = ();
my (@info1, @info2, @info3, @info4, @info5) = ();

my ($line6, $line7, $line8, $line9, $line10) = "";
my (@list6, @list7, @list8, @list9, @list10) = ();
my (@info6, @info7, @info8, @info9, @info10) = ();

my ($famid, $subid, $count, $counth) = 0;
my ($sex, $dadid, $momid, $line2a, $temp2a) = "";
my ($temp, $temp2, $fnd1, $fnd2, $temp3, $temp4, $tempres, $key, $key2) = "";
my ($famid2, $subid2, $sex2, $dadid2, $momid2) = 0;
my ($famid2a, $subid2a, $sex2a, $dadid2a, $momid2a) = 0;
my ($gendad, $genmom, $genkid, $genT, $gendiff) = 0;

my (@famid, @list2a) = ();

my (%indiv, %dad, %mom, %wife, %husb, %kid, %sex, %hashgen) = ();

$, = " ";	# set output field separator

my $in1    = $ARGV[0];	# pedigree file (absolute path)
my $pedh   = $ARGV[1];	# pedigree file header: [T|F]
my $outdir = $ARGV[2];	# output directory (absolute path)

my $script = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;

if ($#ARGV < 0) {
	$script = $0;
	$script =~ s/^(.+)\///g;
	$script =~ s/^\.\///g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (March 2013; updated July 2013-September 2014)\n\n";
	print "This script determines generation numbers\n";
	print "for the individuals in a pedigree.\n\n";

	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script pedigree_file* [T|F]** output_directory*\n";
	print "       *use absolute path\n";
	print "       **pedigree file header=[T|F]\n\n";

	print "If you transposed your fileset by using transpose_fileset.pl,\n";
	print "   use its output pedigree file (*.tpedo).\n\n";
	print "Otherwise, use a pedigree file with the following columns:\n\n";
	print "   1) Family ID\n";
	print "   2) Individual ID (concatenated with family ID)\n";
	print "   3) Father ID (concatenated with family ID except for zeroes)\n";
	print "   4) Mother ID (concatenated with family ID except for zeroes)\n";
	print "   5) Sex\n\n";
	exit;
}

if ($outdir =~ m/\/$/) { chop $outdir; }

open (IN1, "<$in1") || die ("Could not open $in1 file!\n");
@list1 = <IN1>;
close (IN1);

my $out1 = $outdir."/gen_num.out";
my $out2 = $outdir."/pedigree.info";
my $out3 = $outdir."/gen_num.pnd";	# lists the pedigree info of individuals that belong
									# to pedigrees where generation numbers cannot be determined
my $log  = $outdir."/gen_num.log";

if (! -e $outdir) {
	`mkdir -p $outdir`;
}
if ( -e $out3) {
	`rm $out3`;
}

open (OUT1, ">$out1") || die ("Could not create $out1 file!\n");
open (OUT2, ">$out2") || die ("Could not create $out2 file!\n");
print OUT2 "FamilyID$,Individuals$,Males$,Females$,Founders$,Non-founders$,Singletons$,Generations\n";

open (LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "################################################################################\n";
print LOG "#                          PBAP generation_numbers.pl                          #\n";
print LOG "#                            Alejandro Q. Nato, Jr.                            #\n";
print LOG "#                           Statistical Genetics Lab                           #\n";
print LOG "#                    University of Washington, Seattle, WA                     #\n";
print LOG "################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

print LOG "INPUT PEDIGREE FILE : $in1\n\n";
print LOG "OUTPUT FILES (under $outdir):\n";
my $out1a = $out1; $out1a =~ s/$outdir\///g;
my $out2a = $out2; $out2a =~ s/$outdir\///g;
my $out3a = $out3; $out3a =~ s/$outdir\///g;
print LOG "Pedigree file with generation numbers                    : $out1a\n";
print LOG "Information regarding pedigrees in the dataset           : $out2a\n";

$counth = 0;
$count = 0;

# Create several hashes
my @list1a = @list1;
my (@info1a, @spouses, @sptemp, @ped, @gen, @mgen, @singleton) = ();
my ($size_h, $size_w, $size_k, $test, $i, $j) = 0;
my $spouses = "";
my ($individuals, $males, $females, $founders, $nonfounders, $singletons, $generations) = 0;
my ($tindividuals, $tmales, $tfemales, $tfounders, $tnonfounders, $tsingletons, $mgenerations, $tpedigrees, $tskippedfam) = 0;
foreach my $line1a (@list1a) {
	chomp $line1a;
	next if ($line1a =~ m/input|\*|\#/);
	next if (length ($line1a) == 0);
	@info1a = split (/\t|\s+/, $line1a, 5);
	$famid  = $info1a[0];
	$subid  = $info1a[1];
	$dadid  = $info1a[2];
	$momid  = $info1a[3];
	$sex    = $info1a[4];
	
	$counth++;
	if ($pedh =~ m/T/i) {
		next if ( ($counth == 1) || ($famid eq "FamilyID") );
	}
	
	# Remove leading and lagging spaces
	$famid=~s/^\s+//g;
	$subid=~s/^\s+//g;

	$dadid=~s/^\s+//g;
	$dadid=~ s/\s+$//g;
	if ( ($dadid eq "") || ($dadid eq ".") ){ $dadid = 0; }

	$momid=~s/^\s+//g;
	$momid=~ s/\s+$//g;
	if ( ($momid eq "") || ($momid eq ".") ) { $momid = 0; }

	if ($sex eq "M") { $sex = 1; }
	elsif ($sex eq "F") { $sex = 2; }
	if ($sex =~ m/NA/) {
		print LOG "Skipping individual $subid because individual's sex is NA\n";
		next;
	}
	$sex += 0;
	print "$famid$,$subid$,$dadid$,$momid$,$sex\n";
	
	$dad{$subid} = $dadid;
	$mom{$subid} = $momid;
	$indiv{$famid}{$subid} = $subid;
	
	# adding generation number 1 to all individuals
	$hashgen{$famid}{$subid} = 1;
	if ($dadid eq "0") {
		$hashgen{$famid}{$dadid} = 0;
	} else {
		$hashgen{$famid}{$dadid} = 1;
	}
	if ($momid eq "0") {
		$hashgen{$famid}{$momid} = 0;
	} else {
		$hashgen{$famid}{$momid} = 1;
	}
	
	# allow multiple spouses
	if (grep /^$dadid$/, @{ $husb{$momid} }) {
		# do nothing
	} else {
		push (@{ $husb{$momid} }, $dadid);
	}
	if (grep /^$momid$/, @{ $wife{$dadid} }) {
		# do nothing
	} else {
		push (@{ $wife{$dadid} }, $momid);
	}
	$size_h = scalar( @{ $husb{$momid} } );
	$size_w = scalar( @{ $wife{$dadid} } );

	# allow multiple offspring
	if (grep /^$subid$/, @{ $kid{$dadid}{$momid} }) {
		# do nothing
	} else {
		push (@{ $kid{$dadid}{$momid} }, $subid);
	}
	$size_k = scalar( @{ $kid{$dadid}{$momid} } );

	$sex{$subid} = $sex;

	if ( ($size_h > 1) || ($size_w > 1) ) {
		if ($size_h > 1) {
			$spouses = "$momid has $size_h male partners";
			if (grep /$spouses/, @spouses) {
				# do nothing
			} else {
				push (@spouses, $spouses);
				push (@sptemp, "$spouses:");
				for ($i=0; $i<$size_h; $i++) {
					$j = $i + 1;
					push (@sptemp, "$j\. $husb{$momid}->[$i]");
				}
			}
		}
		if ($size_w > 1) {
			$spouses = "$dadid has $size_w female partners";
			if (grep /$spouses/, @spouses) {
				# do nothing
			} else {
				push (@spouses, $spouses);
				push (@sptemp, "$spouses:");
				for ($i=0; $i<$size_w; $i++) {
					$j = $i + 1;
					push (@sptemp, "$j\. $wife{$dadid}->[$i]");
				}
			}
		}
	$test++;
	}
}

$counth = 0;
my %singleton = ();
# Sort @list1 first
my @listsort = sort @list1;
foreach $line1 (@listsort) {
	chomp $line1;
	next if ($line1 =~ m/input|\*|\#/);
	next if (length ($line1) == 0);
	@info1 = split (/\t|\s+/, $line1, 5);
	$famid = $info1[0];
	$subid = $info1[1];
	$dadid = $info1[2];
	$momid = $info1[3];
	$sex   = $info1[4];
	$counth++;
	if ($pedh =~ m/T/i) {
		next if ( ($counth == 1) || ($famid eq "FamilyID") );
	}
	
	# Remove leading and lagging spaces
	$famid=~s/^\s//;
	$subid=~s/^\s//;

	$dadid=~s/^\s//;
	$dadid=~ s/\s+$//;
	if ( ($dadid eq "") || ($dadid eq ".") ){ $dadid = 0; }

	$momid=~s/^\s//;
	$momid=~ s/\s+$//;
	if ( ($momid eq "") || ($momid eq ".") ) { $momid = 0; }

	if ($sex eq "M") { $sex = 1; }
	elsif ($sex eq "F") { $sex = 2; }
	if ($sex =~ m/NA/) {
		print LOG "Skipping individual $subid because individual's sex is NA\n";
		next;
	}
	$sex += 0;


	$temp = "$famid$,$subid$,$dadid$,$momid$,$sex";
	
	# Determine the generation number per family
	($individuals, $males, $females, $founders, $nonfounders, $singletons, $generations) = 0;
	if ($count == 0) {      				# there is none in @temp yet
		push (@list2, $temp);
		unshift (@famid, $famid);
		$count++;
	} elsif ($count >= 1 ) {       			# there is at least one in the pedigree
		if ($famid eq $famid[0]) {  		# we are still in the same pedigree
			push (@list2, $temp);
			unshift (@famid, $famid);
			$count++;
		} elsif ($famid ne $famid[0]) {  	# we are already in another pedigree so start processing now
			
			@list2a = @list2;
			getGenNum(@list2);
			my $iteration = 0;
			do {
				$gendiff = 0;
				getGenNum(@list2);
				$iteration++;
				if ($iteration >= 100) {
					$tskippedfam++;
					push (@ped, $famid[0]);
					$gendiff = 0;
					if ( ! -e $out3) {
						open (OUT3, ">$out3") || die ("Could not create $out3 file!\n");
						print LOG "Individuals whose generation numbers were not determined : $out3a\n\n";
						print OUT3 join ("\n", @list2);
						print OUT3 "\n";
					} elsif ( -e $out3) {
						print OUT3 join ("\n", @list2);
						print OUT3 "\n";
					}
					print LOG "Skipped family $famid[0] since generation numbers cannot be assigned properly\n";
					print "Skipped family $famid[0] since generation numbers cannot be assigned properly\n";
				}
			} until ($gendiff == 0);
			if ( ($gendiff == 0) && ($iteration < 100) ) {
				foreach $line2 (@list2a) {
					($famid2, $subid2, $dadid2, $momid2, $sex2) = split (/\t|\s+/, $line2, 5);
					print OUT1 "$famid2$,$subid2$,$dadid2$,$momid2$,$sex2$,$hashgen{$famid2}{$subid2}\n";
					$individuals++;
					if ($sex2 == 1) { $males++; } elsif ($sex2 == 2) { $females++; }
					if ( ($dadid2 eq "0") && ($momid2 eq "0") ) { 
						if ( ( ($sex2 == 1) && (defined($wife{$subid2})) ) || ( ($sex2 == 2) && (defined($husb{$subid2})) ) ) {
							$founders++;
						} else {
							$singletons++;
							push (@singleton, $subid2);
						}
					} elsif (($dadid2 ne "0") && ($momid2 ne "0")) { 
						if (defined($indiv{$famid2}{$subid2})) {
							$nonfounders++;
						} else {
							$singletons++;
							push (@singleton, $subid2);
						}
					}
					push (@gen, $hashgen{$famid2}{$subid2});
				}
			}
			if ($iteration < 100) {
				$generations = max (@gen);
				if (!defined($individuals)) { $individuals = 0; }
				if (!defined($males))       { $males = 0; }
				if (!defined($females))     { $females = 0; }
				if (!defined($founders))    { $founders = 0; }
				if (!defined($nonfounders)) { $nonfounders = 0; }
				if (!defined($singletons))  { $singletons = 0; }
				if (!defined($generations)) { $generations = 0; }
				if ($individuals == 1) { $singleton{$subid2}++; }
				print OUT2 "$famid[0]$,$individuals$,$males$,$females$,$founders$,$nonfounders$,$singletons$,$generations\n";
				$tindividuals += $individuals;
				$tmales += $males;
				$tfemales += $females;
				$tfounders += $founders;
				$tnonfounders += $nonfounders;
				$tsingletons += $singletons;
				push (@mgen, $generations);
				push (@ped, $famid[0]);
			}
			
			# initialize for the succeeding pedigree
			($count, $gendiff, $iteration) = 0;
			($individuals, $males, $females, $founders, $nonfounders, $singletons, $generations) = 0;
			(@list2, @famid, @gen) = ();
			push (@list2, $temp);
			unshift (@famid, $famid);
			$count++;
		}
	}
}

# Last pedigree in file
			@list2a = @list2;
			getGenNum(@list2);
			my $iteration = 0;
			do {
				$gendiff = 0;
				getGenNum(@list2);
				$iteration++;
				if ($iteration >= 100) {
					$tskippedfam++;
					push (@ped, $famid[0]);
					$gendiff = 0;
					if ( ! -e $out3) {
						open (OUT3, ">$out3") || die ("Could not create $out3 file!\n");
						print LOG "Individuals whose generation numbers were not determined : $out3a\n\n";
						print OUT3 join ("\n", @list2);
						print OUT3 "\n";
					} elsif ( -e $out3) {
						print OUT3 join ("\n", @list2);
						print OUT3 "\n";
					}
					print LOG "Skipped family $famid[0] since generation numbers cannot be assigned properly\n";
					print "Skipped family $famid[0] since generation numbers cannot be assigned properly\n";
				}
			} until ($gendiff == 0);
			if ( ($gendiff == 0) && ($iteration < 100) ) {
				foreach $line2 (@list2a) {
					($famid2, $subid2, $dadid2, $momid2, $sex2) = split (/\t|\s+/, $line2, 5);
					print OUT1 "$famid2$,$subid2$,$dadid2$,$momid2$,$sex2$,$hashgen{$famid2}{$subid2}\n";
					$individuals++;
					if ($sex2 == 1) { $males++; } elsif ($sex2 == 2) { $females++; }
					if ( ($dadid2 eq "0") && ($momid2 eq "0") ) { 
						if ( ( ($sex2 == 1) && (defined($wife{$subid2})) ) || ( ($sex2 == 2) && (defined($husb{$subid2})) ) ) {
							$founders++;
						} else {
							$singletons++;
							push (@singleton, $subid2);
						}
					} elsif (($dadid2 ne "0") && ($momid2 ne "0")) { 
						if (defined($indiv{$famid2}{$subid2})) {
							$nonfounders++;
						} else {
							$singletons++;
							push (@singleton, $subid2);
						}
					}
					push (@gen, $hashgen{$famid2}{$subid2});
				}
			}
			if ($iteration < 100) {
				$generations = max (@gen);
				if (!defined($individuals)) { $individuals = 0; }
				if (!defined($males))       { $males = 0; }
				if (!defined($females))     { $females = 0; }
				if (!defined($founders))    { $founders = 0; }
				if (!defined($nonfounders)) { $nonfounders = 0; }
				if (!defined($singletons))  { $singletons = 0; }
				if (!defined($generations)) { $generations = 0; }
				if ($individuals == 1) { $singleton{$subid2}++; }
				print OUT2 "$famid[0]$,$individuals$,$males$,$females$,$founders$,$nonfounders$,$singletons$,$generations\n";
				$tindividuals += $individuals;
				$tmales += $males;
				$tfemales += $females;
				$tfounders += $founders;
				$tnonfounders += $nonfounders;
				$tsingletons += $singletons;
				push (@mgen, $generations);
				push (@ped, $famid[0]);
			}
# End of last pedigree in file

close (OUT1);
close (OUT2);
if ( -e $out3) {
	close (OUT3);
}

$mgenerations = max (@mgen);
$tpedigrees   = scalar (@ped);
if (!defined($tindividuals)) { $tindividuals = 0; }
if (!defined($tmales))       { $tmales = 0; }
if (!defined($tfemales))     { $tfemales = 0; }
if (!defined($tfounders))    { $tfounders = 0; }
if (!defined($tnonfounders)) { $tnonfounders = 0; }
if (!defined($tsingletons))  { $tsingletons = 0; }
if (!defined($mgenerations)) { $mgenerations = 0; }
if (!defined($tpedigrees))   { $tpedigrees = 0; }
if (!defined($tskippedfam))   { $tskippedfam = 0; }
print LOG "\nDATASET:\n";
print LOG "Total number of pedigrees              : $tpedigrees\n";
print LOG "Total number of individuals            : $tindividuals\n";
print LOG "Total number of males                  : $tmales\n";
print LOG "Total number of females                : $tfemales\n";
print LOG "Total number of founders               : $tfounders\n";
print LOG "Total number of non-founders           : $tnonfounders\n";
print LOG "Total number of singletons             : $tsingletons\n";
print LOG "Highest generation number              : $mgenerations\n";
print LOG "Number of pedigrees skipped by kped.pl : $tskippedfam\n";

if (scalar (@sptemp) >= 1) {
	print LOG "\nINDIVIDUAL(S) WITH MORE THAN ONE PARTNER:\n";
	print LOG join ("\n", @sptemp);
	print LOG "\n";
}
if (scalar (@singleton) >= 1) {
	print LOG "\nSINGLETON(S):\n";
	print LOG join ("\n", @singleton);
	print LOG "\n";
}

##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);

print "\nTotal real time   : " . parsetime ($real);
print   "Total user time   : " . parsetime ($user);
print   "Total system time : " . parsetime ($system);
print LOG "\nTotal real time   : " . parsetime ($real);
print LOG   "Total user time   : " . parsetime ($user);
print LOG   "Total system time : " . parsetime ($system);
print "\nDone\n\n";
close (LOG);

##### SUBROUTINES #####

sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}

sub getGenNum {
	my @ped = @_;
	$gendiff = 0;
	foreach $line2 (@ped) {
		($famid2, $subid2, $dadid2, $momid2, $sex2) = split (/\t|\s+/, $line2, 5);
		if (defined($singleton{$subid2})) { 
			$hashgen{$famid2}{$subid2} = 1;
			$gendiff = 0;
			last;
		}
		($gendad, $genmom, $genkid) = 0;
		# get current generation numbers of individuals in the pedigree
		$gendad = $hashgen{$famid2}{$dadid2};
		$genmom = $hashgen{$famid2}{$momid2};
		$genkid = $hashgen{$famid2}{$subid2};
		$genT = max ($gendad, $genmom, $genkid - 1);
		
		# update generation numbers of individuals in the pedigree
		$gendad = $genmom = $genT;
		$genkid = $genT + 1;
		if ( ($gendad > $hashgen{$famid2}{$dadid2}) && ($dadid2 ne "0") ) {
			if ($dadid2 eq "0") { $hashgen{$famid2}{$dadid2} = 0; } else { $hashgen{$famid2}{$dadid2} = $genT; }
			if ($momid2 eq "0") { $hashgen{$famid2}{$momid2} = 0; } else { $hashgen{$famid2}{$momid2} = $genT; }
			$hashgen{$famid2}{$subid2} = $genT + 1;
			$gendiff++;
		} elsif ( ($genmom > $hashgen{$famid2}{$momid2}) && ($momid2 ne "0") ) {
			if ($dadid2 eq "0") { $hashgen{$famid2}{$dadid2} = 0; } else { $hashgen{$famid2}{$dadid2} = $genT; }
			if ($momid2 eq "0") { $hashgen{$famid2}{$momid2} = 0; } else { $hashgen{$famid2}{$momid2} = $genT; }
			$hashgen{$famid2}{$subid2} = $genT + 1;
			$gendiff++;
		} elsif ($genkid > $hashgen{$famid2}{$subid2}) {
			if ($dadid2 eq "0") { $hashgen{$famid2}{$dadid2} = 0; } else { $hashgen{$famid2}{$dadid2} = $genT; }
			if ($momid2 eq "0") { $hashgen{$famid2}{$momid2} = 0; } else { $hashgen{$famid2}{$momid2} = $genT; }
			$hashgen{$famid2}{$subid2} = $genT + 1;
			$gendiff++;
		}
		($gendad, $genmom, $genkid) = 0;
	}
}

