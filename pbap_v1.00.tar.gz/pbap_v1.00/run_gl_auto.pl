#!/usr/bin/perl
# ./run_gl_auto.pl
# By Alejandro Q. Nato Jr., Ph.D. 
# This script runs gl_auto
# Run this script after running marker_subpanels.pl and setup_gl_auto.pl
# The directory structure will be based on the output of
# marker_subpanels.pl and setup_gl_auto.pl
# The output files will be in the same directory as the output files of
# setup_gl_auto.pl
# Some portions were based on scripts written by Dr. Nicola H. Chapman

# 02/06/2014-02/10/2014
# Modifications: 02/10/2014-05/14/2015


use strict;
use warnings;
use diagnostics;

use Time::HiRes qw( gettimeofday );

$, = " ";	# set output field separator

my ($line, $line1, $line2, $line3, $line4, $line5) = "";
my (@list, @list1, @list2, @list3, @list4, @list5) = ();
my (@info, @info1, @info2, @info3, @info4, @info5) = ();

my ($line6, $line7, $line8, $line9, $line10) = "";
my (@list6, @list7, @list8, @list9, @list10) = ();
my (@info6, @info7, @info8, @info9, @info10) = ();

my ($line11, $line12, $line13, $line14, $line15) = "";
my (@list11, @list12, @list13, @list14, @list15) = ();
my (@info11, @info12, @info13, @info14, @info15) = ();
my ($chr, $panel, $parfile, $singlefam) = "";

if ($#ARGV == 2) {
	$chr       = $ARGV[0];	# chromosome number
	$panel     = $ARGV[1];	# subpanel number
	$parfile   = $ARGV[2];	# absolute path of run_gl_auto.pl parameter file
} elsif ($#ARGV == 3) {
	$chr       = $ARGV[0];	# chromosome number
	$panel     = $ARGV[1];	# subpanel number
	$parfile   = $ARGV[2];	# absolute path of run_gl_auto.pl parameter file
	$singlefam = $ARGV[3];	# single family (useful for parallel runs)
}

my ($script, $script1) = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;

if ($#ARGV < 0) {
	$script  = $0;
	$script  =~ s/^(.+)\///g;
	$script  =~ s/^\.\///g;
	$script1 = $script;
	$script1 =~ s/\.pl//g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (Feb 2014)\n\n";
	print "This script runs gl_auto\n";
	print "Run this script after running marker_subpanels.pl and setup_gl_auto.pl\n";
	print "   The directory structure will be based on the output of\n";
	print "   marker_subpanels.pl and setup_gl_auto.pl\n";
	print "   The output files will be in the same directory as the output files of\n";
	print "   setup_gl_auto.pl\n\n";

	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script chromosome subpanel_number $script1\_parameter_file* family_ID**\n";
	print "       *use absolute path\n";
	print "       **(optional): indicate family ID here if you only want to run gl_auto on one family\n\n";

	print "Parameter file should contain the following:\n\n";
	print "\tLine  1 - Directory containing run_gl_auto.pl\n";

	print "\tLine  2 - Output files of setup_gl_auto were split by pedigree: [Y|N]\n";
	print "\t             Y: To run gl_auto one family at a time (pedigree-specific) for all families,\n";
	print "\t                indicate the location of pedigree files used for setup_gl_auto.pl in lines 7-10\n";
	print "\t                To run specific families, list the FamilyIDs (space-delimited) after \"Y\"\n";
	print "\t                e.g., \"Y Family1 Family2 Family3 ..... FamilyN\"\n";
	print "\t             N: Run gl_auto for all families using one file (leave lines 7-10 blank)\n";
	
	print "\tLine  3 - Path of gl_auto that will be used (e.g., /usr/bin/gl_auto or /home/username/bin/gl_auto)\n";
	
	print "\tLine  4 - Population: [AFR|AMR|ASN|EUR]\n";

	print "\tLine  5 - Directory containing marker subpanel map files\n";
	print "\tLine  6 - Directory containing output files of setup_gl_auto.pl\n";
	print "\tLine  7 - Directory containing pedigree files\n";
	print "\t             Use the output pedigree files of transpose_fileset.pl (*.tpedo)\n";
	print "\t             and not the output pedigree files of setup_gl_auto.pl\n";
	print "\t             If there is a subdirectory for each chromosome, do not include it here\n";
	print "\tLine  8 - [(prefix=)(suffix)] of chromosome number in names of subdirectories\n";
	print "\t             where pedigree files are located\n";
	print "\tLine  9 - [(prefix=)(suffix)] of chromosome number in input pedigree filenames\n";
	print "\t             e.g., if if your files are named chr*-ped.txt, put \"prefix=chr suffix=-ped.txt\"\n";
	print "\tLine 10 - Input pedigree file has a header or not: header=[T|F]\n";

	print "\tNotes: 1) Blank lines and lines that start with a pound sign (#) will be ignored\n";
	print "\t       2) Use absolute paths for all directories and filenames unless specified otherwise\n";
	print "\t       3) For lines 5 and 6, do not include the subdirectories for each subpanel (i.e., panel#)\n";
	print "\t             population (line 4), and chromosome\n";
	print "\t             They will automatically be added based on what you indicated\n";
	print "\t             e.g., if your directory is \"subpaneldir\/panel*\/EUR\/chr*,\" just place \"subpaneldir\"\n";
	print "\t       4) For subdirectory in line 8, if files in line 9 are directly under the directory in line 7,\n";
	print "\t             put \"no dir\"\n";
	print "\t             Examples (if subdirectory is present):\n";
	print "\t             If subdirectory is named chr*, put \"prefix=chr suffix=none\"\n";
	print "\t             If subdirectory is named chr*geno, put \"prefix=chr suffix=geno\"\n";
	print "\t             If subdirectory just contains the chromosome number without any prefix or suffix, you can put \"none\"\n";
	print "\t       5) Lines 7-10 are for the pedigree files\n";
	print "\t       6) If there are Mendelian inconsistencies detected by gl_auto, a backup copy (chr*.geno.bak) of the\n";
	print "\t             original genotype file (chr*.geno) will be created\n\n";
	exit;
}
##############
my ($count, $count1, $count2, $count3, $count4, $numtype) = 0;
my ($scriptdir, $splitped, $glauto, $popn) = "";
my ($mainmdir, $mainsdir, $paneldir, $outdir, $glautodir) = "";
my ($fam, $rest, $fid, $iid) = "";
my ($mapin, $genoin, $parin) = "";
my ($pedname, $pedpre, $pedsuf, $pedin) = "";
my ($mainpdir, $peddir, $peddirpre, $peddirsuf) = "";
my ($peddirin, $pedfdir, $pedfile, $pedh) = "";
my ($i, $j) = 0;
my (@splitped, @fam, @usertime, @systemtime) = ();

open (IN1, "<$parfile") || die ("Could not open $parfile!\n");
@list1 = <IN1>;
close (IN1);
print "\nThese are the parameters that you specified:\n";
foreach $line1 (@list1) {
	chomp $line1;
	next if ($line1 =~ m/^\#/);
	next if ( ($line1 =~ m/\t|\#/) && ( ($line1 =~ m/line|:|\"|\=/i) || ($line1 !~ m/\d/)) );
	next if (length($line1) == 0);
	$line1 =~ s/^\s+//g;
	$line1 =~ s/\s+$//g;
	$count++;
	print "line $count: $line1\n";
	if    ($count == 1) { $scriptdir = $line1; }
	elsif ($count == 2) { $splitped  = $line1; }
	elsif ($count == 3) { $glauto    = $line1; }
	elsif ($count == 4) { $popn      = $line1; }
	elsif ($count == 5) { $mainmdir = $line1; }
	elsif ($count == 6) { $mainsdir = $line1; }
	elsif ( (defined($splitped)) && ($splitped =~ m/^Y/) ) {
		if    ($count == 7)  { $mainpdir = $line1; }
		elsif ($count == 8)  { $peddir   = $line1; }
		elsif ($count == 9)  { $pedname  = $line1; }
		elsif ($count == 10) { $pedh     = $line1; }
	}
}
print "\n";
if ( (defined($mainmdir)) && ($mainmdir =~ m/\/$/) ) { chop $mainmdir; }
if ( (defined($mainsdir)) && ($mainsdir =~ m/\/$/) ) { chop $mainsdir; }
if ( (defined($mainpdir)) && ($mainpdir =~ m/\/$/) ) { chop $mainpdir; }

$paneldir = $mainsdir . "/panel" . $panel;
if (! -e $paneldir) {
	`mkdir -p $paneldir`;
}

$outdir = $paneldir . "/" . $popn;
if (! -e $outdir) {
	`mkdir -p $outdir`;
}

my $popchrdir = $outdir . "/chr" . $chr;
if ($splitped =~ m/^N/i) {
	if (! -e $popchrdir) {
		`mkdir -p $popchrdir`;
	}
}

# Create log file
my $logdir = $paneldir . "/log";
if (! -e $logdir) {
	`mkdir -p $logdir`;
}
my $log = "";
if (defined($singlefam)) {
	$log = "$logdir\/run_gl_auto_panel$panel\_$popn\_family$singlefam\_chr$chr\.log";
} elsif (!defined($singlefam)) {
	$log = "$logdir\/run_gl_auto_panel$panel\_$popn\_chr$chr\.log";
}
open (LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "################################################################################\n";
print LOG "#                             PBAP run_gl_auto.pl                              #\n";
print LOG "#                            Alejandro Q. Nato, Jr.                            #\n";
print LOG "#                           Statistical Genetics Lab                           #\n";
print LOG "#                    University of Washington, Seattle, WA                     #\n";
print LOG "################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

print LOG "PARAMETERS SPECIFIED:\n";

print "Path of gl_auto: $glauto\n";
print LOG "Path of gl_auto              : $glauto\n";

$mapin = $mainmdir . "/panel" . $panel . "/" . $popn . "/chr" . $chr . "/chr" . $chr . ".pmap";
print "Map file : $mapin\n";
print LOG "Map file                     : $mapin\n";
my ($chr5, $marker5, $genloc5, $phypos5, $type5) = "";
my (%gloc, %ppos, %mrkr) = ();
$count2 = 0;
open (IN5, "<$mapin") || die ("Could not open $mapin file!\n");
while (defined ($line5 = <IN5>)) {
	chomp $line5;
	$line5 =~ s/^\s+//g;
	$line5 =~ s/\s+$//g;
	next if ( ($line5 =~ m/^\#/) || (length($line5) == 0) );
	($chr5, $marker5, $genloc5, $phypos5, $type5) = split (/\s+/, $line5);
	$count2++;
	$gloc{$chr5}{$count2} = sprintf ("%.6f", $genloc5);
	if ($phypos5 =~ m/NA/) {
		$ppos{$chr5}{$count2} = $phypos5;
	} elsif ($phypos5 !~ m/NA/) {
		$ppos{$chr5}{$count2} = sprintf ("%.0f", $phypos5);
	}
	$mrkr{$chr5}{$count2} = $marker5;
}
close (IN5);


if ($splitped =~ m/^Y/i) {
	# Check if there are families specified by user
	@splitped = split(/\s+/, $splitped);
	if (scalar(@splitped) > 1) {
		$splitped = $splitped[0];
		print "Split pedigrees : $splitped\n";
		print LOG "Split pedigrees              : $splitped\n";
		for ($i = 1; $i<= $#splitped; $i++) {
			push (@fam, $splitped[$i]);
		}
		if (defined($singlefam)) {
			@fam = ();
			push (@fam, $singlefam);
			print "Family specified on command line (overrides parameter file):\n";
		} elsif (!defined($singlefam)) {
			print "Families specified:\n";
		}
		print join ("\n", @fam);
		print "\n\n";
		print LOG "Families specified           : " . join (" ", @fam) . "\n";

		if (defined($mainpdir)) {
			print "We will only run gl_auto for the families that you specified so not all\n";
			print "   the families in pedigree file specified in lines 7-10 will be used\n\n";
		}
	} elsif (scalar(@splitped) == 1) {
		$splitped = "Y";
		if (defined($singlefam)) {
			@fam = ();
			push (@fam, $singlefam);
		} elsif (!defined($singlefam)) {
			print "We will use the families included in the pedigree file used for setup_gl_auto.pl\n";
			# Pedigree file
			if ($peddir eq "no dir") {
				$pedfdir = $mainpdir;
			} elsif ($peddir ne "no dir") {
				if ($peddir eq "none") {
					$peddirpre = "";
					$peddirsuf = "";
				} elsif ($peddir =~ m/prefix\=(.+) suffix\=(.+)/) {
					$peddirpre = $1;
					$peddirsuf = $2;
					if ($peddirpre eq "none") { $peddirpre = ""; }
					if ($peddirsuf eq "none") { $peddirsuf = ""; }
				} elsif ( ($peddir =~ m/prefix\=(.+)/) && ($peddir !~ m/suffix\=(.+)/) ) {
					$peddirpre = $1;
					$peddirsuf = "";
					if ($peddirpre eq "none") { $peddirpre = ""; }
				} elsif ( ($peddir !~ m/prefix\=(.+)/) && ($peddir =~ m/suffix\=(.+)/) ) {
					$peddirpre = "";
					$peddirsuf = $1;
					if ($peddirsuf eq "none") { $peddirsuf = ""; }
				}
				$pedfdir = $mainpdir . "/" . $peddirpre . $chr . $peddirsuf;
			}
			#print "pedfdir\=$pedfdir\n";
			if ($pedname =~ m/prefix\=(.+) suffix\=(.+)/) {
				$pedpre = $1;
				$pedsuf = $2;
				if ($pedpre eq "none") { $pedpre = ""; }
				if ($pedsuf eq "none") { $pedsuf = ""; }
			} elsif ( ($pedname =~ m/prefix\=(.+)/) && ($pedname !~ m/suffix\=(.+)/) ) {
				$pedpre = $1;
				$pedsuf = "";
				if ($pedpre eq "none") { $pedpre = ""; }
			} elsif ( ($pedname !~ m/prefix\=(.+)/) && ($pedname =~ m/suffix\=(.+)/) ) {
				$pedpre = "";
				$pedsuf = $1;
				if ($pedsuf eq "none") { $pedsuf = ""; }
			}
			$pedfile = $pedfdir . "/" . $pedpre . $chr . $pedsuf;
			print "Pedigree file : $pedfile\n";
			print LOG "Pedigree file                : $pedfile\n";
			open (IN1, "<$pedfile") || die ("Could not open $pedfile file!\n");
			@fam = ();
			my %fam = ();
			while (defined ($line1 = <IN1>)) {
				chomp $line1;
				$line1 =~ s/^\s+//g;
				$line1 =~ s/\s+$//g;
				next if ( ($line1 =~ m/^\#/) || (length($line1) == 0) );
				($fam, $rest) = split(" ", $line1, 2);
				$fam{$fam}++;
				next if ($fam{$fam} > 1);
				push (@fam, $fam);
			}
			close (IN1);
		}
	}
} elsif ($splitped =~ m/^N/i) {
	$splitped = "N";
	if (defined($singlefam)) {
		print "Put \"Y\" in line 2 of your parameter file if you want to run gl_auto on a single family\n";
		exit;
	} elsif (!defined($singlefam)) {
		print "Split pedigrees : $splitped\n";
		print LOG "Split pedigrees              : $splitped\n";
	}
}

print "Output directory : $outdir\n";
print LOG "Output directory             : $outdir\n";

my ($glautoin, $glautoout, $glautobak, $glautoerr, $mainerr, $fglout) = "";
my $k = 0;

if ($splitped eq "Y") {
	if (scalar(@fam) >= 1) {
		# Run gl_auto for specific families
		foreach $fam (@fam) {
			$k++;
			$time2 = 0;
			$time2  = [Time::HiRes::gettimeofday()];
			$glautodir = $outdir . "/ped" . $fam . "/chr" . $chr;
			print "\nglautodir\=$glautodir\n";
			if (! -e $glautodir) {
				`mkdir -p $glautodir`;
			}
			chdir("$glautodir");
			$glautoin  = $glautodir . "/chr" . $chr . ".glauto.par";
			$glautoout = $glautodir . "/chr" . $chr . ".glauto.out";
			$fglout    = $glautodir . "/chr" . $chr . ".fgl";
			$mainerr   = $glautodir . "/chr" . $chr . ".err.all";
			$glautobak = "";
			$glautoerr = "";
			
			print "\nRunning glauto for panel $panel family $fam chromosome $chr ...";
			print LOG "\nRunning glauto for panel $panel family $fam chromosome $chr ...";
			system("/home/bin/gl_auto $glautoin &> $glautoout");
			for ($j = 1; $j <= 10; $j++) {
				if ( -e $fglout ) {
					# FGL output file exists
					print "ok\n";
					print LOG "ok\n";
					last;
				} elsif ( ! -e $fglout ) {
					print "\n   Mendelian inconsistencies were detected so we will zero out\n";
					print "     genotypes of all individuals in the pedigree and will rerun gl_auto\n";
					print LOG "\n   Mendelian inconsistencies were detected so we will zero out\n";
					print LOG "     genotypes of all individuals in the pedigree and will rerun gl_auto\n";
					if ( ! -e $mainerr ) {
						open (OUT1, ">$mainerr") || die ("Could not create $mainerr file!\n");
					}
					parse_errors_fam($chr, $j);
					zero_genotypes_fam($chr, $j);
					system("/home/bin/gl_auto $glautoin &> $glautoout");
				}
				unless ( -e $fglout ) {
					print "   After cycle $j it is still not working, so we will rerun again!\n";
					print LOG "   After cycle $j it is still not working, so we will rerun again!\n";
				}
			}
			if ( -e $mainerr ) {
				close (OUT1);
			}
			
			my ($user3, $system3) = 0;
			($user2, $system2, $child_user2, $child_system2) = 0;
			($user2, $system2, $child_user2, $child_system2) = times;
			$real2   = Time::HiRes::tv_interval($time2);
			$user2   = sprintf ("%.3f", $user2 + $child_user2);
			$system2 = sprintf ("%.3f", $system2 + $child_system2);
			unshift (@usertime, $user2);
			unshift (@systemtime, $system2);
			if ($k == 1) {
				$user3 = $usertime[0];
				$system3 = $systemtime[0];
			} elsif ($k > 1) {
				$user3 = $usertime[0] - $usertime[1];
				$system3 = $systemtime[0] - $systemtime[1];
			}
			print "\nReal time (panel $panel popn $popn fam $fam chr $chr)   : " . parsetime ($real2);
			print   "User time (panel $panel popn $popn fam $fam chr $chr)   : " . parsetime ($user3);
			print   "System time (panel $panel fpopn $popn fam $fam chr $chr) : " . parsetime ($system3);
			print LOG "\nReal time (panel $panel popn $popn fam $fam chr $chr)   : " . parsetime ($real2);
			print LOG   "User time (panel $panel popn $popn fam $fam chr $chr)   : " . parsetime ($user3);
			print LOG   "System time (panel $panel popn $popn fam $fam chr $chr) : " . parsetime ($system3);
			
			chdir("$scriptdir");
		}
	}
} elsif ($splitped eq "N") {
	# Run gl_auto for all families
	$glautodir = $outdir . "/chr" . $chr;
	print "\nglautodir\=$glautodir\n";
	if (! -e $glautodir) {
		`mkdir -p $glautodir`;
	}
	chdir("$glautodir");
	$glautoin  = $glautodir . "/chr" . $chr . ".glauto.par";
	$glautoout = $glautodir . "/chr" . $chr . ".glauto.out";
	$fglout    = $glautodir . "/chr" . $chr . ".fgl";
	$mainerr   = $glautodir . "/chr" . $chr . ".err.all";
	$glautobak = "";
	$glautoerr = "";
	
	print "\nRunning glauto for panel $panel chromosome $chr ...";
	print LOG "\nRunning glauto for panel $panel chromosome $chr ...";
	system("/home/bin/gl_auto $glautoin &> $glautoout");
	for ($j = 1; $j <= 10; $j++) {
		if ( -e $fglout ) {
			# FGL output file exists
			print "ok\n";
			print LOG "ok\n";
			last;
		} elsif ( ! -e $fglout ) {
			print "\n   Mendelian inconsistencies were detected so we will zero out\n";
			print "     genotypes of all individuals in the pedigree and will rerun gl_auto\n";
			print LOG "\n   Mendelian inconsistencies were detected so we will zero out\n";
			print LOG "     genotypes of all individuals in the pedigree and will rerun gl_auto\n";
			if ( ! -e $mainerr ) {
				open (OUT1, ">$mainerr") || die ("Could not create $mainerr file!\n");
			}
			parse_errors_fam($chr, $j);
			zero_genotypes_fam($chr, $j);
			system("/home/bin/gl_auto $glautoin &> $glautoout");
		}
		unless ( -e $fglout ) {
			print "   After cycle $j it is still not working, so we will rerun again!\n";
			print LOG "   After cycle $j it is still not working, so we will rerun again!\n";
		}
	}
	if ( -e $mainerr ) {
		close (OUT1);
	}
	
	chdir("$scriptdir");
}





##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);

print "\nTotal real time (panel $panel popn $popn chr $chr)   : " . parsetime ($real);
print   "Total user time (panel $panel popn $popn chr $chr)   : " . parsetime ($user);
print   "Total system time (panel $panel popn $popn chr $chr) : " . parsetime ($system);
print LOG "\nTotal real time (panel $panel popn $popn chr $chr)   : " . parsetime ($real);
print LOG   "Total user time (panel $panel popn $popn chr $chr)   : " . parsetime ($user);
print LOG   "Total system time (panel $panel popn $popn chr $chr) : " . parsetime ($system);
print "\nDone\n\n";
close (LOG);

##### SUBROUTINES #####

sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}

sub parse_errors_fam {
	
	my $chr2  = $_[0];
	my $cycle = $_[1];
	my @indtozero = ();
	my $marker = "";
	@info2 = ();
	$glautodir = $glautodir;
	$glautoout = $glautoout;
	$mainerr   = $mainerr;
	%gloc = %gloc;
	%ppos = %ppos;
	%mrkr = %mrkr;
	
	# Backup current chr*.glauto.out
	$glautobak = $glautodir . "/chr" . $chr2 . ".glauto.out$cycle";
	system("cp -p $glautoout $glautobak");

	$glautoerr = $glautodir . "/chr" . $chr2 . ".err$cycle";
	open (OUT2, ">$glautoerr") || die ("Could not create $glautoerr file!\n");
	open (IN2, "<$glautoout") || die ("Could not open $glautoout file!\n");
	while (defined ($line2 = <IN2>)) {
		chomp $line2;
		$line2 =~ s/^\s+//g;
		$line2 =~ s/\s+$//g;
		next if ( ($line2 =~ m/^\#/) || (length($line2) == 0) );
		@info2 = split(" ", $line2);
		if ($info2[0] eq "Mendelian" or $info2[0] eq "hostname:") {
			if (scalar(@indtozero) >= 1) { 
				print OUT1 "$cycle$,$marker$,$mrkr{$chr2}{$marker}$,$gloc{$chr2}{$marker}$,$ppos{$chr2}{$marker}$,@indtozero\n";
				print OUT2 "$cycle$,$marker$,$mrkr{$chr2}{$marker}$,$gloc{$chr2}{$marker}$,$ppos{$chr2}{$marker}$,@indtozero\n";
				@indtozero = ();
			}
			$marker = $info2[8];
		}
		if ( ($info2[0] eq "Father:") || ($info2[0] eq "Mother:") || ($info2[0] eq "->") ) {
			push(@indtozero, $info2[1].":".$info2[2]);
		}
	}
	close (IN2);
	close (OUT2);
}

sub zero_genotypes_fam {

	my $chr2  = $_[0];
	my $cycle = $_[1];
	my @indtozero = ();
	my ($marker, $cycle2, $nummarkers, $genloc4, $phypos4) = 0;
	my ($k, $indiv, $geno3, $marker4, $geno4, $markername) = "";
	my %zeroout = ();
	$glautodir = $glautodir;
	$glautoerr = $glautoerr;
	%gloc = %gloc;
	%ppos = %ppos;
	%mrkr = %mrkr;
	
	# chr*.geno should always be the latest so we will backup the original
	# genotype file as chr*.geno
	my $geno    = $glautodir . "/chr" . $chr2 . ".geno";
	my $genobak = $glautodir . "/chr" . $chr2 . ".geno.bak$cycle";
	system("cp -p $geno $genobak");
	
	# Read the list of individuals whose genotypes should be zeroed out
	open (IN3, "<$glautoerr") || die ("Could not open $glautoerr file!\n");
	my $indtozero2 = "";
	while (defined ($line3 = <IN3>)) {
		chomp $line3;
		$line3 =~ s/^\s+//g;
		$line3 =~ s/\s+$//g;
		next if ( ($line3 =~ m/^\#/) || (length($line3) == 0) );
		($cycle2, $marker, $markername, $genloc4, $phypos4, $indtozero2) = split(" ", $line3, 6);
		@indtozero = split (" ", $indtozero2);
		for ($k=0; $k<=$#indtozero; $k++) {
			($indiv, $geno3) = split (/\:/, $indtozero[$k]);
			# let us zero out the entire family for this marker instead of this individual alone
			($fid, $iid) = split (/\_|\-\./, $indiv);
			print "indiv_error\=$indiv so zero_out_family $fid\n";
			$zeroout{$marker}{$fid}++;
		}
		@indtozero = ();
	}
	close (IN3);
	
	# We will overwrite the current genotype file (same filename as $geno above)
	my $genoout  = $glautodir . "/chr" . $chr2 . ".geno";
	my $genorows = 0;
	open (OUT3, ">$genoout") || die ("Could not create $genoout file!\n");
	open (IN4, "<$genobak") || die ("Could not open $genobak file!\n");
	while (defined ($line4 = <IN4>)) {
		chomp $line4;
		@info4 = split (" ", $line4);
		# Print lines as is before reaching rows containing genotype data
		if ($genorows == 0) {
			print OUT3 "$line4\n";
		}
		# If $genorows is 1, let's zero out the genotypes
		if ($genorows == 1) {
			if (length($line4) == 0) {
				print OUT3 "\n";
				next;
			} elsif (length($line4) >= 1) {
				print OUT3 "$info4[0]";
				foreach ($marker4 = 1; $marker4 <= $nummarkers; $marker4++) {
					my ($fid2, $iid2) = "";
					($fid2, $iid2) = split (/\_|\-\./, $info4[0]);
					if (defined($zeroout{$marker4}{$fid2})) {
						# Zero out the genotype
						print "zero out indiv\=$info4[0] marker4\=$marker4 cycle\=$cycle\n";
						print OUT3 "$,0 0";
					} elsif (!defined($zeroout{$marker4}{$fid2})) {
						# Print the current genotype
						$geno4 = $info4[2*$marker4-1] . " " . $info4[2*$marker4];
						print OUT3 "$,$geno4";
					}
				}
				print OUT3 "\n";
			}
		}
		
		# When it reaches the indicator that genotype data is next ("set markers # data")
		# set $genorows to 1
		unless (!defined($info4[3])) {
			if ($info4[3] eq "data") {
				$genorows = 1;
				$nummarkers = $info4[2];
			}
		}
	}
	close (IN4);
	close (OUT3);
}

