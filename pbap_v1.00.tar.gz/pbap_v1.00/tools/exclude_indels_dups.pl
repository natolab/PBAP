#!/usr/bin/perl
# ./exclude_indels_dups.pl
# By Alejandro Q. Nato Jr., Ph.D.
# This script excludes indels and duplcate SNPs by using vcftools and
# subsequent checks on the 1000 Genomes Project files

# 10/02/2013
# Modification: 08/06/2015


use strict;
use warnings;
use diagnostics;

use Time::HiRes qw( gettimeofday );

$, = " ";	# set output field separator

my ($line, $line1, $line2, $line3, $line4, $line5) = "";
my (@list, @list1, @list2, @list3, @list4, @list5) = ();
my (@info, @info1, @info2, @info3, @info4, @info5) = ();

my ($line6, $line7, $line8, $line9, $line10) = "";
my (@list6, @list7, @list8, @list9, @list10) = ();
my (@info6, @info7, @info8, @info9, @info10) = ();

my $indir    = $ARGV[0];	# input directory
my $outdir   = $ARGV[1];	# output directory
#                             do not include the population here since it will be automatically created under this folder
my $vcftools = $ARGV[2];	# location of vcftools
my $chr      = $ARGV[3];	# chromosome
my $popn     = $ARGV[4];	# main population


my ($script, $script1) = "";

my $rundate = "";
my ($time1, $real, $user, $system, $child_user, $child_system) = 0;
my ($time2, $real2, $user2, $system2, $child_user2, $child_system2) = 0;

if ($#ARGV < 0) {
	$script  = $0;
	$script  =~ s/^(.+)\///g;
	$script  =~ s/^\.\///g;
	$script1 = $script;
	$script1 =~ s/\.pl//g;
	print "\n$script\n";
	print "By Alejandro Q. Nato, Jr. (Oct 2013)\n\n";
	print "This script excludes indels and duplcate SNPs by using vcftools and\n";
	print "subsequent checks on the 1000 Genomes Project files.\n\n";

	print "Make the Perl script executable (i.e., chmod 755 *.pl)\n";
	print "USAGE: \.\/$script input_directory output_directory location_of_vcftools chromosome main_population:[AFR|EUR|AMR|ASN]\n\n";
	exit;
}

if ( (defined($indir)) && ($indir =~ m/\/$/) ) { chop $indir; }
if ( (defined($outdir)) && ($outdir =~ m/\/$/) ) { chop $outdir; }

$outdir = "$outdir\/$popn";
if (! -e $outdir) {
	`mkdir -p $outdir`;
}

# Create log file
my $log = "$outdir\/exclude_indels_dups_$popn\_chr$chr\.log";
open(LOG, ">$log") || die ("Could not create $log file!\n");
open (LOG, ">$log") || die ("Could not create $log file!\n");
print LOG "################################################################################\n";
print LOG "#                            exclude_indels_dups.pl                            #\n";
print LOG "#                            Alejandro Q. Nato, Jr.                            #\n";
print LOG "#                           Statistical Genetics Lab                           #\n";
print LOG "#                    University of Washington, Seattle, WA                     #\n";
print LOG "################################################################################\n\n";

$rundate = readpipe ("date \+\%a\"\, \"\%b\" \"\%d\"\, \"\%Y\" \"\%T"); chomp $rundate; print LOG "$rundate\n\n";
$time1  = [Time::HiRes::gettimeofday()];

##########
# Edit this line depending on your filename
my $in1 = "$indir\/chr$chr\.phase1_release_v3.20101123.snps_indels_svs.genotypes.refpanel.$popn\.vcf"; 
##########
my $tpedout = "$outdir\/$popn\_chr$chr\.tped";
my $tfamout = "$outdir\/$popn\_chr$chr\.tfam";
print LOG "INPUT FILE       : $in1\n";
print LOG "OUTPUT TPED FILE : $tpedout\n";
print LOG "OUTPUT TFAM FILE : $tfamout\n\n";

print LOG "LOG:\n";

# Run vcftools
chdir("$outdir");
system("$vcftools --vcf $in1 --remove-indels --plink-tped --out $popn\_chr$chr\_tmp");
system("mv $popn\_chr$chr\_tmp.tfam $popn\_chr$chr\.tfam");
system("mv $popn\_chr$chr\_tmp.log $popn\_chr$chr\.log");

# Although very rare, simply check for more duplicates
# Usually, there are two lines of the same SNP where one has
# a regular SNP and the other is an indel so the command above
# already removes these indels
my $in2  = "$outdir\/$popn\_chr$chr\_tmp.tped";
my $out1 = "$outdir\/$popn\_chr$chr\.tped";
my $out2 = "$outdir\/$popn\_chr$chr\_dup.tped";
my $out3 = "$outdir\/$popn\_chr$chr\_indel.tped";

open (IN1, "<$in2") || die ("Could not open $in2 file!\n");
open (OUT1, ">$out1") || die ("Could not open $out1 file!\n");

my ($i, $count, $count2) = 0;
my ($m1, $m2, $m3) = 0;
my %marker = ();
while (<IN1>) {
	chomp;
	$line1 = $_;
	$line1 =~ s/^\s+//g;
	$line1 =~ s/\s+$//g;
	next if (length ($line1) == 0);
	@info1 = ();
	@info1 = split (/\t/, $line1);
	my $elem = scalar (@info1);
	($i, $count) = 0;
	for ($i = 4; $i < $elem; $i++) {
		$info1[$i] =~ s/^\s+//g;
		$info1[$i] =~ s/\s+$//g;
		if (length ($info1[$i]) > 1) {
			$count++;
			$i = $elem;
		}
	}
	
	$line1 =~ s/\t/ /g;
	if (defined($count)) {
		if (! -e $out3) {
			open (OUT3, ">$out3") || die ("Could not open $out3 file!\n");
			print OUT3 "$line1\n";
			$m3++;
		} elsif ( -e $out2) {
			print OUT2 "$line1\n";
			$m2++;
		}
		if (exists($marker{$info1[1]})) {
			if (! -e $out2) {
				open (OUT2, ">$out2") || die ("Could not open $out2 file!\n");
				print OUT2 "$line1\n";
				$m2++;
			} elsif ( -e $out2) {
				print OUT2 "$line1\n";
				$m2++;
			}
		}
	} elsif (!defined($count)) {
		if (!exists($marker{$info1[1]})) {
			$count2++;
			print OUT1 "$line1\n";
			$m1++;
			$marker{$info1[1]} = 1;
		} elsif (exists($marker{$info1[1]})) {
			if (! -e $out2) {
				open (OUT2, ">$out2") || die ("Could not open $out2 file!\n");
				print OUT2 "$line1\n";
				$m2++;
			} elsif ( -e $out2) {
				print OUT2 "$line1\n";
				$m2++;
			}
		}
	}
	($i, $count) = 0;
	@info1 = ();
}
close (OUT1);
if (-e $out2) {
	close (OUT2);
}
if (-e $out3) {
	close (OUT3);
}
if (!defined($m1)) { $m1 = 0; }
if (!defined($m2)) { $m2 = 0; }
if (!defined($m3)) { $m3 = 0; }
print "\nNumber of markers in the output TPED file \($out1\)\: $m1\n";
print LOG "Number of markers in output TPED file \($out1\)\: $m1\n";
if (-e $out2) {
	print "Number of duplicate markers \($out2\)\: $m2\n";
	print LOG "Number of duplicate markers \($out2\)\: $m2\n";
} elsif (! -e $out2) {
	print "There are no duplicate markers detected\n";
	print LOG "There are no duplicate markers detected\n";
}
if (-e $out3) {
	print "Number of indels \($out3\)\: $m3\n";
	print LOG "Number of indels \($out3\)\: $m3\n";
} elsif (! -e $out2) {
	print "There are no more indels detected\n";
	print LOG "There are no more indels detected\n";
}

`rm $in2`;

##########
($user, $system, $child_user, $child_system) = times;
$real   = Time::HiRes::tv_interval($time1);
$user   = sprintf ("%.3f", $user + $child_user);
$system = sprintf ("%.3f", $system + $child_system);

print "\nTotal real time (popn $popn chr $chr)   : " . parsetime ($real);
print   "Total user time (popn $popn chr $chr)   : " . parsetime ($user);
print   "Total system time (popn $popn chr $chr) : " . parsetime ($system);
print LOG "\nTotal real time (popn $popn chr $chr)   : " . parsetime ($real);
print LOG   "Total user time (popn $popn chr $chr)   : " . parsetime ($user);
print LOG   "Total system time (popn $popn chr $chr) : " . parsetime ($system);
print "\nDone\n\n";
close (LOG);

##### SUBROUTINES #####

sub parsetime {
	my $seconds = $_[0];
	my $hours   = int ( $seconds / 3600 );
	my $minutes = int ( ($seconds - ($hours * 3600)) / 60);
	my $remsec  = sprintf ("%.3f", ( $seconds - ($hours * 3600) - ($minutes * 60) ) );
	my $elapsed = "$hours hr $minutes min $remsec sec";
	return "$elapsed\n";
}
